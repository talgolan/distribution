/**
 * Generate Architect_Comments__c from opportunity fields and guidelines (rule-based; ≤ maxLength).
 * Supports full Slackbot-style comments and 240-char summary. Pure functions; no I/O.
 * @module src/generator
 */

import * as analyzer from "./analyzer.js";

const DEFAULT_MAX_LENGTH = 240;
const SUMMARY_MAX_LENGTH = 240;

/**
 * Score tier from IqScore (1–99).
 * @param {number|null|undefined} score
 * @returns {string}
 */
function scoreTier(score) {
  if (score == null || Number.isNaN(score)) return "N/A";
  const n = Number(score);
  if (n >= 70) return "High";
  if (n >= 40) return "Medium";
  return "Low";
}

/**
 * Truncate and sanitize a string to maxLen (single line, no control chars).
 *
 * @param {string} s
 * @param {number} maxLen
 * @returns {string}
 */
function truncate(s, maxLen) {
  const one = (s ?? "").replace(/\s+/g, " ").replace(/[\r\n]+/g, " ").trim();
  if (one.length <= maxLen) return one;
  return one.slice(0, maxLen - 1).trim() + "…";
}

/**
 * Generate Architect_Comments__c for one opportunity.
 * Uses SE_Comments__c (truncated), score tier (IqScore), stage, and a short guideline snippet.
 * Final length is always ≤ maxLength (default 240).
 *
 * @param {import('./types.js').Opportunity} opportunity - Normalized opportunity record
 * @param {string} guidelinesText - Full guidelines text from Google Doc or file
 * @param {{ maxLength?: number }} [options] - maxLength defaults to 240
 * @returns {string} Generated comment (≤ maxLength)
 */
export function generateArchitectComment(opportunity, guidelinesText, options = {}) {
  const maxLength = options.maxLength ?? DEFAULT_MAX_LENGTH;
  const parts = [];

  const seComments = (opportunity["SE_Comments__c"] ?? "").trim();
  if (seComments) {
    const allowed = Math.min(120, Math.floor(maxLength / 2));
    parts.push(truncate(seComments, allowed));
  }

  const stage = (opportunity["StageName"] ?? "").trim();
  if (stage) parts.push(`Stage: ${truncate(stage, 40)}`);

  const score = opportunity["IqScore"] ?? opportunity.IqScore;
  const tier = scoreTier(score);
  parts.push(`Score: ${tier}`);

  const guidelines = (guidelinesText ?? "").trim();
  if (guidelines) {
    const firstLine = guidelines.split(/\r?\n/)[0]?.trim() ?? "";
    const snippet = truncate(firstLine, 60);
    if (snippet) parts.push(snippet);
  }

  const raw = parts.join(" | ");
  return truncate(raw, maxLength);
}

/**
 * Generate the full architect comment (Slackbot-style sections, ~200–300 words).
 * Structure: Solution Summary, Technical Scope, Architecture Considerations, Risk Mitigation, Next Steps, Stage Assessment.
 *
 * @param {import('./types.js').OpportunityWithRelated} opportunityWithRelated
 * @param {string} guidelinesText
 * @param {{ maxLength?: number }} [options]
 * @returns {string} Full comment (multi-section)
 */
export function generateFullArchitectComment(opportunityWithRelated, guidelinesText, options = {}) {
  const ctx = analyzer.analyzeContext(opportunityWithRelated);
  const tech = analyzer.analyzeTechnical(opportunityWithRelated);
  const engagement = analyzer.analyzeEngagement(opportunityWithRelated);
  const risks = analyzer.analyzeRisks(opportunityWithRelated);
  const score = opportunityWithRelated.IqScore ?? opportunityWithRelated["IqScore"];
  const tier = scoreTier(score);
  const stage = (opportunityWithRelated.StageName ?? "").trim();
  const guidelines = (guidelinesText ?? "").trim();

  const sections = [];

  // 1. Customer Context
  sections.push("**Customer Context**");
  const accountInfo = [opportunityWithRelated["Account.Name"], opportunityWithRelated["Account.Industry"], opportunityWithRelated["Account.Type"]].filter(Boolean).join(" · ") || "—";
  const customerContext = ctx.seComments !== "—"
    ? truncate(ctx.seComments, 150)
    : ctx.description !== "—"
    ? truncate(ctx.description, 150)
    : "No additional context available.";
  sections.push(`${accountInfo}. ${customerContext}`);

  // 2. Opportunity Summary
  sections.push("\n**Opportunity Summary**");
  sections.push(`${ctx.summary}.`);
  if (ctx.nextStep !== "—") sections.push(`Next step: ${truncate(ctx.nextStep, 100)}.`);

  // 3. Architectural Assessment
  sections.push("\n**Architectural Assessment**");
  const productLine = tech.productNames.length ? tech.productNames.join(", ") : tech.families.join(", ") || "—";
  sections.push(`Products: ${productLine}. Complexity: ${tech.complexity}.`);
  if (tech.keywords.length) sections.push(`Technical signals: ${tech.keywords.join(", ")}.`);
  sections.push(`Technical stakeholders: ${risks.technicalContacts.length ? risks.technicalContacts.join(", ") : "—"}.`);
  if (risks.hasPocValidation) sections.push("POC/validation language present; confirm scope and success criteria.");

  // 4. Competitive Landscape
  sections.push("\n**Competitive Landscape**");
  sections.push("No competitor data available in structured CRM data. Review with account team and flag if competitive displacement is in play.");

  // 5. Recommended Approach
  sections.push("\n**Recommended Approach**");
  if (ctx.nextStep !== "—") {
    sections.push(truncate(ctx.nextStep, 150));
  } else {
    sections.push("Engage technical stakeholders; align on solution scope and timeline.");
  }
  sections.push(`Engagement: ${engagement.taskCount} tasks, ${engagement.caseCount} cases, ${engagement.relatedOppCount} related opportunities on account.`);
  if (engagement.recentActivity !== "—") sections.push(`Recent activity: ${truncate(engagement.recentActivity, 80)}.`);

  // 6. Open Questions / Risks
  sections.push("\n**Open Questions / Risks**");
  if (risks.hasPocValidation) sections.push("POC/validation scope and success criteria not confirmed.");
  if (risks.stageVsProbability) sections.push(risks.stageVsProbability);
  sections.push(`Stage: ${stage || "—"}. Einstein Score: ${tier}.`);
  if (!risks.hasPocValidation && !risks.stageVsProbability) sections.push("Validate stage alignment and confirm next steps with account team.");
  if (guidelines) sections.push(`Guidelines: ${truncate(guidelines.split(/\r?\n/)[0] ?? "", 80)}.`);

  return sections.join(" ").replace(/\n\s*/g, "\n").trim();
}

/**
 * Produce a ≤240-character summary from the full comment (or from opportunity when full not provided).
 * Truncates at word boundary with "…" when over maxLength.
 *
 * @param {string} [fullComment] - If provided, distill from this
 * @param {import('./types.js').OpportunityWithRelated} [opportunityWithRelated] - Used when fullComment omitted
 * @param {string} [guidelinesText]
 * @param {{ maxLength?: number }} [options]
 * @returns {string} Summary ≤ maxLength (default 240)
 */
export function generateSummaryArchitectComment(fullComment, opportunityWithRelated, guidelinesText, options = {}) {
  const maxLen = options.maxLength ?? SUMMARY_MAX_LENGTH;
  if (fullComment && fullComment.length <= maxLen) return fullComment.replace(/\s+/g, " ").trim();
  if (fullComment) {
    const firstSentence = fullComment.replace(/\s+/g, " ").trim().split(/[.!?]/)[0] ?? "";
    const rest = fullComment.replace(/\s+/g, " ").trim();
    const take = rest.slice(0, maxLen - 1);
    const atWord = take.lastIndexOf(" ");
    const trimmed = atWord > maxLen / 2 ? take.slice(0, atWord) : take;
    return (trimmed + "…").trim();
  }
  if (opportunityWithRelated) {
    return generateArchitectComment(opportunityWithRelated, guidelinesText ?? "", { maxLength: maxLen });
  }
  return truncate("No summary available.", maxLen);
}

/**
 * Generate both full and summary architect comments for an opportunity with related data.
 *
 * @param {import('./types.js').OpportunityWithRelated} opportunityWithRelated
 * @param {string} guidelinesText
 * @param {{ maxLength?: number }} [options]
 * @returns {{ full: string, summary: string }}
 */
export function generateArchitectComments(opportunityWithRelated, guidelinesText, options = {}) {
  const full = generateFullArchitectComment(opportunityWithRelated, guidelinesText, options);
  const summary = generateSummaryArchitectComment(full, opportunityWithRelated, guidelinesText, options);
  return { full, summary };
}
