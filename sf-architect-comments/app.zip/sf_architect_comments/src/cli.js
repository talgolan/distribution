#!/usr/bin/env bun
/**
 * Architect Comments CLI – entry point.
 * Generates Architect_Comments__c for Opportunities from SE_Comments__c, scorecard, stage,
 * and guidelines; outputs a Data Loader–ready CSV. Uses only the unified Salesforce CLI (`sf`).
 * @module src/cli
 */

import { program } from "commander";
import { loadConfig } from "./config.js";
import { fetchOpportunities, fetchOpportunitiesWithRelated, fetchOpportunityById, fetchOpportunityWithRelatedById, verifySfLogin, loadOpportunitiesFromFile, writeOpportunitiesToFile } from "./sf.js";
import { fetchGuidelines, STUB_GUIDELINES } from "./guidelines.js";
import { generateArchitectComments } from "./generator.js";
import { generateArchitectCommentsWithLLM, verifyGateway } from "./llm.js";
import { buildCsv, writeCsvReport, writeFullCommentsJson } from "./csv.js";

program
  .name("architect-comments")
  .description("Generate Architect_Comments__c for Opportunities; output Data Loader CSV. Uses unified Salesforce CLI (sf) only.")
  .option("--dry-run", "Print proposed comments and lengths; write to a dry-run CSV instead of the main output path")
  .option("--only-verify-login", "First incremental test: confirm logged in to Salesforce CLI; exit after check")
  .option("--only-opportunities", "Test SF only: fetch opportunities and write JSON; do not fetch guidelines or generate comments")
  .option("--only-guidelines", "Test guidelines fetch only: fetch guidelines and write to output or stdout; do not call SF or generate")
  .option("--only-generate", "Test generator + CSV only: require --opportunities-file and guidelines (file/URL or --stub-guidelines); do not call SF")
  .option("--only-retrieve-opportunity", "Fetch a single opportunity by ID and output JSON; requires --opportunity-id. No guidelines or comment generation.")
  .option("--opportunities-file <path>", "Skip SF: load opportunities from JSON file (same shape as --only-opportunities output)")
  .option("--stub-guidelines", "Skip real guidelines: use built-in stub text instead of URL or file")
  .option("--guidelines-url <url>", "Google Doc URL or document ID for Architect guidelines (or set GUIDELINES_DOC_URL)")
  .option("--guidelines-file <path>", "Local file path for guidelines (override/fallback)")
  .option("--opportunity-owner-role-like <value>", "LIKE filter for Opportunity_Owner_Role__c in bulk retrieval (e.g. \"AMER - TMT - ENTR - MT - MTE%\")")
  .option("--owner-manager-names <names>", "Comma-separated Owner_Manager_Name__c values for bulk retrieval (e.g. \"Rachel McMahan,Mikel Linder\")")
  .option("--output <path>", "Path for the Data Loader CSV (default: architect_comments.csv)")
  .option("--output-full <path>", "Path for full architect comments JSON (default: architect_comments_full.json)")
  .option("--opportunity-id <id>", "Test full workflow for a single opportunity: fetch data, generate comments, print full and 240-char summary to stdout (no CSV/file output)")
  .option("--use-llm", "Use LLM via Engineering AI Model Gateway for comment generation; requires ENG_AI_MODEL_GW_KEY")
  .option("--json-output", "With --opportunity-id: output a JSON object {sections, summary} instead of human-readable text")
  .option("--target-org <alias>", "Salesforce CLI target org alias (passed to sf)")
  .option("--config <path>", "Path to JSON config file")
  .action(async (opts) => {
    const configPath = opts.config;
    const config = await loadConfig(configPath);

    // CLI overrides
    if (opts.guidelinesUrl) config.guidelinesUrl = opts.guidelinesUrl;
    if (opts.guidelinesFile) config.guidelinesFile = opts.guidelinesFile;
    if (opts.opportunityOwnerRoleLike) {
      config.opportunityOwnerRoleLike = String(opts.opportunityOwnerRoleLike).trim();
    }
    if (opts.ownerManagerNames) {
      config.ownerManagerNames = String(opts.ownerManagerNames)
        .split(",")
        .map((v) => v.trim())
        .filter(Boolean);
    }
    if (opts.output) config.outputPath = opts.output;
    if (opts.outputFull) config.outputFullPath = opts.outputFull;
    if (opts.targetOrg) config.targetOrg = opts.targetOrg;
    if (opts.useLlm !== undefined) config.useLlm = Boolean(opts.useLlm);

    const dryRun = Boolean(opts.dryRun);
    const onlyVerifyLogin = Boolean(opts.onlyVerifyLogin);
    const onlyOpportunities = Boolean(opts.onlyOpportunities);
    const onlyGuidelines = Boolean(opts.onlyGuidelines);
    const onlyGenerate = Boolean(opts.onlyGenerate);
    const onlyRetrieveOpportunity = Boolean(opts.onlyRetrieveOpportunity);
    const opportunitiesFile = opts.opportunitiesFile;
    const stubGuidelines = Boolean(opts.stubGuidelines);
    const opportunityId = opts.opportunityId?.trim();

    const onlyFlags = [onlyVerifyLogin, onlyOpportunities, onlyGuidelines, onlyGenerate, onlyRetrieveOpportunity].filter(Boolean);
    if (onlyFlags.length > 1) {
      console.error("Error: At most one of --only-verify-login, --only-opportunities, --only-guidelines, --only-generate, --only-retrieve-opportunity may be set.");
      process.exit(1);
    }
    if (onlyRetrieveOpportunity && !opportunityId) {
      console.error("Error: --only-retrieve-opportunity requires --opportunity-id.");
      process.exit(1);
    }
    if (opportunityId && onlyFlags.length > 0 && !onlyRetrieveOpportunity) {
      console.error("Error: --opportunity-id cannot be combined with --only-verify-login, --only-opportunities, --only-guidelines, or --only-generate.");
      process.exit(1);
    }
    const usesBulkSoql = onlyOpportunities || (!onlyVerifyLogin && !onlyGuidelines && !onlyGenerate && !onlyRetrieveOpportunity && !opportunityId && !opportunitiesFile);
    if (usesBulkSoql && (config.ownerManagerNames != null && (!Array.isArray(config.ownerManagerNames) || config.ownerManagerNames.length === 0))) {
      console.error("Error: owner manager names are empty. Provide --owner-manager-names or OWNER_MANAGER_NAMES with at least one value.");
      process.exit(1);
    }

    const useLlm = Boolean(config.useLlm);
    if (useLlm && (config.engAiModelGwKey ?? "").trim().length === 0) {
      console.error("Error: LLM generation requires ENG_AI_MODEL_GW_KEY.");
      process.exit(1);
    }

    /** @param {{ model: string, inputTokens: number, outputTokens: number, cached?: boolean }} usage */
    const logLlmUsage = (usage) => {
      const cached = usage.cached ? " (cached)" : "";
      console.error(`LLM model: ${usage.model}${cached}`);
      console.error(`Input tokens: ${usage.inputTokens}`);
      console.error(`Output tokens: ${usage.outputTokens}`);
    };

    /**
     * Run connectivity pre-flight checks in parallel before any real work.
     * Prints "Checking …" immediately, then "OK (…)" or "FAILED" on the same line.
     * Throws on the first failure; caught by the outer try/catch which exits with code 1.
     *
     * @param {{ sf: boolean, gateway: boolean }} flags
     */
    const runPreflightChecks = async ({ sf, gateway }) => {
      const checks = [];
      if (sf) {
        process.stderr.write("Checking Salesforce CLI authentication... ");
        checks.push(
          verifySfLogin({ targetOrg: config.targetOrg || undefined })
            .then(({ alias, username }) =>
              console.error(`OK (${alias}${username ? `, ${username}` : ""})`)
            )
            .catch((err) => {
              console.error("FAILED");
              throw err;
            })
        );
      }
      if (gateway) {
        process.stderr.write("Checking Engineering AI Model Gateway... ");
        checks.push(
          verifyGateway({ apiKey: config.engAiModelGwKey, baseUrl: config.engAiModelGwUrl, model: config.llmModel })
            .then(() => console.error("OK"))
            .catch((err) => {
              console.error("FAILED");
              throw err;
            })
        );
      }
      await Promise.all(checks);
    };

    const needsSf = !opportunitiesFile && !onlyGuidelines && !onlyGenerate && !onlyVerifyLogin;
    const needsGateway = useLlm && !onlyVerifyLogin && !onlyOpportunities && !onlyGuidelines && !onlyRetrieveOpportunity;

    try {
      if (needsSf || needsGateway) {
        await runPreflightChecks({ sf: needsSf, gateway: needsGateway });
      }
      if (onlyRetrieveOpportunity && opportunityId) {
        const opp = await fetchOpportunityById(opportunityId, {
          targetOrg: config.targetOrg || undefined,
        });
        if (!opp) {
          console.error(`Error: Opportunity not found: ${opportunityId}`);
          process.exit(1);
        }
        let outPath = config.outputPath;
        if (!outPath || !outPath.toLowerCase().endsWith(".json")) {
          outPath = `${opportunityId}.json`;
        }
        await writeOpportunitiesToFile([opp], outPath);
        console.log(`Wrote 1 opportunity to ${outPath}`);
        process.exit(0);
      }

      if (opportunityId) {
        if (!config.guidelinesUrl && !config.guidelinesFile && !stubGuidelines) {
          console.error("Error: For --opportunity-id provide --guidelines-url, --guidelines-file, or --stub-guidelines.");
          process.exit(1);
        }
        const fetchRelated = config.fetchRelatedData !== false;
        const caseField = config.caseOpportunityField ?? "";
        const oppWithRelated = await fetchOpportunityWithRelatedById(opportunityId, {
          targetOrg: config.targetOrg || undefined,
          fetchRelatedData: fetchRelated,
          caseOpportunityField: caseField,
        });
        if (!oppWithRelated) {
          console.error(`Error: Opportunity not found: ${opportunityId}`);
          process.exit(1);
        }
        const guidelinesText = stubGuidelines
          ? STUB_GUIDELINES
          : await fetchGuidelines({ url: config.guidelinesUrl, filePath: config.guidelinesFile });
        const result = useLlm
          ? await generateArchitectCommentsWithLLM(oppWithRelated, guidelinesText, {
              engAiModelGwKey: config.engAiModelGwKey,
              engAiModelGwUrl: config.engAiModelGwUrl,
              llmModel: config.llmModel,
              maxLength: config.maxCommentLength,
              llmCache: config.llmCache,
              llmCacheDir: config.llmCacheDir,
            })
          : generateArchitectComments(oppWithRelated, guidelinesText, { maxLength: config.maxCommentLength });
        const { full, summary } = result;
        if (result.usage) logLlmUsage(result.usage);
        if (opts.jsonOutput) {
          const jsonOut = { sections: result.sections ?? null, summary };
          if (useLlm && config.engAiModelGwUrl) jsonOut.gateway = config.engAiModelGwUrl;
          console.log(JSON.stringify(jsonOut, null, 2));
        } else {
          console.log("Full architect comment:\n");
          console.log(full);
          console.log("\n---\nSummary (≤240 chars):\n");
          console.log(summary);
        }
        process.exit(0);
      }

      if (onlyVerifyLogin) {
        const { alias, username } = await verifySfLogin({ targetOrg: config.targetOrg || undefined });
        console.log(`Logged in to Salesforce CLI. Org: ${alias}${username ? ` (${username})` : ""}`);
        process.exit(0);
      }

      if (onlyOpportunities) {
        const opportunities = await fetchOpportunities({
          targetOrg: config.targetOrg || undefined,
          closeDateFrom: config.closeDateFrom || undefined,
          closeDateTo: config.closeDateTo || undefined,
          opportunityOwnerRoleLike: config.opportunityOwnerRoleLike || undefined,
          ownerManagerNames: config.ownerManagerNames,
        });
        let outPath = config.outputPath;
        if (!outPath.endsWith(".json")) {
          console.warn(`Warning: output path "${outPath}" does not end in .json; writing to "opportunities.json" instead.`);
          outPath = "opportunities.json";
        }
        await writeOpportunitiesToFile(opportunities, outPath);
        console.log(`Wrote ${opportunities.length} opportunity(ies) to ${outPath}`);
        process.exit(0);
      }

      if (onlyGuidelines) {
        if (!config.guidelinesUrl && !config.guidelinesFile) {
          console.error("Error: For --only-guidelines provide --guidelines-url or --guidelines-file.");
          process.exit(1);
        }
        const text = await fetchGuidelines({ url: config.guidelinesUrl, filePath: config.guidelinesFile });
        if (config.outputPath) {
          const { writeFile } = await import("fs/promises");
          await writeFile(config.outputPath, text, "utf-8");
          console.log(`Wrote guidelines to ${config.outputPath}`);
        } else {
          console.log(text);
        }
        process.exit(0);
      }

      if (onlyGenerate) {
        if (!opportunitiesFile) {
          console.error("Error: --only-generate requires --opportunities-file <path>.");
          process.exit(1);
        }
        const hasGuidelines = config.guidelinesUrl || config.guidelinesFile || stubGuidelines;
        if (!hasGuidelines) {
          console.error("Error: --only-generate requires --guidelines-url, --guidelines-file, or --stub-guidelines.");
          process.exit(1);
        }
        const opportunities = await loadOpportunitiesFromFile(opportunitiesFile);
        const guidelinesText = stubGuidelines ? STUB_GUIDELINES : await fetchGuidelines({ url: config.guidelinesUrl, filePath: config.guidelinesFile });
        const withRelated = opportunities.map((opp) => ({ ...opp, lineItems: [], contactRoles: [], tasks: [], cases: [], relatedOpportunities: [] }));
        const rows = [];
        const fullEntries = [];
        const llmOpts = useLlm
          ? {
              engAiModelGwKey: config.engAiModelGwKey,
              engAiModelGwUrl: config.engAiModelGwUrl,
              llmModel: config.llmModel,
              maxLength: config.maxCommentLength,
              llmCache: config.llmCache,
              llmCacheDir: config.llmCacheDir,
            }
          : null;
        for (const opp of withRelated) {
          const genResult = llmOpts
            ? await generateArchitectCommentsWithLLM(opp, guidelinesText, llmOpts)
            : generateArchitectComments(opp, guidelinesText, { maxLength: config.maxCommentLength });
          const { full, summary } = genResult;
          if (genResult.usage) logLlmUsage(genResult.usage);
          rows.push({ Id: opp.Id, Architect_Comments__c: summary });
          fullEntries.push({ Id: opp.Id, Name: opp.Name, FullComment: full });
        }
        const csv = buildCsv(rows);
        const genOutPath = dryRun ? config.outputPath.replace(/\.csv$/i, "_dry_run.csv") : config.outputPath;
        await writeCsvReport(genOutPath, csv, rows, opportunities, { dryRun, verbose: true });
        const genFullPathBase = config.outputFullPath ?? "architect_comments_full.json";
        const genFullPath = dryRun ? genFullPathBase.replace(/\.json$/i, "_dry_run.json") : genFullPathBase;
        await writeFullCommentsJson(genFullPath, fullEntries, { verbose: true });
        process.exit(0);
      }

      // Full pipeline
      const useOpportunitiesFile = Boolean(opportunitiesFile);
      const useStubGuidelines = stubGuidelines;
      if (!useStubGuidelines && !config.guidelinesUrl && !config.guidelinesFile) {
        console.error("Error: Provide --guidelines-url, --guidelines-file, or --stub-guidelines (or set GUIDELINES_DOC_URL / GUIDELINES_FILE).");
        process.exit(1);
      }

      const fetchRelated = config.fetchRelatedData !== false;
      const caseField = config.caseOpportunityField ?? "";

      let opportunitiesWithRelated;
      if (useOpportunitiesFile) {
        const opportunities = await loadOpportunitiesFromFile(opportunitiesFile);
        opportunitiesWithRelated = opportunities.map((opp) => ({
          ...opp,
          lineItems: [],
          contactRoles: [],
          tasks: [],
          cases: [],
          relatedOpportunities: [],
        }));
      } else {
        opportunitiesWithRelated = await fetchOpportunitiesWithRelated({
          targetOrg: config.targetOrg || undefined,
          fetchRelatedData: fetchRelated,
          caseOpportunityField: caseField,
          closeDateFrom: config.closeDateFrom || undefined,
          closeDateTo: config.closeDateTo || undefined,
          opportunityOwnerRoleLike: config.opportunityOwnerRoleLike || undefined,
          ownerManagerNames: config.ownerManagerNames,
        });
      }

      const guidelinesText = useStubGuidelines
        ? STUB_GUIDELINES
        : await fetchGuidelines({ url: config.guidelinesUrl, filePath: config.guidelinesFile });

      const llmOpts = useLlm
        ? {
            engAiModelGwKey: config.engAiModelGwKey,
            engAiModelGwUrl: config.engAiModelGwUrl,
            llmModel: config.llmModel,
            maxLength: config.maxCommentLength,
            llmCache: config.llmCache,
            llmCacheDir: config.llmCacheDir,
          }
        : null;
      const rows = [];
      const fullEntries = [];
      for (const opp of opportunitiesWithRelated) {
        const genResult = llmOpts
          ? await generateArchitectCommentsWithLLM(opp, guidelinesText, llmOpts)
          : generateArchitectComments(opp, guidelinesText, { maxLength: config.maxCommentLength });
        const { full, summary } = genResult;
        if (genResult.usage) logLlmUsage(genResult.usage);
        rows.push({ Id: opp.Id, Architect_Comments__c: summary });
        fullEntries.push({ Id: opp.Id, Name: opp.Name, FullComment: full });
      }

      const csv = buildCsv(rows);
      const outPath = dryRun ? config.outputPath.replace(/\.csv$/i, "_dry_run.csv") : config.outputPath;
      await writeCsvReport(outPath, csv, rows, opportunitiesWithRelated, { dryRun, verbose: true });

      const fullPathBase = config.outputFullPath ?? "architect_comments_full.json";
      const fullPath = dryRun ? fullPathBase.replace(/\.json$/i, "_dry_run.json") : fullPathBase;
      await writeFullCommentsJson(fullPath, fullEntries, { verbose: true });
    } catch (err) {
      console.error("Error:", err.message);
      process.exit(1);
    }
  });

program.parse();
