/**
 * Fetch Architect guidelines from a Google Doc URL (export as text) or local file.
 * Uses Bun fetch() for URL; no Google API credentials if doc is shared "anyone with link".
 * @module src/guidelines
 */

import { readFile } from "fs/promises";

/** Stub guidelines text used when --stub-guidelines is set (incremental testing). */
export const STUB_GUIDELINES = "Stub guidelines for testing.";

/**
 * Extract document ID from a Google Doc URL.
 * @param {string} urlOrId - Full URL or document ID
 * @returns {string|null} Document ID or null
 */
export function extractDocId(urlOrId) {
  const trimmed = (urlOrId || "").trim();
  if (!trimmed) return null;
  const match = trimmed.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  if (/^[a-zA-Z0-9_-]+$/.test(trimmed)) return trimmed;
  return null;
}

/**
 * Fetch guidelines from a Google Doc URL (export as plain text).
 * Doc must be shared so the export link is accessible (e.g. "Anyone with the link").
 *
 * @param {string} urlOrId - Google Doc URL or document ID
 * @returns {Promise<string>} Plain text content
 */
export async function fetchGuidelinesFromUrl(urlOrId) {
  const docId = extractDocId(urlOrId);
  if (!docId) throw new Error("Invalid Google Doc URL or document ID");
  const exportUrl = `https://docs.google.com/document/d/${docId}/export?format=txt`;
  const res = await fetch(exportUrl);
  if (!res.ok) {
    throw new Error(`Failed to fetch guidelines (${res.status}). Ensure the doc is shared (e.g. Anyone with the link). Use --guidelines-file as fallback.`);
  }
  return res.text();
}

/**
 * Fetch guidelines from URL and/or local file. File is fallback if URL fails or is empty.
 *
 * @param {{ url?: string, filePath?: string }} options
 * @param {string} [options.url] - Google Doc URL or document ID
 * @param {string} [options.filePath] - Local file path (override/fallback)
 * @returns {Promise<string>} Guidelines text (trimmed)
 */
export async function fetchGuidelines(options = {}) {
  const { url, filePath } = options;

  if (filePath) {
    try {
      const content = await readFile(filePath, "utf-8");
      return content.trim();
    } catch (e) {
      if (!url) throw new Error(`Guidelines file not found: ${filePath}. ${e.message}`);
      // Fall through to URL
    }
  }

  if (url) {
    try {
      const content = await fetchGuidelinesFromUrl(url);
      return content.trim();
    } catch (e) {
      if (filePath) throw new Error(`Guidelines URL failed: ${e.message}. Tried file ${filePath} first.`);
      throw e;
    }
  }

  throw new Error("Provide guidelinesUrl or guidelinesFile.");
}
