/**
 * Load configuration from environment variables and optional config file.
 * Used by the Architect Comments CLI; no Salesforce credentials are stored here
 * (auth is via the unified Salesforce CLI `sf` only).
 * @module src/config
 */

/**
 * Default org ID for reference/filtering (not used for auth).
 * @constant
 */
export const DEFAULT_ORG_ID = "00D000000000062EAA";

/**
 * Default maximum length for Architect_Comments__c (Salesforce Long Text Area limit).
 * @constant
 */
export const DEFAULT_MAX_COMMENT_LENGTH = 240;

/**
 * Load merged config from env and optional config file.
 * Env vars override config file. No Salesforce credentials; only app options.
 *
 * @param {string} [configPath] - Optional path to JSON config file.
 * @returns {Promise<import('./types.js').Config>} Merged config object.
 */
export async function loadConfig(configPath) {
  const parseOwnerManagerNames = (value) => {
    if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean);
    if (typeof value === "string") {
      return value.split(",").map((v) => v.trim()).filter(Boolean);
    }
    return [];
  };

  const env = {
    guidelinesUrl: process.env.GUIDELINES_DOC_URL ?? process.env.GUIDELINES_URL ?? "",
    guidelinesFile: process.env.GUIDELINES_FILE ?? "",
    outputPath: process.env.OUTPUT_PATH ?? process.env.OUTPUT ?? "architect_comments.csv",
    outputFullPath: process.env.OUTPUT_FULL_PATH ?? process.env.OUTPUT_FULL ?? "architect_comments_full.json",
    targetOrg: process.env.SF_TARGET_ORG ?? process.env.TARGET_ORG ?? "",
    orgId: process.env.SF_ORG_ID ?? DEFAULT_ORG_ID,
    maxCommentLength: Number(process.env.MAX_COMMENT_LENGTH) || DEFAULT_MAX_COMMENT_LENGTH,
    fetchRelatedData: process.env.FETCH_RELATED_DATA !== "false",
    caseOpportunityField: process.env.CASE_OPPORTUNITY_FIELD ?? "",
    useLlm: process.env.USE_LLM === "true" || process.env.USE_LLM === "1",
    engAiModelGwKey: process.env.ENG_AI_MODEL_GW_KEY ?? "",
    engAiModelGwUrl: process.env.ENG_AI_MODEL_GW_URL ?? "https://eng-ai-model-gateway.sfproxy.devx-preprod.aws-esvc1-useast2.aws.sfdc.cl",
    llmModel: process.env.ENG_AI_MODEL ?? process.env.LLM_MODEL ?? "claude-sonnet-4-20250514",
    llmCache: process.env.LLM_CACHE !== "false" && process.env.LLM_CACHE !== "0",
    llmCacheDir: process.env.LLM_CACHE_DIR ?? ".llm-cache",
    closeDateFrom: process.env.CLOSE_DATE_FROM ?? "",
    closeDateTo: process.env.CLOSE_DATE_TO ?? "",
    opportunityOwnerRoleLike: process.env.OPPORTUNITY_OWNER_ROLE_LIKE ?? "",
    ownerManagerNames: parseOwnerManagerNames(process.env.OWNER_MANAGER_NAMES ?? ""),
  };

  if (!configPath) return env;

  try {
    const fs = await import("fs/promises");
    const raw = await fs.readFile(configPath, "utf-8");
    const file = JSON.parse(raw);
    return {
      guidelinesUrl: file.guidelinesUrl ?? file.guidelines_url ?? env.guidelinesUrl,
      guidelinesFile: file.guidelinesFile ?? file.guidelines_file ?? env.guidelinesFile,
      outputPath: file.outputPath ?? file.output_path ?? env.outputPath,
      outputFullPath: file.outputFullPath ?? file.output_full_path ?? env.outputFullPath,
      targetOrg: file.targetOrg ?? file.target_org ?? env.targetOrg,
      orgId: file.orgId ?? file.org_id ?? env.orgId,
      maxCommentLength: Number(file.maxCommentLength ?? file.max_comment_length) || env.maxCommentLength,
      fetchRelatedData: file.fetchRelatedData != null ? file.fetchRelatedData !== false : env.fetchRelatedData,
      caseOpportunityField: file.caseOpportunityField ?? file.case_opportunity_field ?? env.caseOpportunityField,
      useLlm: file.useLlm === true || file.use_llm === true || env.useLlm,
      engAiModelGwKey: file.engAiModelGwKey ?? file.eng_ai_model_gw_key ?? env.engAiModelGwKey,
      engAiModelGwUrl: file.engAiModelGwUrl ?? file.eng_ai_model_gw_url ?? env.engAiModelGwUrl,
      llmModel: file.llmModel ?? file.llm_model ?? env.llmModel,
      llmCache: file.llmCache != null ? file.llmCache !== false : env.llmCache,
      llmCacheDir: file.llmCacheDir ?? file.llm_cache_dir ?? env.llmCacheDir,
      closeDateFrom: file.closeDateFrom ?? file.close_date_from ?? env.closeDateFrom,
      closeDateTo: file.closeDateTo ?? file.close_date_to ?? env.closeDateTo,
      opportunityOwnerRoleLike: file.opportunityOwnerRoleLike ?? file.opportunity_owner_role_like ?? env.opportunityOwnerRoleLike,
      ownerManagerNames: parseOwnerManagerNames(
        file.ownerManagerNames ?? file.owner_manager_names ?? env.ownerManagerNames
      ),
    };
  } catch (e) {
    if (e.code === "ENOENT") return env;
    throw new Error(`Failed to load config from ${configPath}: ${e.message}`);
  }
}
