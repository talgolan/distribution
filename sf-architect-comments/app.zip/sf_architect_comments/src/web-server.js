#!/usr/bin/env bun
import { spawn, spawnSync } from "node:child_process";
import { mkdir, readdir, readFile, rm, unlink, writeFile } from "node:fs/promises";
import { basename, join, extname } from "node:path";
import { verifySfLogin, fetchOpportunityWithRelatedById } from "./sf.js";
import { verifyGateway } from "./llm.js";

const projectRoot = process.cwd();
const webRoot = join(projectRoot, "web");
const markdownScriptPath = join(projectRoot, "scripts", "opportunities-to-markdown.js");
const outputDir = join(projectRoot, "output");
const llmCacheDir = join(projectRoot, ".llm-cache");

const DEFAULT_GW_URL = "https://eng-ai-model-gateway.sfproxy.devx-preprod.aws-esvc1-useast2.aws.sfdc.cl";
const DEFAULT_MODEL = "gemini-3-flash-preview";

/**
 * Frozen snapshot of the system environment at startup.
 * Used to power "Reset to system defaults" and to display per-field override indicators.
 * Captured before any in-process mutations so it never changes.
 */
const SYSTEM_ENV = Object.freeze({
  engAiModelGwKey: process.env.ENG_AI_MODEL_GW_KEY ?? "",
  engAiModelGwUrl: process.env.ENG_AI_MODEL_GW_URL ?? DEFAULT_GW_URL,
  engAiModel: process.env.ENG_AI_MODEL ?? process.env.LLM_MODEL ?? DEFAULT_MODEL,
  // SF_TARGET_ORG: org alias/username passed to `sf org display --target-org`.
  // Required when no global default org is set in ~/.sf/config.json.
  sfTargetOrg: process.env.SF_TARGET_ORG ?? "",
  // NODE_EXTRA_CA_CERTS: path to a PEM file with additional CA certificates.
  // Populated at startup when the Tauri layer captures it from the user's shell;
  // can also be set manually via the Settings page for corporate VPN/proxy scenarios.
  nodeExtraCaCerts: process.env.NODE_EXTRA_CA_CERTS ?? "",
});

/**
 * Resolve a data file parameter to an absolute path.
 * Paths starting with "/" are used as-is (from the native file picker).
 * Relative paths are joined with projectRoot for dev-mode compatibility.
 * Returns null when no file is specified.
 * @param {string|null|undefined} fileParam
 * @returns {string|null}
 */
const resolveDataFile = (fileParam) => {
  const p = (fileParam ?? "").trim();
  if (!p) return null;
  if (p.startsWith("/")) return p;
  return join(projectRoot, p);
};
const port = Number(process.env.WEB_PORT || 3000);
const processJobs = new Map();
const encoder = new TextEncoder();
const activeMarkdownProcesses = new Set();
let isShuttingDown = false;

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
};

const jsonResponse = (status, payload) =>
  new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });

const sanitizePath = (pathname) => {
  if (!pathname || pathname === "/") return "index.html";
  const normalized = pathname.replace(/^\/+/, "");
  if (normalized.includes("..")) return null;
  return normalized;
};

const parseCacheUsed = (stderr) => /\(cached\)/i.test(String(stderr || ""));

const createJobId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

const emitJobEvent = (job, type, payload) => {
  const event = { type, payload, at: new Date().toISOString() };
  job.events.push(event);
  for (const send of [...job.subscribers]) {
    try {
      send(event);
    } catch {
      job.subscribers.delete(send);
    }
  }
};

const createJob = ({ ids, dataFilePath }) => {
  const jobId = createJobId();
  const job = {
    id: jobId,
    status: "queued",
    ids,
    dataFilePath,
    total: ids.length,
    completed: 0,
    currentId: null,
    results: [],
    events: [],
    subscribers: new Set(),
  };
  processJobs.set(jobId, job);
  return job;
};

const loadOpportunitiesFromFile = async (filePath) => {
  const raw = await readFile(filePath, "utf-8");
  const parsed = JSON.parse(raw);
  if (!Array.isArray(parsed)) {
    throw new Error("Opportunities file must contain a JSON array.");
  }
  return parsed;
};

const runMarkdownForOpportunity = async (opportunityId) => {
  const args = [
    "run",
    markdownScriptPath,
    "--opportunity-id",
    opportunityId,
  ];

  const startedAt = performance.now();
  // Build the child env explicitly so runtime mutations to process.env (via
  // POST /api/settings) are reliably forwarded to the grandchild cli.js process.
  const childEnv = {
    ...process.env,
    ...(process.env.ENG_AI_MODEL_GW_KEY && { ENG_AI_MODEL_GW_KEY: process.env.ENG_AI_MODEL_GW_KEY }),
    ...(process.env.ENG_AI_MODEL_GW_URL && { ENG_AI_MODEL_GW_URL: process.env.ENG_AI_MODEL_GW_URL }),
    ...(process.env.ENG_AI_MODEL && { ENG_AI_MODEL: process.env.ENG_AI_MODEL }),
    // NODE_EXTRA_CA_CERTS ensures child bun processes (cli.js) also trust the corporate
    // VPN CA — even when the value was set via the Settings page after server startup.
    ...(process.env.NODE_EXTRA_CA_CERTS && { NODE_EXTRA_CA_CERTS: process.env.NODE_EXTRA_CA_CERTS }),
  };
  const proc = spawn("bun", args, {
    cwd: projectRoot,
    env: childEnv,
    stdio: ["ignore", "pipe", "pipe"],
  });
  activeMarkdownProcesses.add(proc);

  let stdout = "";
  let stderr = "";

  proc.stdout.setEncoding("utf-8");
  proc.stderr.setEncoding("utf-8");
  proc.stdout.on("data", (chunk) => {
    stdout += chunk;
  });
  proc.stderr.on("data", (chunk) => {
    stderr += chunk;
  });

  const exitCode = await new Promise((resolve, reject) => {
    proc.on("error", reject);
    proc.on("close", resolve);
  });
  activeMarkdownProcesses.delete(proc);

  const durationMs = Math.round(performance.now() - startedAt);
  const markdownPath = join(outputDir, `${opportunityId}.md`);
  if (exitCode !== 0) {
    return {
      id: opportunityId,
      ok: false,
      durationMs,
      markdownPath,
      cacheUsed: parseCacheUsed(stderr),
      stdout: stdout.trim() || null,
      stderr: stderr.trim() || null,
      error: stderr.trim() || `CLI exited with code ${exitCode}`,
    };
  }

  return {
    id: opportunityId,
    ok: true,
    durationMs,
    markdownPath,
    cacheUsed: parseCacheUsed(stderr),
    stdout: stdout.trim() || null,
    stderr: stderr.trim() || null,
  };
};

const listProcessedMarkdownIds = async () => {
  try {
    const entries = await readdir(outputDir, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isFile() && entry.name.endsWith(".md"))
      .map((entry) => basename(entry.name, ".md"));
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return [];
    }
    throw error;
  }
};

const processJob = async (job) => {
  job.status = "running";
  emitJobEvent(job, "job-start", {
    jobId: job.id,
    total: job.total,
    completed: job.completed,
  });

  const dataFile = job.dataFilePath;
  let opportunities = [];
  try {
    opportunities = await loadOpportunitiesFromFile(dataFile);
  } catch (error) {
    job.status = "failed";
    emitJobEvent(job, "job-complete", {
      jobId: job.id,
      status: "failed",
      error: `Failed to load opportunities for processing: ${error.message}`,
      requested: job.total,
      successCount: 0,
      failureCount: job.total,
      results: [],
    });
    return;
  }

  await mkdir(outputDir, { recursive: true });
  const opportunitiesById = new Map(opportunities.map((opp) => [String(opp?.Id || ""), opp]));

  for (let i = 0; i < job.ids.length; i++) {
    const id = job.ids[i];
    job.currentId = id;
    emitJobEvent(job, "opportunity-start", {
      jobId: job.id,
      id,
      index: i + 1,
      total: job.total,
      completed: job.completed,
    });

    const opp = opportunitiesById.get(id);
    if (!opp) {
      const result = {
        id,
        ok: false,
        durationMs: 0,
        markdownPath: join(outputDir, `${id}.md`),
        cacheUsed: false,
        error: `Opportunity ${id} not found in ${job.dataFileInput}.`,
      };
      job.results.push(result);
      job.completed += 1;
      emitJobEvent(job, "opportunity-complete", {
        ...result,
        completed: job.completed,
        total: job.total,
      });
      continue;
    }

    const inputPath = join(projectRoot, `${id}.json`);
    await writeFile(inputPath, JSON.stringify([opp], null, 2), "utf-8");
    try {
      // eslint-disable-next-line no-await-in-loop
      const result = await runMarkdownForOpportunity(id);
      job.results.push(result);
      for (const [streamName, content] of [
        ["stderr", result.stderr],
        ["stdout", result.stdout],
      ]) {
        if (!content) continue;
        const lines = String(content).split("\n").filter(Boolean);
        for (const line of lines) {
          emitJobEvent(job, "opportunity-log", {
            id,
            stream: streamName,
            line,
          });
        }
      }
      job.completed += 1;
      emitJobEvent(job, "opportunity-complete", {
        ...result,
        completed: job.completed,
        total: job.total,
      });
    } finally {
      await unlink(inputPath).catch(() => {});
    }
  }

  job.status = "complete";
  const successCount = job.results.filter((r) => r.ok).length;
  emitJobEvent(job, "job-complete", {
    jobId: job.id,
    status: "complete",
    requested: job.total,
    successCount,
    failureCount: job.total - successCount,
    results: job.results,
  });
};

const server = Bun.serve({
  port,
  idleTimeout: 120,
  async fetch(req) {
    if (isShuttingDown) {
      return jsonResponse(503, { error: "Server is shutting down." });
    }
    const url = new URL(req.url);

    if (url.pathname === "/api/version" && req.method === "GET") {
      const versionFile = new URL("../VERSION", import.meta.url);
      const version = await Bun.file(versionFile).text().catch(() => "unknown");
      return new Response(JSON.stringify({ version: version.trim() }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    if (url.pathname === "/api/preflight" && req.method === "GET") {
      const sfOpts = process.env.SF_TARGET_ORG?.trim()
        ? { targetOrg: process.env.SF_TARGET_ORG.trim() }
        : {};
      const [sfResult, gatewayResult] = await Promise.allSettled([
        verifySfLogin(sfOpts),
        verifyGateway({
          apiKey: process.env.ENG_AI_MODEL_GW_KEY ?? "",
          baseUrl: process.env.ENG_AI_MODEL_GW_URL ?? DEFAULT_GW_URL,
          model: process.env.ENG_AI_MODEL ?? DEFAULT_MODEL,
        }),
      ]);
      return jsonResponse(200, {
        sf: sfResult.status === "fulfilled"
          ? { ok: true, org: sfResult.value.alias, username: sfResult.value.username }
          : { ok: false, error: sfResult.reason?.message ?? "Unknown error" },
        gateway: gatewayResult.status === "fulfilled"
          ? { ok: true }
          : { ok: false, error: gatewayResult.reason?.message ?? "Unknown error" },
      });
    }

    if (url.pathname === "/api/settings" && req.method === "GET") {
      return jsonResponse(200, {
        system: {
          engAiModelGwKeySet: !!SYSTEM_ENV.engAiModelGwKey,
          engAiModelGwUrl: SYSTEM_ENV.engAiModelGwUrl,
          engAiModel: SYSTEM_ENV.engAiModel,
          sfTargetOrg: SYSTEM_ENV.sfTargetOrg,
          nodeExtraCaCerts: SYSTEM_ENV.nodeExtraCaCerts,
        },
        active: {
          engAiModelGwKeySet: !!(process.env.ENG_AI_MODEL_GW_KEY ?? ""),
          engAiModelGwUrl: process.env.ENG_AI_MODEL_GW_URL ?? SYSTEM_ENV.engAiModelGwUrl,
          engAiModel: process.env.ENG_AI_MODEL ?? SYSTEM_ENV.engAiModel,
          sfTargetOrg: process.env.SF_TARGET_ORG ?? SYSTEM_ENV.sfTargetOrg,
          nodeExtraCaCerts: process.env.NODE_EXTRA_CA_CERTS ?? SYSTEM_ENV.nodeExtraCaCerts,
        },
      });
    }

    if (url.pathname === "/api/settings" && req.method === "POST") {
      let body;
      try { body = await req.json(); } catch { return jsonResponse(400, { error: "Invalid JSON." }); }
      // Apply each field. Empty string reverts a field to its system default.
      if (typeof body.engAiModelGwKey === "string" && body.engAiModelGwKey.trim()) {
        process.env.ENG_AI_MODEL_GW_KEY = body.engAiModelGwKey.trim();
      }
      if (typeof body.engAiModelGwUrl === "string") {
        process.env.ENG_AI_MODEL_GW_URL = body.engAiModelGwUrl.trim() || SYSTEM_ENV.engAiModelGwUrl;
      }
      if (typeof body.engAiModel === "string") {
        process.env.ENG_AI_MODEL = body.engAiModel.trim() || SYSTEM_ENV.engAiModel;
      }
      if (typeof body.sfTargetOrg === "string") {
        process.env.SF_TARGET_ORG = body.sfTargetOrg.trim();
      }
      if (typeof body.nodeExtraCaCerts === "string") {
        process.env.NODE_EXTRA_CA_CERTS = body.nodeExtraCaCerts.trim();
      }
      return jsonResponse(200, { ok: true });
    }

    if (url.pathname === "/api/settings/reset" && req.method === "POST") {
      process.env.ENG_AI_MODEL_GW_KEY = SYSTEM_ENV.engAiModelGwKey;
      process.env.ENG_AI_MODEL_GW_URL = SYSTEM_ENV.engAiModelGwUrl;
      process.env.ENG_AI_MODEL = SYSTEM_ENV.engAiModel;
      process.env.SF_TARGET_ORG = SYSTEM_ENV.sfTargetOrg;
      process.env.NODE_EXTRA_CA_CERTS = SYSTEM_ENV.nodeExtraCaCerts;
      return jsonResponse(200, { ok: true });
    }

    if (url.pathname === "/api/browse" && req.method === "POST") {
      // Use AppleScript's choose file dialog — works on macOS without any plugin.
      const script = `POSIX path of (choose file with prompt "Select opportunities JSON file" of type {"public.json"} without invisibles)`;
      const r = spawnSync("osascript", ["-e", script]);
      if (r.status === 0 && r.stdout) {
        return jsonResponse(200, { path: r.stdout.toString().trim() });
      }
      // User cancelled the dialog.
      return new Response(null, { status: 204 });
    }

    if (url.pathname === "/api/opportunities" && req.method === "GET") {
      const dataFile = resolveDataFile(url.searchParams.get("file"));
      if (!dataFile) {
        return jsonResponse(400, { error: "No data file selected. Use the Browse button to choose a JSON file." });
      }
      try {
        const parsed = await loadOpportunitiesFromFile(dataFile);
        return jsonResponse(200, {
          source: dataFile,
          count: parsed.length,
          opportunities: parsed,
        });
      } catch (error) {
        return jsonResponse(500, {
          error: `Failed to load opportunities: ${error.message}`,
        });
      }
    }

    if (url.pathname === "/api/process-by-sfid" && req.method === "POST") {
      let body;
      try {
        body = await req.json();
      } catch {
        return jsonResponse(400, { error: "Request body must be valid JSON." });
      }

      const opportunityId = String(body?.opportunityId || "").trim();
      if (!opportunityId) {
        return jsonResponse(400, { error: "Provide a non-empty opportunityId." });
      }
      if (!process.env.ENG_AI_MODEL_GW_KEY?.trim()) {
        return jsonResponse(400, {
          error: "API key not configured. Open \u2699 Settings and enter your Engineering AI Gateway key, then try again.",
        });
      }

      // Fetch live from Salesforce — this is what differentiates this endpoint from
      // the batch flow, which reads from a pre-loaded JSON file.
      let oppWithRelated;
      try {
        const targetOrg = process.env.SF_TARGET_ORG?.trim() || undefined;
        oppWithRelated = await fetchOpportunityWithRelatedById(opportunityId, { targetOrg });
      } catch (err) {
        return jsonResponse(502, { error: `Salesforce fetch failed: ${err.message}` });
      }
      if (!oppWithRelated) {
        return jsonResponse(404, { error: `Opportunity ${opportunityId} not found in your Salesforce org.` });
      }

      // Write to the same temp-file slot the batch flow uses, then hand off to the
      // existing job pipeline which reads it back via loadOpportunitiesFromFile.
      const dataFilePath = join(projectRoot, `${opportunityId}.json`);
      await writeFile(dataFilePath, JSON.stringify([oppWithRelated], null, 2), "utf-8");

      const job = createJob({ ids: [opportunityId], dataFilePath });
      processJob(job).catch((error) => {
        job.status = "failed";
        emitJobEvent(job, "job-complete", {
          jobId: job.id,
          status: "failed",
          error: `Unexpected processing failure: ${error.message}`,
          requested: 1,
          successCount: 0,
          failureCount: 1,
          results: job.results,
        });
      });
      return jsonResponse(200, { jobId: job.id, opportunityId, requested: 1 });
    }

    if (url.pathname === "/api/process" && req.method === "POST") {
      let body;
      try {
        body = await req.json();
      } catch {
        return jsonResponse(400, { error: "Request body must be valid JSON." });
      }

      const ids = Array.isArray(body?.ids)
        ? body.ids.map((v) => String(v).trim()).filter(Boolean)
        : [];
      const dataFilePath = resolveDataFile(String(body?.dataFile || "").trim());
      if (!ids.length) {
        return jsonResponse(400, { error: "Provide a non-empty ids array." });
      }
      if (!dataFilePath) {
        return jsonResponse(400, { error: "No data file specified." });
      }
      if (!process.env.ENG_AI_MODEL_GW_KEY?.trim()) {
        return jsonResponse(400, {
          error: "API key not configured. Open \u2699 Settings and enter your Engineering AI Gateway key, then try again.",
        });
      }

      const job = createJob({ ids, dataFilePath });
      processJob(job).catch((error) => {
        job.status = "failed";
        emitJobEvent(job, "job-complete", {
          jobId: job.id,
          status: "failed",
          error: `Unexpected processing failure: ${error.message}`,
          requested: job.total,
          successCount: job.results.filter((r) => r.ok).length,
          failureCount: job.total - job.results.filter((r) => r.ok).length,
          results: job.results,
        });
      });
      return jsonResponse(200, {
        jobId: job.id,
        requested: ids.length,
      });
    }

    if (url.pathname === "/api/cache/clear" && req.method === "POST") {
      let body;
      try {
        body = await req.json();
      } catch {
        return jsonResponse(400, { error: "Request body must be valid JSON." });
      }

      const dataFile = resolveDataFile(String(body?.dataFile || "").trim());
      if (!dataFile) {
        return jsonResponse(400, { error: "No data file specified." });
      }
      let opportunities = [];
      try {
        opportunities = await loadOpportunitiesFromFile(dataFile);
      } catch (error) {
        return jsonResponse(500, {
          error: `Failed to load opportunities for cache clear: ${error.message}`,
        });
      }

      const sourceIds = opportunities.map((opp) => String(opp?.Id || "")).filter(Boolean);
      const sourceIdSet = new Set(sourceIds);

      let llmDeletedCount = 0;
      try {
        const entries = await readdir(llmCacheDir, { withFileTypes: true });
        for (const entry of entries) {
          const isMatch = [...sourceIdSet].some((id) => entry.name.startsWith(`${id}_`));
          if (!isMatch) continue;
          const target = join(llmCacheDir, entry.name);
          await rm(target, { recursive: true, force: true });
          llmDeletedCount += 1;
        }
      } catch (error) {
        if (!(error && typeof error === "object" && "code" in error && error.code === "ENOENT")) {
          return jsonResponse(500, { error: `Failed to clear llm cache: ${error.message}` });
        }
      }

      let markdownDeletedCount = 0;
      let markdownFiles = new Set();
      try {
        const outputEntries = await readdir(outputDir, { withFileTypes: true });
        markdownFiles = new Set(
          outputEntries
            .filter((entry) => entry.isFile() && entry.name.endsWith(".md"))
            .map((entry) => entry.name)
        );
      } catch (error) {
        if (!(error && typeof error === "object" && "code" in error && error.code === "ENOENT")) {
          return jsonResponse(500, { error: `Failed to inspect markdown cache: ${error.message}` });
        }
      }
      for (const id of sourceIds) {
        const fileName = `${id}.md`;
        if (!markdownFiles.has(fileName)) continue;
        const markdownPath = join(outputDir, fileName);
        try {
          await rm(markdownPath, { force: true });
          markdownDeletedCount += 1;
        } catch (error) {
          return jsonResponse(500, { error: `Failed to clear markdown cache: ${error.message}` });
        }
      }

      return jsonResponse(200, {
        ok: true,
        source: dataFile,
        idsConsidered: sourceIds.length,
        sourceIds,
        llmDeletedCount,
        markdownDeletedCount,
      });
    }

    if (url.pathname === "/api/processed" && req.method === "GET") {
      const dataFile = resolveDataFile(url.searchParams.get("file"));
      if (!dataFile) {
        return jsonResponse(400, { error: "No data file specified." });
      }
      let opportunities = [];
      try {
        opportunities = await loadOpportunitiesFromFile(dataFile);
      } catch (error) {
        return jsonResponse(500, {
          error: `Failed to load opportunities for processed lookup: ${error.message}`,
        });
      }

      const processedIds = new Set(await listProcessedMarkdownIds());
      const results = opportunities
        .filter((opp) => processedIds.has(String(opp?.Id || "")))
        .map((opp) => ({
          id: String(opp?.Id || ""),
          ok: true,
          durationMs: 0,
          cacheUsed: true,
          markdownPath: join(outputDir, `${String(opp?.Id || "")}.md`),
          preexisting: true,
        }));

      return jsonResponse(200, {
        source: dataFile,
        count: results.length,
        results,
      });
    }

    const streamMatch = url.pathname.match(/^\/api\/process\/([^/]+)\/stream$/);
    if (streamMatch && req.method === "GET") {
      const jobId = decodeURIComponent(streamMatch[1]);
      const job = processJobs.get(jobId);
      if (!job) {
        return jsonResponse(404, { error: `Processing job not found: ${jobId}` });
      }

      const stream = new ReadableStream({
        // Assigned in start() so cancel() can cleanup safely.
        // eslint-disable-next-line no-empty-function
        _cleanup: () => {},
        start(controller) {
          let closed = false;
          let heartbeat = null;

          const closeStream = () => {
            if (closed) return;
            closed = true;
            if (heartbeat) clearInterval(heartbeat);
            job.subscribers.delete(send);
            try {
              controller.close();
            } catch {
              // Ignore close races.
            }
          };
          this._cleanup = closeStream;

          const send = (event) => {
            if (closed) return;
            const chunk = `event: ${event.type}\ndata: ${JSON.stringify(event.payload)}\n\n`;
            try {
              controller.enqueue(encoder.encode(chunk));
            } catch {
              closeStream();
              throw new Error("SSE stream closed");
            }
          };

          for (const event of job.events) send(event);
          job.subscribers.add(send);

          // Keep SSE alive while idle; Bun defaults to 10s timeout.
          heartbeat = setInterval(() => {
            if (closed) return;
            try {
              controller.enqueue(encoder.encode("event: ping\ndata: {}\n\n"));
            } catch {
              closeStream();
            }
          }, 8000);

          if (job.status === "complete" || job.status === "failed") {
            const doneChunk = "event: stream-end\ndata: {}\n\n";
            try {
              controller.enqueue(encoder.encode(doneChunk));
            } catch {
              // Ignore if already closed.
            }
            closeStream();
          }
        },
        cancel() {
          this._cleanup();
        },
      });

      return new Response(stream, {
        headers: {
          "content-type": "text/event-stream; charset=utf-8",
          "cache-control": "no-cache, no-transform",
          connection: "keep-alive",
        },
      });
    }

    if (url.pathname.startsWith("/api/markdown/") && req.method === "GET") {
      const opportunityId = decodeURIComponent(url.pathname.slice("/api/markdown/".length)).trim();
      if (!opportunityId) {
        return jsonResponse(400, { error: "Missing opportunity id." });
      }

      const markdownPath = join(outputDir, `${opportunityId}.md`);
      try {
        const markdown = await readFile(markdownPath, "utf-8");
        return jsonResponse(200, {
          id: opportunityId,
          path: markdownPath,
          markdown,
        });
      } catch (error) {
        return jsonResponse(404, {
          id: opportunityId,
          path: markdownPath,
          error: `Markdown file not found or unreadable: ${error.message}`,
        });
      }
    }

    const safePath = sanitizePath(url.pathname);
    if (!safePath) {
      return new Response("Invalid path", { status: 400 });
    }

    const filePath = join(webRoot, safePath);
    try {
      const file = await Bun.file(filePath).arrayBuffer();
      const contentType = mimeTypes[extname(filePath)] || "application/octet-stream";
      return new Response(file, {
        status: 200,
        headers: { "content-type": contentType },
      });
    } catch {
      if (!safePath.endsWith(".html")) {
        return new Response("Not found", { status: 404 });
      }
      const fallback = await Bun.file(join(webRoot, "index.html")).arrayBuffer();
      return new Response(fallback, {
        status: 200,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
});

console.log(`Web GUI running at http://localhost:${server.port}`);

const shutdown = (signal) => {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log(`Received ${signal}, shutting down web server...`);

  for (const proc of [...activeMarkdownProcesses]) {
    try {
      proc.kill("SIGTERM");
    } catch {
      // Ignore process termination errors during shutdown.
    }
  }

  try {
    server.stop(true);
  } catch {
    // Ignore stop errors and exit anyway.
  }
  process.exit(0);
};

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
