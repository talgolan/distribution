/**
 * Build Data Loader–ready CSV (Id, Architect_Comments__c) and write dry-run or final report.
 * @module src/csv
 */

import { writeFile } from "fs/promises";

const CSV_HEADERS = ["Id", "Architect_Comments__c"];

/**
 * Escape a CSV field (quote if contains comma, newline, or quote).
 *
 * @param {string} value
 * @returns {string}
 */
function escapeCsvField(value) {
  const s = String(value ?? "");
  if (s.includes(",") || s.includes("\n") || s.includes("\r") || s.includes('"')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

/**
 * Build CSV string from rows (Data Loader format: Id, Architect_Comments__c).
 *
 * @param {import('./types.js').DataLoaderRow[]} rows
 * @returns {string}
 */
export function buildCsv(rows) {
  const header = CSV_HEADERS.join(",");
  const body = rows.map((r) => CSV_HEADERS.map((h) => escapeCsvField(r[h])).join(",")).join("\n");
  return `${header}\n${body}`;
}

/**
 * Write CSV to file and optionally print a dry-run report (Id, Name, Account.Name, comment, length).
 *
 * @param {string} outPath - File path for CSV
 * @param {string} csv - Full CSV content
 * @param {Array<{ Id: string, Architect_Comments__c: string }>} rows - Data Loader rows
 * @param {Array<{ Id: string, Name?: string, 'Account.Name'?: string }>} [opportunities] - Full opportunities for dry-run report
 * @param {{ dryRun?: boolean, verbose?: boolean }} [options]
 */
export async function writeCsvReport(outPath, csv, rows, opportunities = [], options = {}) {
  const { dryRun = false, verbose = true } = options;
  await writeFile(outPath, csv, "utf-8");
  if (verbose) {
    if (dryRun && rows.length > 0) {
      console.log("Dry run – proposed Architect_Comments__c (length):");
      const byId = new Map((opportunities || []).map((o) => [o.Id, o]));
      for (const r of rows) {
        const opp = byId.get(r.Id);
        const name = opp?.Name ?? "";
        const accName = opp?.["Account.Name"] ?? "";
        const len = (r.Architect_Comments__c ?? "").length;
        const preview = (r.Architect_Comments__c ?? "").slice(0, 60);
        console.log(`  ${r.Id}  ${name || "-"}  ${accName || "-"}  ${len} chars  ${preview}${len > 60 ? "…" : ""}`);
      }
    }
    console.log(`Wrote ${rows.length} row(s) to ${outPath}`);
  }
}

/**
 * Write full architect comments to a JSON file (array of { Id, Name?, FullComment }).
 *
 * @param {string} outPath - File path for JSON
 * @param {Array<{ Id: string, Name?: string, FullComment: string }>} entries
 * @param {{ verbose?: boolean }} [options]
 * @returns {Promise<void>}
 */
export async function writeFullCommentsJson(outPath, entries, options = {}) {
  const { verbose = true } = options;
  const payload = JSON.stringify(entries, null, 2);
  await writeFile(outPath, payload, "utf-8");
  if (verbose) {
    console.log(`Wrote ${entries.length} full comment(s) to ${outPath}`);
  }
}
