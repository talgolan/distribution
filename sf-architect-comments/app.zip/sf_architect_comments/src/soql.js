/**
 * SOQL query builders for opportunities (unified sf CLI only; no sfdx).
 * Main query is built via buildOpportunitiesSoql() to allow date and role overrides.
 * @module src/soql
 */

const DEFAULT_OWNER_ROLE_LIKE = "AMER - TMT - ENTR - MT - MTE%";
const DEFAULT_OWNER_MANAGER_NAMES = [
  "Rachel McMahan",
  "Mikel Linder",
  "Joshua Whitham",
  "Brandon Douglas",
  "Michael McTigue",
];

function escapeSoqlString(value) {
  return String(value ?? "").replace(/'/g, "''").trim();
}

function quoteSoqlString(value) {
  return `'${escapeSoqlString(value)}'`;
}

/**
 * Build the core opportunities SOQL for bulk retrieval.
 * Defaults to THIS_FISCAL_YEAR, role prefix 'AMER - TMT - ENTR - MT - MTE%',
 * and a default manager list.
 *
 * @param {{ opportunityOwnerRoleLike?: string, ownerManagerNames?: string[] }} [options]
 * @returns {string} SOQL string
 */
export function buildOpportunitiesSoql(options = {}) {
  const roleLike = escapeSoqlString(options.opportunityOwnerRoleLike || DEFAULT_OWNER_ROLE_LIKE);
  const ownerManagerNames = Array.isArray(options.ownerManagerNames) && options.ownerManagerNames.length > 0
    ? options.ownerManagerNames.map((n) => String(n).trim()).filter(Boolean)
    : DEFAULT_OWNER_MANAGER_NAMES;
  if (!ownerManagerNames.length) {
    throw new Error("At least one Owner_Manager_Name__c value is required for bulk retrieval.");
  }
  const ownerManagerInList = ownerManagerNames.map(quoteSoqlString).join(", ");

  return `
SELECT Id, Name, IqScore, IsClosed, IsWon, StageName, Owner.Name, Account.Id, Account.Industry, Account.Type, Account.Combo_Company__c, Account.Name,
       Owner.Id, Owner_Manager_Name__c, CloseDate, AmountConverted__c, SE_Comments__c, SE_Next_Steps__c, Architect_Comments__c,
       Type, LastModifiedDate, LastModifiedBy.Name, EBR_Manager_Notes__c, Specialist_Sales_Notes__c, Competitive_Notes__c,
       SEM_Notes__c, IBU_Next_Steps_Notes__c, Manager_Notes__c, Opportunity_Owner_Role__c
FROM Opportunity
WHERE Opportunity_Owner_Role__c LIKE '${roleLike}'
  AND CloseDate = THIS_FISCAL_YEAR
  AND AmountConverted__c > 0
  AND Owner_Manager_Name__c IN (${ownerManagerInList})
  AND IsClosed = false
  AND StageName NOT IN ('Dead - Duplicate','Dead - No Opportunity','Dead - No Decision','Dead - Webstore','Dead - Lost','Dead - OEM','01 - Identifying an Opportunity')
ORDER BY Owner_Manager_Name__c, CloseDate, AmountConverted__c DESC`.replace(/\n/g, " ").trim();
}
//AND (Architect_Comments__c = null OR Architect_Comments__c = '')

/**
 * Default opportunities SOQL computed with default options at module load time.
 * Exported for backward compatibility; prefer buildOpportunitiesSoql() where config is available.
 */
export const OPPORTUNITIES_SOQL = buildOpportunitiesSoql();

/** SELECT clause (same fields as main query) for reuse in single-opportunity query. */
const OPPORTUNITY_SELECT_CLAUSE = `
SELECT Id, Name, AccountId, Account.Name, Account.Industry, Account.Type, Amount, CloseDate, StageName, Type, Owner.Name,
       SE_Comments__c, Architect_Comments__c, Opportunity_Owner_Role__c, IqScore,
       Description, NextStep, LeadSource, IsClosed, IsWon, Probability, CreatedDate, LastModifiedDate
FROM Opportunity
`.replace(/\n/g, " ").trim();

/**
 * SOQL for a single opportunity by Id (same fields as buildOpportunitiesSoql output).
 *
 * @param {string} opportunityId - Salesforce Opportunity Id (e.g. 006ed00000TwuE1AAJ)
 * @returns {string} SOQL string
 */
export function getOpportunityByIdSoql(opportunityId) {
  const id = String(opportunityId ?? "").replace(/'/g, "''");
  if (!id) throw new Error("Opportunity Id is required.");
  return `${OPPORTUNITY_SELECT_CLAUSE} WHERE Id = '${id}'`;
}
