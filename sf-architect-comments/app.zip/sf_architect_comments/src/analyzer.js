/**
 * Pure analysis helpers for architect comment generation.
 * Derive structured snippets (context, technical, engagement, risks) from OpportunityWithRelated.
 * @module src/analyzer
 */

/**
 * @param {import('./types.js').OpportunityWithRelated} opp
 * @returns {{ summary: string, account: string, owner: string, contacts: string[], seComments: string, description: string, nextStep: string }}
 */
export function analyzeContext(opp) {
  const name = opp.Name ?? "Opportunity";
  const amount = opp.Amount != null ? `$${Number(opp.Amount).toLocaleString()}` : "";
  const stage = opp.StageName ?? "";
  const type = opp.Type ?? "";
  const products = (opp.lineItems ?? [])
    .map((li) => li["Product2.Name"] ?? li["Product2.Family"])
    .filter(Boolean);
  const productList = [...new Set(products)].slice(0, 5).join(", ") || "—";

  const account = [opp["Account.Name"], opp["Account.Industry"], opp["Account.Type"]].filter(Boolean).join(" · ") || "—";
  const owner = opp["Owner.Name"] ?? "—";
  const contactRoles = (opp.contactRoles ?? []).map((cr) => {
    const name = cr["Contact.Name"] ?? "";
    const role = cr.Role ?? "";
    return role ? `${name} (${role})` : name;
  }).filter(Boolean);
  const contacts = contactRoles.length ? contactRoles : ["—"];

  const seComments = (opp.SE_Comments__c ?? "").trim() || "—";
  const description = (opp.Description ?? "").trim() || "—";
  const nextStep = (opp.NextStep ?? "").trim() || "—";

  const summary = [name, amount, stage, type, productList].filter(Boolean).join(" | ");
  return { summary, account, owner, contacts, seComments, description, nextStep };
}

/**
 * @param {import('./types.js').OpportunityWithRelated} opp
 * @returns {{ productNames: string[], families: string[], keywords: string[], complexity: string }}
 */
export function analyzeTechnical(opp) {
  const lineItems = opp.lineItems ?? [];
  const productNames = [...new Set(lineItems.map((li) => li["Product2.Name"]).filter(Boolean))];
  const families = [...new Set(lineItems.map((li) => li["Product2.Family"]).filter(Boolean))];
  const text = [
    opp.SE_Comments__c ?? "",
    opp.Description ?? "",
    ...lineItems.map((li) => li.Description ?? ""),
  ].join(" ");
  const keywords = ["POC", "validation", "routing", "sandbox", "integration", "API", "migration", "security"]
    .filter((k) => text.toLowerCase().includes(k.toLowerCase()));
  const complexity = productNames.length > 2 || families.length > 1 ? "High" : productNames.length > 0 ? "Medium" : "Standard";
  return { productNames, families, keywords, complexity };
}

/**
 * @param {import('./types.js').OpportunityWithRelated} opp
 * @returns {{ taskCount: number, recentActivity: string, caseCount: number, relatedOppCount: number }}
 */
export function analyzeEngagement(opp) {
  const tasks = opp.tasks ?? [];
  const taskCount = tasks.length;
  const recent = tasks.slice(0, 3).map((t) => t.Subject ?? t.Type ?? "Activity").filter(Boolean);
  const recentActivity = recent.length ? recent.join("; ") : "—";
  const caseCount = (opp.cases ?? []).length;
  const relatedOppCount = (opp.relatedOpportunities ?? []).length;
  return { taskCount, recentActivity, caseCount, relatedOppCount };
}

/**
 * @param {import('./types.js').OpportunityWithRelated} opp
 * @returns {{ hasPocValidation: boolean, stageVsProbability: string, technicalContacts: string[] }}
 */
export function analyzeRisks(opp) {
  const text = [opp.SE_Comments__c ?? "", opp.Description ?? ""].join(" ").toLowerCase();
  const hasPocValidation = /poc|proof of concept|validation|pilot/.test(text);
  const stage = opp.StageName ?? "";
  const prob = opp.Probability;
  let stageVsProbability = "";
  if (typeof prob === "number" && stage) {
    if (stage.includes("Validating") && prob < 40) stageVsProbability = "Stage suggests validation; probability still moderate.";
    else if (stage.includes("Negotiating") && prob < 60) stageVsProbability = "Negotiation stage; confirm probability alignment.";
  }
  const technicalRoles = (opp.contactRoles ?? [])
    .filter((cr) => /architect|engineer|technical|cto|vp engineering/i.test((cr.Role ?? "") + (cr["Contact.Title"] ?? "")))
    .map((cr) => cr["Contact.Name"] ?? cr.Role ?? "")
    .filter(Boolean);
  return { hasPocValidation, stageVsProbability, technicalContacts: technicalRoles };
}
