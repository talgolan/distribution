/**
 * SOQL builders for related data (LineItems, ContactRoles, Tasks, Cases, Related Opportunities).
 * Queries use IN (...) placeholders; callers pass ID lists and optional config (e.g. Case lookup field).
 * @module src/soql-related
 */

const CHUNK_SIZE = 50;

/** Max rows to fetch for tasks per batch (CHUNK_SIZE × tasks kept per opportunity). */
const TASK_LIMIT = 1000;

/** Max rows to fetch for related opportunities per batch (CHUNK_SIZE × opps kept per account). */
const RELATED_OPP_LIMIT = 500;

/**
 * Escape a value for use inside a SOQL single-quoted string literal.
 * @param {string} s
 * @returns {string}
 */
function escapeSoqlString(s) {
  return String(s).replace(/'/g, "''");
}

/**
 * Build SOQL for OpportunityLineItem by OpportunityId set. Run in chunks to avoid URL length limits.
 *
 * @param {string[]} opportunityIds - Up to CHUNK_SIZE IDs
 * @returns {string} SOQL string
 */
export function soqlLineItems(opportunityIds) {
  if (!opportunityIds?.length) return "";
  const inList = opportunityIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ");
  return `SELECT Id, OpportunityId, Product2.Name, Product2.Family, Quantity, UnitPrice, TotalPrice, Description FROM OpportunityLineItem WHERE OpportunityId IN (${inList})`.trim();
}

/**
 * Build SOQL for OpportunityContactRole by OpportunityId set.
 *
 * @param {string[]} opportunityIds
 * @returns {string} SOQL string
 */
export function soqlContactRoles(opportunityIds) {
  if (!opportunityIds?.length) return "";
  const inList = opportunityIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ");
  return `SELECT Id, OpportunityId, Role, Contact.Name, Contact.Title, IsPrimary FROM OpportunityContactRole WHERE OpportunityId IN (${inList})`.trim();
}

/**
 * Build SOQL for Task by WhatId (Opportunity). Application-side limit (e.g. 20 per opp) when grouping.
 *
 * @param {string[]} opportunityIds
 * @returns {string} SOQL string
 */
export function soqlTasks(opportunityIds) {
  if (!opportunityIds?.length) return "";
  const inList = opportunityIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ");
  return `SELECT Id, WhatId, Subject, Status, ActivityDate, Description, Type FROM Task WHERE WhatId IN (${inList}) ORDER BY CreatedDate DESC LIMIT ${TASK_LIMIT}`.trim();
}

/**
 * Build SOQL for Case by configurable opportunity lookup field. Skip if field not configured.
 *
 * @param {string[]} opportunityIds
 * @param {string} caseOpportunityField - API name e.g. Related_Opportunity__c
 * @returns {string} SOQL string or "" if field empty
 */
export function soqlCases(opportunityIds, caseOpportunityField) {
  if (!opportunityIds?.length || !caseOpportunityField?.trim()) return "";
  const inList = opportunityIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ");
  return `SELECT Id, ${caseOpportunityField.trim()}, Subject, Status, Type, Description FROM Case WHERE ${caseOpportunityField.trim()} IN (${inList})`.trim();
}

/**
 * Build SOQL for related opportunities (same account), excluding the current opportunity set.
 *
 * @param {string[]} accountIds - Account IDs from core query
 * @param {string[]} excludeOpportunityIds - Current opportunity IDs to exclude
 * @returns {string} SOQL string
 */
export function soqlRelatedOpportunities(accountIds, excludeOpportunityIds) {
  if (!accountIds?.length) return "";
  const accountList = accountIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ");
  const excludeList = excludeOpportunityIds?.length
    ? excludeOpportunityIds.map((id) => `'${escapeSoqlString(id)}'`).join(", ")
    : "";
  const excludeClause = excludeList ? ` AND Id NOT IN (${excludeList})` : "";
  return `SELECT Id, AccountId, Name, StageName, Amount, CloseDate, Type FROM Opportunity WHERE AccountId IN (${accountList})${excludeClause} ORDER BY CloseDate DESC LIMIT ${RELATED_OPP_LIMIT}`.trim();
}

/**
 * Chunk an array into groups of at most size.
 *
 * @param {string[]} ids
 * @param {number} [size=50]
 * @returns {string[][]}
 */
export function chunkIds(ids, size = CHUNK_SIZE) {
  if (!Array.isArray(ids) || ids.length === 0) return [];
  const out = [];
  for (let i = 0; i < ids.length; i += size) {
    out.push(ids.slice(i, i + size));
  }
  return out;
}

export { CHUNK_SIZE };
