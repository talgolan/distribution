/**
 * Shared type definitions (JSDoc) for the Architect Comments CLI.
 * @module src/types
 */

/**
 * @typedef {Object} Config
 * @property {string} guidelinesUrl - Google Doc URL or document ID for guidelines.
 * @property {string} guidelinesFile - Optional local file path for guidelines (fallback).
 * @property {string} outputPath - Path for the Data Loader CSV output.
 * @property {string} [outputFullPath] - Path for full architect comments JSON (default architect_comments_full.json).
 * @property {string} targetOrg - Salesforce CLI target org alias (optional).
 * @property {string} orgId - Org ID for reference (default 00D...).
 * @property {number} maxCommentLength - Max length for Architect_Comments__c (default 240).
 * @property {boolean} [fetchRelatedData] - Whether to fetch related data (line items, contacts, tasks, etc.); default true.
 * @property {string} [caseOpportunityField] - Case lookup field API name (e.g. Related_Opportunity__c); empty skips Case query.
 * @property {boolean} [useLlm] - When true, use LLM via Engineering AI Model Gateway for comment generation; requires ENG_AI_MODEL_GW_KEY.
 * @property {string} [engAiModelGwKey] - Gateway API key (env ENG_AI_MODEL_GW_KEY).
 * @property {string} [engAiModelGwUrl] - Gateway base URL (env ENG_AI_MODEL_GW_URL); optional override.
 * @property {string} [llmModel] - Model id (env ENG_AI_MODEL or LLM_MODEL); default claude-sonnet-4-20250514. List via GET {base}/v1/models.
 * @property {boolean} [llmCache] - When true (default), cache LLM responses by opportunity Id + guidelines + model to reduce cost.
 * @property {string} [llmCacheDir] - Directory for cache files (default .llm-cache); set LLM_CACHE=false to disable.
 * @property {string} [closeDateFrom] - SOQL CloseDate >= filter (YYYY-MM-DD); default: first of current month.
 * @property {string} [closeDateTo] - SOQL CloseDate <= filter (YYYY-MM-DD); default: last day 12 months out.
 * @property {string} [opportunityOwnerRoleLike] - SOQL LIKE filter for Opportunity_Owner_Role__c; default: hardcoded team filter.
 * @property {string[]} [ownerManagerNames] - Owner manager names used in bulk retrieval Owner_Manager_Name__c IN (...) filter.
 */

/**
 * Normalized opportunity record as returned from sf data query (flattened where needed).
 * @typedef {Object} Opportunity
 * @property {string} Id
 * @property {string} Name
 * @property {string} [AccountId]
 * @property {string} [Account?.Name]
 * @property {string} [Account?.Industry]
 * @property {string} [Account?.Type]
 * @property {string} [Account?.Combo_Company__c]
 * @property {number} [Amount]
 * @property {string} [CloseDate]
 * @property {string} [StageName]
 * @property {string} [Type]
 * @property {string} [Owner?.Name]
 * @property {string} [Owner?.Id]
 * @property {string} [Owner_Manager_Name__c]
 * @property {string} [LastModifiedBy?.Name]
 * @property {string} [SE_Comments__c]
 * @property {string} [SE_Next_Steps__c]
 * @property {string} [EBR_Manager_Notes__c]
 * @property {string} [Specialist_Sales_Notes__c]
 * @property {string} [Competitive_Notes__c]
 * @property {string} [SEM_Notes__c]
 * @property {string} [IBU_Next_Steps_Notes__c]
 * @property {string} [Manager_Notes__c]
 * @property {string} [Architect_Comments__c]
 * @property {string} [Opportunity_Owner_Role__c]
 * @property {number|null} [IqScore]
 * @property {string} [Description]
 * @property {string} [NextStep]
 * @property {string} [LeadSource]
 * @property {boolean} [IsClosed]
 * @property {boolean} [IsWon]
 * @property {number} [Probability]
 * @property {string} [CreatedDate]
 * @property {string} [LastModifiedDate]
 */

/**
 * Opportunity line item (product).
 * @typedef {Object} LineItem
 * @property {string} Id
 * @property {string} OpportunityId
 * @property {string} [Product2?.Name]
 * @property {string} [Product2?.Family]
 * @property {number} [Quantity]
 * @property {number} [UnitPrice]
 * @property {number} [TotalPrice]
 * @property {string} [Description]
 */

/**
 * Opportunity contact role.
 * @typedef {Object} ContactRole
 * @property {string} Id
 * @property {string} OpportunityId
 * @property {string} [Role]
 * @property {string} [Contact?.Name]
 * @property {string} [Contact?.Title]
 * @property {boolean} [IsPrimary]
 */

/**
 * Task related to an opportunity (WhatId).
 * @typedef {Object} TaskRecord
 * @property {string} Id
 * @property {string} WhatId
 * @property {string} [Subject]
 * @property {string} [Status]
 * @property {string} [ActivityDate]
 * @property {string} [Description]
 * @property {string} [Type]
 */

/**
 * Case related to an opportunity (configurable lookup).
 * @typedef {Object} CaseRecord
 * @property {string} Id
 * @property {string} [Related_Opportunity__c]
 * @property {string} [Subject]
 * @property {string} [Status]
 * @property {string} [Type]
 * @property {string} [Description]
 */

/**
 * Related opportunity (same account).
 * @typedef {Object} RelatedOpportunity
 * @property {string} Id
 * @property {string} AccountId
 * @property {string} [Name]
 * @property {string} [StageName]
 * @property {number} [Amount]
 * @property {string} [CloseDate]
 * @property {string} [Type]
 */

/**
 * Opportunity plus related data (line items, contact roles, tasks, cases, related opps).
 * @typedef {Object} OpportunityWithRelated
 * @property {string} Id
 * @property {string} Name
 * @property {string} [AccountId]
 * @property {string} [Account.Name]
 * @property {string} [Account.Industry]
 * @property {string} [Account.Type]
 * @property {number} [Amount]
 * @property {string} [CloseDate]
 * @property {string} [StageName]
 * @property {string} [Type]
 * @property {string} [Owner.Name]
 * @property {string} [SE_Comments__c]
 * @property {string} [Description]
 * @property {string} [NextStep]
 * @property {number|null} [IqScore]
 * @property {number} [Probability]
 * @property {LineItem[]} [lineItems]
 * @property {ContactRole[]} [contactRoles]
 * @property {TaskRecord[]} [tasks]
 * @property {CaseRecord[]} [cases]
 * @property {RelatedOpportunity[]} [relatedOpportunities]
 */

/**
 * Row for Data Loader CSV (Update Opportunity).
 * @typedef {Object} DataLoaderRow
 * @property {string} Id - Opportunity Id
 * @property {string} Architect_Comments__c - Generated comment (≤ max length)
 */
