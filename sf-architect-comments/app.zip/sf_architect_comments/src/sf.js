/**
 * Invoke unified Salesforce CLI (`sf`) only to run SOQL and return opportunities.
 * No legacy sfdx commands. Uses sf data query --result-format json.
 * Also provides verifySfLogin, loadOpportunitiesFromFile, writeOpportunitiesToFile for incremental testing.
 * @module src/sf
 */

import { spawn } from "child_process";
import { readFile, writeFile } from "fs/promises";
import { buildOpportunitiesSoql, getOpportunityByIdSoql } from "./soql.js";
import {
  chunkIds,
  soqlLineItems,
  soqlContactRoles,
  soqlTasks,
  soqlCases,
  soqlRelatedOpportunities,
} from "./soql-related.js";

/**
 * Run a command and return stdout as string; throws on non-zero exit or stderr when failOnStderr.
 *
 * @param {string} cmd - Command (e.g. "sf")
 * @param {string[]} args - Arguments (e.g. ["data", "query", "--query", "...", "--result-format", "json"])
 * @param {{ failOnStderr?: boolean }} [opts] - If true, treat stderr as failure
 * @returns {Promise<string>} stdout
 */
export function runSf(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    proc.stdout.setEncoding("utf-8").on("data", (chunk) => { stdout += chunk; });
    proc.stderr.setEncoding("utf-8").on("data", (chunk) => { stderr += chunk; });
    proc.on("error", (err) => reject(new Error(`Failed to run ${cmd}: ${err.message}`)));
    proc.on("close", (code) => {
      if (code !== 0) reject(new Error(`sf exited ${code}. ${stderr || stdout}`.trim()));
      else if (opts.failOnStderr && stderr) reject(new Error(`sf stderr: ${stderr}`.trim()));
      else resolve(stdout);
    });
  });
}

/**
 * Run a SOQL query via sf data query and return parsed records array.
 * Used by fetchOpportunitiesWithRelated for related-data queries; injectable for tests.
 *
 * @param {string} soql - SOQL string
 * @param {{ targetOrg?: string, runSf?: (cmd: string, args: string[]) => Promise<string> }} [options]
 * @returns {Promise<Record<string, unknown>[]>} Raw records (not normalized)
 */
export async function runSfQuery(soql, options = {}) {
  const run = options.runSf ?? runSf;
  const args = [
    "data", "query",
    "--query", soql,
    "--result-format", "json",
  ];
  if (options.targetOrg) {
    args.push("--target-org", options.targetOrg);
  }
  const raw = await run("sf", args);
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    throw new Error(`Invalid JSON from sf data query: ${e.message}`);
  }
  const records = data?.result?.records ?? data?.records ?? data;
  if (!Array.isArray(records)) {
    throw new Error("Unexpected sf data query output: no records array");
  }
  return records;
}

/**
 * Fetch opportunities by invoking sf data query (unified CLI only).
 * Parses JSON and normalizes records (flatten Account.Name, Owner.Name, etc.).
 *
 * @param {{ targetOrg?: string, opportunityOwnerRoleLike?: string, ownerManagerNames?: string[] }} [options] - Optional target org alias and bulk SOQL overrides
 * @returns {Promise<import('./types.js').Opportunity[]>} List of opportunity records
 */
export async function fetchOpportunities(options = {}) {
  const args = [
    "data", "query",
    "--query", buildOpportunitiesSoql(options),
    "--result-format", "json",
  ];
  if (options.targetOrg) {
    args.push("--target-org", options.targetOrg);
  }

  const raw = await runSf("sf", args);
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    throw new Error(`Invalid JSON from sf data query: ${e.message}`);
  }

  // CLI returns { result: { records: [...] } } or similar; normalize
  const records = data?.result?.records ?? data?.records ?? data;
  if (!Array.isArray(records)) {
    throw new Error("Unexpected sf data query output: no records array");
  }

  return records.map(normalizeOpportunity);
}

const TASKS_PER_OPP = 20;
const RELATED_OPPS_PER_ACCOUNT = 10;

/**
 * Fetch opportunities with related data (line items, contact roles, tasks, cases, related opps).
 * Runs core query then batch runs related queries in chunks; groups by OpportunityId and returns OpportunityWithRelated[].
 *
 * @param {{
 *   targetOrg?: string,
 *   fetchRelatedData?: boolean,
 *   caseOpportunityField?: string,
 *   runSfQuery?: (soql: string, opts: object) => Promise<Record<string, unknown>[]>,
 *   opportunityOwnerRoleLike?: string,
 *   ownerManagerNames?: string[],
 * }} [options]
 * @returns {Promise<import('./types.js').OpportunityWithRelated[]>}
 */
export async function fetchOpportunitiesWithRelated(options = {}) {
  const fetchRelated = options.fetchRelatedData !== false;
  const caseField = options.caseOpportunityField?.trim() ?? "";
  const runQuery = options.runSfQuery ?? runSfQuery;

  const coreRecords = await runQuery(buildOpportunitiesSoql(options), { targetOrg: options.targetOrg });
  const opportunities = coreRecords.map(normalizeOpportunity);
  if (!opportunities.length) return [];

  const oppIds = opportunities.map((o) => o.Id);
  const accountIds = [...new Set(opportunities.map((o) => o.AccountId).filter(Boolean))];

  /** @type {Record<string, import('./types.js').LineItem[]>} */
  const lineItemsByOpp = {};
  /** @type {Record<string, import('./types.js').ContactRole[]>} */
  const contactRolesByOpp = {};
  /** @type {Record<string, import('./types.js').TaskRecord[]>} */
  const tasksByOpp = {};
  /** @type {Record<string, import('./types.js').CaseRecord[]>} */
  const casesByOpp = {};
  /** @type {Record<string, import('./types.js').RelatedOpportunity[]>} */
  const relatedByAccount = {};

  if (fetchRelated) {
    const chunks = chunkIds(oppIds);
    for (const chunk of chunks) {
      const [lineSoql, contactSoql, taskSoql] = [
        soqlLineItems(chunk),
        soqlContactRoles(chunk),
        soqlTasks(chunk),
      ];
      const caseSoql = caseField ? soqlCases(chunk, caseField) : "";

      const [lineRecords, contactRecords, taskRecords, caseRecords] = await Promise.all([
        lineSoql ? runQuery(lineSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
        contactSoql ? runQuery(contactSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
        taskSoql ? runQuery(taskSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
        caseSoql ? runQuery(caseSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
      ]);

      for (const r of lineRecords) {
        const norm = normalizeLineItem(r);
        const oid = norm.OpportunityId;
        if (!lineItemsByOpp[oid]) lineItemsByOpp[oid] = [];
        lineItemsByOpp[oid].push(norm);
      }
      for (const r of contactRecords) {
        const norm = normalizeContactRole(r);
        const oid = norm.OpportunityId;
        if (!contactRolesByOpp[oid]) contactRolesByOpp[oid] = [];
        contactRolesByOpp[oid].push(norm);
      }
      for (const r of taskRecords) {
        const norm = normalizeTask(r);
        const wid = norm.WhatId;
        if (!tasksByOpp[wid]) tasksByOpp[wid] = [];
        if (tasksByOpp[wid].length < TASKS_PER_OPP) tasksByOpp[wid].push(norm);
      }
      for (const r of caseRecords) {
        const norm = normalizeCase(r, caseField);
        const oid = norm.OpportunityId;
        if (!oid) continue;
        if (!casesByOpp[oid]) casesByOpp[oid] = [];
        casesByOpp[oid].push(norm);
      }
    }

    const accountChunks = chunkIds(accountIds);
    for (const acctChunk of accountChunks) {
      const soql = soqlRelatedOpportunities(acctChunk, oppIds);
      if (!soql) continue;
      const relRecords = await runQuery(soql, { targetOrg: options.targetOrg });
      for (const r of relRecords) {
        const norm = normalizeRelatedOpportunity(r);
        const aid = norm.AccountId;
        if (!relatedByAccount[aid]) relatedByAccount[aid] = [];
        if (relatedByAccount[aid].length < RELATED_OPPS_PER_ACCOUNT) {
          relatedByAccount[aid].push(norm);
        }
      }
    }
  }

  return opportunities.map((opp) => {
    const base = { ...opp };
    delete base.Architect_Comments__c;
    /** @type {import('./types.js').OpportunityWithRelated} */
    const withRelated = {
      ...base,
      lineItems: lineItemsByOpp[opp.Id] ?? [],
      contactRoles: contactRolesByOpp[opp.Id] ?? [],
      tasks: tasksByOpp[opp.Id] ?? [],
      cases: casesByOpp[opp.Id] ?? [],
      relatedOpportunities: relatedByAccount[opp.AccountId] ?? [],
    };
    return withRelated;
  });
}

/**
 * Fetch a single opportunity by Id (same data shape as one element from fetchOpportunities).
 * No related data; use for --only-retrieve-opportunity to match --only-opportunities output.
 *
 * @param {string} opportunityId - Salesforce Opportunity Id (e.g. 006ed00000TwuE1AAJ)
 * @param {{ targetOrg?: string, runSfQuery?: (soql: string, opts: object) => Promise<Record<string, unknown>[]> }} [options]
 * @returns {Promise<import('./types.js').Opportunity|null>} Single normalized opportunity, or null if not found
 */
export async function fetchOpportunityById(opportunityId, options = {}) {
  const runQuery = options.runSfQuery ?? runSfQuery;
  const soql = getOpportunityByIdSoql(opportunityId);
  const records = await runQuery(soql, { targetOrg: options.targetOrg });
  if (!records.length) return null;
  return normalizeOpportunity(records[0]);
}

/**
 * Fetch a single opportunity by Id with full related data (line items, contact roles, tasks, cases, related opps).
 * Runs the same related-data queries as fetchOpportunitiesWithRelated for that one Id. Use for testing the full workflow.
 *
 * @param {string} opportunityId - Salesforce Opportunity Id (e.g. 006ed00000TwuE1AAJ)
 * @param {{
 *   targetOrg?: string,
 *   fetchRelatedData?: boolean,
 *   caseOpportunityField?: string,
 *   runSfQuery?: (soql: string, opts: object) => Promise<Record<string, unknown>[]>,
 * }} [options]
 * @returns {Promise<import('./types.js').OpportunityWithRelated|null>} Single opportunity with related data, or null if not found
 */
export async function fetchOpportunityWithRelatedById(opportunityId, options = {}) {
  const runQuery = options.runSfQuery ?? runSfQuery;
  const soql = getOpportunityByIdSoql(opportunityId);
  const coreRecords = await runQuery(soql, { targetOrg: options.targetOrg });
  if (!coreRecords.length) return null;
  const opp = normalizeOpportunity(coreRecords[0]);
  const fetchRelated = options.fetchRelatedData !== false;
  const caseField = options.caseOpportunityField?.trim() ?? "";
  const oppIds = [opp.Id];
  const accountIds = opp.AccountId ? [opp.AccountId] : [];

  /** @type {Record<string, import('./types.js').LineItem[]>} */
  const lineItemsByOpp = {};
  /** @type {Record<string, import('./types.js').ContactRole[]>} */
  const contactRolesByOpp = {};
  /** @type {Record<string, import('./types.js').TaskRecord[]>} */
  const tasksByOpp = {};
  /** @type {Record<string, import('./types.js').CaseRecord[]>} */
  const casesByOpp = {};
  /** @type {Record<string, import('./types.js').RelatedOpportunity[]>} */
  const relatedByAccount = {};

  if (fetchRelated) {
    const [lineSoql, contactSoql, taskSoql] = [
      soqlLineItems(oppIds),
      soqlContactRoles(oppIds),
      soqlTasks(oppIds),
    ];
    const caseSoql = caseField ? soqlCases(oppIds, caseField) : "";

    const [lineRecords, contactRecords, taskRecords, caseRecords] = await Promise.all([
      lineSoql ? runQuery(lineSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
      contactSoql ? runQuery(contactSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
      taskSoql ? runQuery(taskSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
      caseSoql ? runQuery(caseSoql, { targetOrg: options.targetOrg }) : Promise.resolve([]),
    ]);

    for (const r of lineRecords) {
      const norm = normalizeLineItem(r);
      const oid = norm.OpportunityId;
      if (!lineItemsByOpp[oid]) lineItemsByOpp[oid] = [];
      lineItemsByOpp[oid].push(norm);
    }
    for (const r of contactRecords) {
      const norm = normalizeContactRole(r);
      const oid = norm.OpportunityId;
      if (!contactRolesByOpp[oid]) contactRolesByOpp[oid] = [];
      contactRolesByOpp[oid].push(norm);
    }
    for (const r of taskRecords) {
      const norm = normalizeTask(r);
      const wid = norm.WhatId;
      if (!tasksByOpp[wid]) tasksByOpp[wid] = [];
      if (tasksByOpp[wid].length < TASKS_PER_OPP) tasksByOpp[wid].push(norm);
    }
    for (const r of caseRecords) {
      const norm = normalizeCase(r, caseField);
      const oid = norm.OpportunityId;
      if (!oid) continue;
      if (!casesByOpp[oid]) casesByOpp[oid] = [];
      casesByOpp[oid].push(norm);
    }

    if (accountIds.length) {
      const soqlRel = soqlRelatedOpportunities(accountIds, oppIds);
      if (soqlRel) {
        const relRecords = await runQuery(soqlRel, { targetOrg: options.targetOrg });
        for (const r of relRecords) {
          const norm = normalizeRelatedOpportunity(r);
          const aid = norm.AccountId;
          if (!relatedByAccount[aid]) relatedByAccount[aid] = [];
          if (relatedByAccount[aid].length < RELATED_OPPS_PER_ACCOUNT) relatedByAccount[aid].push(norm);
        }
      }
    }
  }

  const base = { ...opp };
  delete base.Architect_Comments__c;
  /** @type {import('./types.js').OpportunityWithRelated} */
  return {
    ...base,
    lineItems: lineItemsByOpp[opp.Id] ?? [],
    contactRoles: contactRolesByOpp[opp.Id] ?? [],
    tasks: tasksByOpp[opp.Id] ?? [],
    cases: casesByOpp[opp.Id] ?? [],
    relatedOpportunities: relatedByAccount[opp.AccountId] ?? [],
  };
}

/**
 * Verify the user is logged in to the Salesforce CLI (unified sf only).
 * Runs `sf org display --json`; on success returns alias and username.
 *
 * @param {{ targetOrg?: string }} [options] - Optional target org alias for sf
 * @returns {Promise<{ alias: string, username?: string }>} Org alias and optional username
 * @throws {Error} When not logged in, no default org, or sf fails
 */
export async function verifySfLogin(options = {}) {
  const args = ["org", "display", "--json"];
  if (options.targetOrg) {
    args.push("--target-org", options.targetOrg);
  }
  let raw;
  try {
    raw = await runSf("sf", args);
  } catch (e) {
    const msg = e.message || String(e);
    if (/exit|not found|ENOENT/i.test(msg)) {
      throw new Error("Not logged in to Salesforce CLI or no default org set. Run: sf org login web (or use --target-org).");
    }
    throw new Error(`Salesforce CLI error: ${msg}`);
  }
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    throw new Error("Invalid JSON from sf org display.");
  }
  const result = data?.result ?? data;
  const alias = result?.alias ?? result?.username ?? "default";
  const username = result?.username;
  return { alias, username };
}

/**
 * Load opportunities from a JSON file (same shape as normalizeOpportunity output).
 * Used for incremental testing with --opportunities-file or --only-generate.
 *
 * @param {string} path - Path to JSON file (array of opportunity objects)
 * @returns {Promise<import('./types.js').Opportunity[]>} List of opportunity records
 */
export async function loadOpportunitiesFromFile(path) {
  let raw;
  try {
    raw = await readFile(path, "utf-8");
  } catch (e) {
    if (e.code === "ENOENT") throw new Error(`Opportunities file not found: ${path}`);
    throw new Error(`Failed to read opportunities file: ${e.message}`);
  }
  let arr;
  try {
    arr = JSON.parse(raw);
  } catch (e) {
    throw new Error(`Invalid JSON in opportunities file: ${e.message}`);
  }
  if (!Array.isArray(arr)) throw new Error("Opportunities file must contain a JSON array.");
  return arr.map((item) => ({
    Id: String(item.Id ?? ""),
    Name: item.Name != null ? String(item.Name) : undefined,
    "Account.Name": item["Account.Name"] != null ? String(item["Account.Name"]) : undefined,
    "Account.Industry": item["Account.Industry"] != null ? String(item["Account.Industry"]) : undefined,
    "Account.Type": item["Account.Type"] != null ? String(item["Account.Type"]) : undefined,
    Amount: typeof item.Amount === "number" ? item.Amount : undefined,
    CloseDate: item.CloseDate != null ? String(item.CloseDate) : undefined,
    StageName: item.StageName != null ? String(item.StageName) : undefined,
    Type: item.Type != null ? String(item.Type) : undefined,
    "Owner.Name": item["Owner.Name"] != null ? String(item["Owner.Name"]) : undefined,
    SE_Comments__c: item.SE_Comments__c != null ? String(item.SE_Comments__c) : undefined,
    Architect_Comments__c: item.Architect_Comments__c != null ? String(item.Architect_Comments__c) : undefined,
    Opportunity_Owner_Role__c: item.Opportunity_Owner_Role__c != null ? String(item.Opportunity_Owner_Role__c) : undefined,
    IqScore: typeof item.IqScore === "number" ? item.IqScore : (item.IqScore != null ? Number(item.IqScore) : null),
    Description: item.Description != null ? String(item.Description) : undefined,
    NextStep: item.NextStep != null ? String(item.NextStep) : undefined,
    LeadSource: item.LeadSource != null ? String(item.LeadSource) : undefined,
    IsClosed: item.IsClosed === true,
    IsWon: item.IsWon === true,
    Probability: typeof item.Probability === "number" ? item.Probability : undefined,
    CreatedDate: item.CreatedDate != null ? String(item.CreatedDate) : undefined,
    LastModifiedDate: item.LastModifiedDate != null ? String(item.LastModifiedDate) : undefined,
  }));
}

/**
 * Write opportunities to a JSON file (same format as loadOpportunitiesFromFile expects).
 * Used when --only-opportunities writes its output.
 *
 * @param {import('./types.js').Opportunity[]} opportunities - List of opportunity records
 * @param {string} path - Output file path
 * @returns {Promise<void>}
 */
export async function writeOpportunitiesToFile(opportunities, path) {
  await writeFile(path, JSON.stringify(opportunities, null, 2), "utf-8");
}

/** @param {Record<string, unknown>} raw */
function normalizeLineItem(raw) {
  const p = raw.Product2;
  return {
    Id: String(raw.Id ?? ""),
    OpportunityId: String(raw.OpportunityId ?? ""),
    "Product2.Name": p && typeof p.Name !== "undefined" ? String(p.Name) : undefined,
    "Product2.Family": p && typeof p.Family !== "undefined" ? String(p.Family) : undefined,
    Quantity: typeof raw.Quantity === "number" ? raw.Quantity : undefined,
    UnitPrice: typeof raw.UnitPrice === "number" ? raw.UnitPrice : undefined,
    TotalPrice: typeof raw.TotalPrice === "number" ? raw.TotalPrice : undefined,
    Description: raw.Description != null ? String(raw.Description) : undefined,
  };
}

/** @param {Record<string, unknown>} raw */
function normalizeContactRole(raw) {
  const c = raw.Contact;
  return {
    Id: String(raw.Id ?? ""),
    OpportunityId: String(raw.OpportunityId ?? ""),
    Role: raw.Role != null ? String(raw.Role) : undefined,
    "Contact.Name": c && typeof c.Name !== "undefined" ? String(c.Name) : undefined,
    "Contact.Title": c && typeof c.Title !== "undefined" ? String(c.Title) : undefined,
    IsPrimary: raw.IsPrimary === true,
  };
}

/** @param {Record<string, unknown>} raw */
function normalizeTask(raw) {
  return {
    Id: String(raw.Id ?? ""),
    WhatId: String(raw.WhatId ?? ""),
    Subject: raw.Subject != null ? String(raw.Subject) : undefined,
    Status: raw.Status != null ? String(raw.Status) : undefined,
    ActivityDate: raw.ActivityDate != null ? String(raw.ActivityDate) : undefined,
    Description: raw.Description != null ? String(raw.Description) : undefined,
    Type: raw.Type != null ? String(raw.Type) : undefined,
  };
}

/**
 * @param {Record<string, unknown>} raw
 * @param {string} caseOpportunityField - API name of the lookup to Opportunity
 */
function normalizeCase(raw, caseOpportunityField) {
  const opportunityId = raw[caseOpportunityField] != null ? String(raw[caseOpportunityField]) : undefined;
  const out = {
    Id: String(raw.Id ?? ""),
    OpportunityId: opportunityId,
    Subject: raw.Subject != null ? String(raw.Subject) : undefined,
    Status: raw.Status != null ? String(raw.Status) : undefined,
    Type: raw.Type != null ? String(raw.Type) : undefined,
    Description: raw.Description != null ? String(raw.Description) : undefined,
  };
  if (caseOpportunityField) out[caseOpportunityField] = opportunityId;
  return out;
}

/** @param {Record<string, unknown>} raw */
function normalizeRelatedOpportunity(raw) {
  return {
    Id: String(raw.Id ?? ""),
    AccountId: String(raw.AccountId ?? ""),
    Name: raw.Name != null ? String(raw.Name) : undefined,
    StageName: raw.StageName != null ? String(raw.StageName) : undefined,
    Amount: typeof raw.Amount === "number" ? raw.Amount : undefined,
    CloseDate: raw.CloseDate != null ? String(raw.CloseDate) : undefined,
    Type: raw.Type != null ? String(raw.Type) : undefined,
  };
}

/**
 * Normalize a raw record from sf (relationship fields may be nested).
 *
 * @param {Record<string, unknown>} raw
 * @returns {import('./types.js').Opportunity}
 */
function normalizeOpportunity(raw) {
  const acc = raw.Account;
  const owner = raw.Owner;
  const lastModifiedBy = raw.LastModifiedBy;
  return {
    Id: String(raw.Id ?? ""),
    Name: String(raw.Name ?? ""),
    AccountId: raw.AccountId != null ? String(raw.AccountId) : undefined,
    "Account.Name": acc && typeof acc.Name !== "undefined" ? String(acc.Name) : undefined,
    "Account.Industry": acc && typeof acc.Industry !== "undefined" ? String(acc.Industry) : undefined,
    "Account.Type": acc && typeof acc.Type !== "undefined" ? String(acc.Type) : undefined,
    Amount: typeof raw.Amount === "number"
      ? raw.Amount
      : (typeof raw.AmountConverted__c === "number" ? raw.AmountConverted__c : undefined),
    CloseDate: raw.CloseDate != null ? String(raw.CloseDate) : undefined,
    StageName: raw.StageName != null ? String(raw.StageName) : undefined,
    Type: raw.Type != null ? String(raw.Type) : undefined,
    "Owner.Name": owner && typeof owner.Name !== "undefined" ? String(owner.Name) : undefined,
    "Owner.Id": owner && typeof owner.Id !== "undefined" ? String(owner.Id) : undefined,
    Owner_Manager_Name__c: raw.Owner_Manager_Name__c != null ? String(raw.Owner_Manager_Name__c) : undefined,
    "LastModifiedBy.Name": lastModifiedBy && typeof lastModifiedBy.Name !== "undefined" ? String(lastModifiedBy.Name) : undefined,
    "Account.Combo_Company__c": acc && typeof acc.Combo_Company__c !== "undefined" ? String(acc.Combo_Company__c) : undefined,
    SE_Comments__c: raw.SE_Comments__c != null ? String(raw.SE_Comments__c) : undefined,
    SE_Next_Steps__c: raw.SE_Next_Steps__c != null ? String(raw.SE_Next_Steps__c) : undefined,
    EBR_Manager_Notes__c: raw.EBR_Manager_Notes__c != null ? String(raw.EBR_Manager_Notes__c) : undefined,
    Specialist_Sales_Notes__c: raw.Specialist_Sales_Notes__c != null ? String(raw.Specialist_Sales_Notes__c) : undefined,
    Competitive_Notes__c: raw.Competitive_Notes__c != null ? String(raw.Competitive_Notes__c) : undefined,
    SEM_Notes__c: raw.SEM_Notes__c != null ? String(raw.SEM_Notes__c) : undefined,
    IBU_Next_Steps_Notes__c: raw.IBU_Next_Steps_Notes__c != null ? String(raw.IBU_Next_Steps_Notes__c) : undefined,
    Manager_Notes__c: raw.Manager_Notes__c != null ? String(raw.Manager_Notes__c) : undefined,
    Architect_Comments__c: raw.Architect_Comments__c != null ? String(raw.Architect_Comments__c) : undefined,
    Opportunity_Owner_Role__c: raw.Opportunity_Owner_Role__c != null ? String(raw.Opportunity_Owner_Role__c) : undefined,
    IqScore: typeof raw.IqScore === "number" ? raw.IqScore : (raw.IqScore != null ? Number(raw.IqScore) : null),
    Description: raw.Description != null ? String(raw.Description) : undefined,
    NextStep: raw.NextStep != null ? String(raw.NextStep) : undefined,
    LeadSource: raw.LeadSource != null ? String(raw.LeadSource) : undefined,
    IsClosed: raw.IsClosed === true,
    IsWon: raw.IsWon === true,
    Probability: typeof raw.Probability === "number" ? raw.Probability : undefined,
    CreatedDate: raw.CreatedDate != null ? String(raw.CreatedDate) : undefined,
    LastModifiedDate: raw.LastModifiedDate != null ? String(raw.LastModifiedDate) : undefined,
  };
}
