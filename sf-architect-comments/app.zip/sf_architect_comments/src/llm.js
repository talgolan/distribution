/**
 * LLM-based architect comment generation via Engineering AI Model Gateway.
 * Builds a prompt from factual opportunity data and guidelines; requests structured JSON response
 * with one field per POV section. All LLM access is through the gateway (ENG_AI_MODEL_GW_KEY).
 * Cache keyed by opportunity Id + LastModifiedDate hash + guidelines hash + model.
 * @module src/llm
 */

import { createHash } from "node:crypto";
import { mkdir } from "node:fs/promises";
import * as analyzer from "./analyzer.js";

const GUIDELINES_MAX_CHARS = 8000;
const SUMMARY_MAX_LENGTH = 240;
const DEFAULT_CACHE_DIR = ".llm-cache";

/** Top-level JSON keys the LLM must return (excluding "summary"). */
const SECTION_KEYS = [
  "customerContext",
  "opportunitySummary",
  "architecturalAssessment",
  "competitiveLandscape",
  "recommendedApproach",
  "openQuestionsRisks",
  "technicalFitAssessment",
];

function guidelinesHash(guidelinesText) {
  return createHash("sha256").update(guidelinesText ?? "").digest("hex").slice(0, 16);
}

function safeModelForFilename(model) {
  return (model ?? "").replace(/[^a-zA-Z0-9-]/g, "_");
}

function lastModifiedHash(lastModifiedDate) {
  return createHash("sha256").update(String(lastModifiedDate ?? "")).digest("hex").slice(0, 8);
}

/**
 * @param {string} opportunityId
 * @param {string} lastModifiedDate
 * @param {string} guidelinesText
 * @param {string} modelName
 * @param {string} cacheDir
 * @returns {string} Cache file path.
 */
function cachePath(opportunityId, lastModifiedDate, guidelinesText, modelName, cacheDir) {
  const modHash = lastModifiedHash(lastModifiedDate);
  const h = guidelinesHash(guidelinesText);
  const safe = safeModelForFilename(modelName);
  return `${cacheDir}/${opportunityId}_${modHash}_${h}_${safe}.json`;
}

/**
 * @typedef {{ model: string, inputTokens: number, outputTokens: number, cached?: boolean }} LlmUsage
 */

/**
 * @param {string} cacheDir
 * @param {string} opportunityId
 * @param {string} lastModifiedDate
 * @param {string} guidelinesText
 * @param {string} modelName
 * @returns {Promise<{ sections: object, summary: string, usage: LlmUsage } | null>}
 */
async function getCached(cacheDir, opportunityId, lastModifiedDate, guidelinesText, modelName) {
  const path = cachePath(opportunityId, lastModifiedDate, guidelinesText, modelName, cacheDir);
  try {
    const data = await Bun.file(path).json();
    if (data?.sections != null && data?.summary != null && data?.usage) {
      return {
        sections: data.sections,
        summary: String(data.summary),
        usage: { ...data.usage, cached: true },
      };
    }
  } catch {
    // ignore missing or invalid cache file
  }
  return null;
}

/**
 * @param {string} cacheDir
 * @param {string} opportunityId
 * @param {string} lastModifiedDate
 * @param {string} guidelinesText
 * @param {string} modelName
 * @param {{ sections: object, summary: string, usage: LlmUsage }} value
 */
async function setCached(cacheDir, opportunityId, lastModifiedDate, guidelinesText, modelName, value) {
  const path = cachePath(opportunityId, lastModifiedDate, guidelinesText, modelName, cacheDir);
  await mkdir(cacheDir, { recursive: true });
  await Bun.write(
    path,
    JSON.stringify({
      sections: value.sections,
      summary: value.summary,
      usage: value.usage,
      cachedAt: new Date().toISOString(),
    }),
    { encoding: "utf-8" }
  );
}

/**
 * Assemble a human-readable "full" POV string from structured sections.
 * Used for CLI display, CSV full-comment output, and backward compatibility.
 *
 * @param {object} sections
 * @returns {string}
 */
export function assembleFull(sections) {
  const tfa = sections.technicalFitAssessment ?? {};
  const dimLines = (tfa.dimensions ?? [])
    .map((d) => `- ${d.name}: ${d.assessment}${d.confidence ? `; ${d.confidence} confidence.` : ""}`)
    .join("\n");
  const nextStepLines = (tfa.nextSteps ?? [])
    .map((s, i) => `${i + 1}. ${s}`)
    .join("\n");

  return [
    `**Customer Context** – ${sections.customerContext ?? ""}`,
    "",
    `**Opportunity Summary** – ${sections.opportunitySummary ?? ""}`,
    "",
    `**Architectural Assessment** – ${sections.architecturalAssessment ?? ""}`,
    "",
    `**Competitive Landscape** – ${sections.competitiveLandscape ?? ""}`,
    "",
    `**Recommended Approach** – ${sections.recommendedApproach ?? ""}`,
    "",
    `**Open Questions / Risks** – ${sections.openQuestionsRisks ?? ""}`,
    "",
    `**Technical Fit Assessment**`,
    "",
    `Opinion: ${tfa.opinion ?? ""}`,
    "",
    `Summary: ${tfa.summary ?? ""}`,
    "",
    `Dimension Breakdown:`,
    dimLines,
    "",
    `Key Unknowns:`,
    tfa.keyUnknowns ?? "",
    "",
    `Recommended Next Steps:`,
    nextStepLines,
  ]
    .join("\n")
    .trim();
}

/**
 * Build system and user prompts for the LLM from opportunity analysis and guidelines.
 * No I/O; uses analyzer to produce structured factual context.
 *
 * @param {import('./types.js').OpportunityWithRelated} opportunityWithRelated
 * @param {string} guidelinesText
 * @returns {{ systemPrompt: string, userPrompt: string }}
 */
export function buildPromptForOpportunity(opportunityWithRelated, guidelinesText) {
  const ctx = analyzer.analyzeContext(opportunityWithRelated);
  const tech = analyzer.analyzeTechnical(opportunityWithRelated);
  const engagement = analyzer.analyzeEngagement(opportunityWithRelated);
  const risks = analyzer.analyzeRisks(opportunityWithRelated);
  const score = opportunityWithRelated.IqScore ?? opportunityWithRelated["IqScore"];
  const stage = (opportunityWithRelated.StageName ?? "").trim();
  const probability = opportunityWithRelated.Probability;
  const notes = {
    seNextSteps: (opportunityWithRelated.SE_Next_Steps__c ?? "").trim() || "—",
    architectComments: (opportunityWithRelated.Architect_Comments__c ?? "").trim() || "—",
    ebrManagerNotes: (opportunityWithRelated.EBR_Manager_Notes__c ?? "").trim() || "—",
    specialistSalesNotes: (opportunityWithRelated.Specialist_Sales_Notes__c ?? "").trim() || "—",
    competitiveNotes: (opportunityWithRelated.Competitive_Notes__c ?? "").trim() || "—",
    semNotes: (opportunityWithRelated.SEM_Notes__c ?? "").trim() || "—",
    ibuNextStepsNotes: (opportunityWithRelated.IBU_Next_Steps_Notes__c ?? "").trim() || "—",
    managerNotes: (opportunityWithRelated.Manager_Notes__c ?? "").trim() || "—",
  };

  const facts = {
    context: {
      summary: ctx.summary,
      account: ctx.account,
      owner: ctx.owner,
      contacts: ctx.contacts,
      seComments: ctx.seComments,
      description: ctx.description,
      nextStep: ctx.nextStep,
    },
    technical: {
      productNames: tech.productNames,
      families: tech.families,
      keywords: tech.keywords,
      complexity: tech.complexity,
    },
    engagement: {
      taskCount: engagement.taskCount,
      recentActivity: engagement.recentActivity,
      caseCount: engagement.caseCount,
      relatedOppCount: engagement.relatedOppCount,
    },
    risks: {
      hasPocValidation: risks.hasPocValidation,
      stageVsProbability: risks.stageVsProbability,
      technicalContacts: risks.technicalContacts,
    },
    opportunity: {
      name: opportunityWithRelated.Name,
      amount: opportunityWithRelated.Amount,
      stage,
      probability,
      score,
      type: opportunityWithRelated.Type,
      closeDate: opportunityWithRelated.CloseDate,
    },
    notes,
  };

  const guidelines = (guidelinesText ?? "").trim();
  const guidelinesTruncated =
    guidelines.length > GUIDELINES_MAX_CHARS
      ? guidelines.slice(0, GUIDELINES_MAX_CHARS) + "\n[... truncated ...]"
      : guidelines;

  const systemPrompt = `You are a Senior Technical Architect at Salesforce with deep pre-sales experience across Enterprise and TMT accounts. Your audience is internal: sales leadership and executive sponsors. Your job is to produce a comprehensive Architect Point of View and to evaluate whether the opportunity represents a viable technical fit for a Salesforce solution.

Using the structured opportunity data, discovery/TA notes, and architect comments provided, produce the seven sections below.

---

EVALUATION FRAMEWORK (for Technical Fit):

Assess the opportunity across these five dimensions. For each, note what evidence exists, what is unknown, and your confidence level (High / Medium / Low):

1. SOLUTION ALIGNMENT – Does the described need map to a Salesforce product or cloud without significant gaps? Are any required capabilities missing, unsupported, or roadmap-dependent?
2. INTEGRATION COMPLEXITY – What systems must connect to Salesforce, and are standard integration patterns viable? Are there latency, real-time, or data volume requirements that could strain platform limits?
3. CUSTOMIZATION BURDEN – How much is out-of-the-box vs. requiring custom development? Does the customer have the admin/developer capacity to build and sustain customizations?
4. TECHNICAL RISK FLAGS – Architectural constraints (legacy systems, data residency, compliance, org model complexity) that could block or delay implementation? Any gap requiring a POC before committing?
5. CUSTOMER TECHNICAL READINESS – Does the customer have internal technical resources, governance, and appetite to implement and adopt? Signals of prior failed implementations or platform fatigue?

OPINIONS:
- ✅ FIT – In your judgment, strong alignment across most dimensions with no disqualifying risks; recommend proceeding with full technical proposal.
- ⚠️ CONDITIONAL FIT – In your judgment, viable but one or more dimensions carry meaningful risk or uncertainty; specify the condition(s) you believe must be resolved (e.g., POC required, architecture review, specific gap).
- ❌ NO FIT – In your judgment, one or more disqualifying issues exist; specify the disqualifying factor(s) clearly.

---

BODY STRUCTURE (why, what, what's next):

Across your prose JSON fields, use this consistent narrative so each comment covers engagement context, insight, POV, risk, and forward motion. Map as follows (do not add separate headings inside the JSON strings unless a section is naturally short enough):

- Engagements — Context and the specific goal of this engagement: primarily in "customerContext" and "opportunitySummary".
- Key Findings/Insights — What you discovered that changes the deal's technical or strategic posture: primarily in "architecturalAssessment" and "competitiveLandscape" (where competitor/strategic angle matters).
- Architecture/Strategic Recommendation — Your expert point of view (POV): primarily in "recommendedApproach".
- Risks/Gaps — Red flags or product gaps: primarily in "openQuestionsRisks".
- Next Steps — Clear ownership and deadlines: primarily in "recommendedApproach" (and only if needed, briefly in "openQuestionsRisks"); technicalFitAssessment.nextSteps should align with these actions.

---

Output format: You must respond with ONLY a valid JSON object (no markdown, no code block wrapper) with exactly these keys:

- "customerContext": string (50–120 words) – Who the customer is, their strategic moment, and what they're trying to solve.
- "opportunitySummary": string (50–120 words) – What Salesforce is being asked to deliver, deal stage, and key signals (size, timeline, competition).
- "architecturalAssessment": string (50–120 words) – Key technical considerations, risks, integration complexity, or platform fit concerns.
- "competitiveLandscape": string (50–120 words) – Known competitors, their positioning, and Salesforce's differentiated strengths. If no competitor data is available, note that and flag as an open item.
- "recommendedApproach": string (50–120 words) – Architect team's recommended path forward, including any pre-sales technical actions needed.
- "openQuestionsRisks": string (50–120 words) – Unresolved issues that could affect deal success or delivery confidence.
- "technicalFitAssessment": object with exactly these keys:
  - "opinion": string – Your architectural opinion, expressed as one of: "✅ FIT", "⚠️ CONDITIONAL FIT", or "❌ NO FIT"
  - "summary": string – 2–3 sentences: the "so what" for the AE and deal team
  - "dimensions": array of exactly 5 objects, each with "name" (string), "assessment" (string), "confidence" ("High"|"Medium"|"Low"). Names must be exactly: "Solution Alignment", "Integration Complexity", "Customization Burden", "Technical Risk Flags", "Customer Technical Readiness"
  - "keyUnknowns": string – What information is missing that would change your opinion
  - "nextSteps": array of 1–3 strings – specific recommended actions (plain strings, no numbering)
- "summary": string ≤240 characters – Lead with the architectural assessment, open questions/risks, and recommended approach. End with the Technical Fit opinion (e.g., "⚠️ CONDITIONAL FIT"). The opinion must always be the last element. Do not include the customer name, opportunity name, or deal value. Plain direct language, no jargon. Must be usable as a CRM field value.

Write each prose section as a trusted advisor, not a vendor. Be direct and specific. Avoid generic Salesforce marketing language. Lead with business impact for executive audiences. If architect comments contain differing perspectives, synthesize into a balanced view and flag uncertainty.

Respond with nothing else but the JSON object.`;

  const discoveryNotes = [
    ["SE / TA comments", ctx.seComments],
    ["SE next steps", notes.seNextSteps],
    ["Description", (opportunityWithRelated.Description ?? "").trim() || "—"],
    ["Next step", ctx.nextStep],
    ["Existing architect comments", notes.architectComments],
    ["EBR manager notes", notes.ebrManagerNotes],
    ["Specialist sales notes", notes.specialistSalesNotes],
    ["Competitive notes", notes.competitiveNotes],
    ["SEM notes", notes.semNotes],
    ["IBU next steps notes", notes.ibuNextStepsNotes],
    ["Manager notes", notes.managerNotes],
  ]
    .filter(([, v]) => v && v !== "—")
    .map(([label, v]) => `${label}:\n${v}`)
    .join("\n\n---\n\n") || "(No discovery or TA notes provided.)";

  const userPrompt = `## Discover / Architect notes (input for Technical Fit evaluation)

<notes>
${discoveryNotes}
</notes>

## Factual opportunity data (JSON)

\`\`\`json
${JSON.stringify(facts, null, 2)}
\`\`\`

## Architect guidelines (for tone and emphasis)

${guidelinesTruncated || "(No guidelines provided.)"}

## Your response

Respond with a single JSON object with keys: customerContext, opportunitySummary, architecturalAssessment, competitiveLandscape, recommendedApproach, openQuestionsRisks, technicalFitAssessment (object), summary.

Follow the BODY STRUCTURE guidance in the system prompt (Engagements, Key Findings/Insights, Architecture/Strategic Recommendation, Risks/Gaps, Next Steps) across those prose fields.`;

  return { systemPrompt, userPrompt };
}

/**
 * Call Engineering AI Model Gateway chat completions. Uses OpenAI-style request/response.
 *
 * @param {Array<{ role: string, content: string }>} messages
 * @param {{ apiKey: string, baseUrl: string, model: string }} options
 * @returns {Promise<{ content: string, usage: LlmUsage }>}
 */
export async function callGateway(messages, options) {
  const { apiKey, baseUrl, model } = options;
  const modelName = model || "gemini-3-flash-preview";
  if (!apiKey?.trim()) throw new Error("ENG_AI_MODEL_GW_KEY is required.");
  const url = `${(baseUrl ?? "").replace(/\/$/, "")}/chat/completions`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey.trim()}`,
    },
    body: JSON.stringify({
      model: modelName,
      messages,
      temperature: 0.3,
    }),
  });
  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Gateway API error (${res.status}): ${errBody || res.statusText}`);
  }
  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  if (content == null) throw new Error("Gateway returned no content.");
  const usage = data?.usage;
  const inputTokens = usage?.prompt_tokens ?? 0;
  const outputTokens = usage?.completion_tokens ?? 0;
  return {
    content: String(content),
    usage: { model: data?.model ?? modelName, inputTokens, outputTokens },
  };
}

/**
 * Truncate summary at word boundary to maxLen; append "…" if truncated.
 *
 * @param {string} s
 * @param {number} maxLen
 * @returns {string}
 */
function truncateSummary(s, maxLen) {
  const t = (s ?? "").trim().replace(/\s+/g, " ");
  if (t.length <= maxLen) return t;
  const take = t.slice(0, maxLen - 1);
  const lastSpace = take.lastIndexOf(" ");
  const out = lastSpace > maxLen / 2 ? take.slice(0, lastSpace) : take;
  return (out + "…").trim();
}

/**
 * Parse structured LLM response; validate required section keys; enforce summary ≤ maxLength.
 * Returns { sections, summary } where sections contains the 7 POV keys.
 *
 * @param {string} content - Raw assistant message (expected structured JSON)
 * @param {{ maxLength?: number }} [options]
 * @returns {{ sections: object, summary: string }}
 */
export function parseLlmCommentResponse(content, options = {}) {
  const maxLen = options.maxLength ?? SUMMARY_MAX_LENGTH;
  const raw = (content ?? "").trim();
  const stripped = raw.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
  let obj;
  try {
    obj = JSON.parse(stripped);
  } catch (e) {
    throw new Error(`LLM response is not valid JSON: ${e.message}`);
  }

  for (const key of SECTION_KEYS) {
    if (obj[key] == null) throw new Error(`LLM response missing '${key}' field.`);
  }
  const tfa = obj.technicalFitAssessment;
  if (typeof tfa !== "object" || tfa == null || Array.isArray(tfa)) {
    throw new Error("LLM response 'technicalFitAssessment' must be an object.");
  }
  if (!tfa.opinion) throw new Error("LLM response 'technicalFitAssessment.opinion' is missing.");
  if (!tfa.summary) throw new Error("LLM response 'technicalFitAssessment.summary' is missing.");
  if (!Array.isArray(tfa.dimensions)) throw new Error("LLM response 'technicalFitAssessment.dimensions' must be an array.");

  let summary = obj?.summary != null ? String(obj.summary).trim() : "";
  if (!summary) throw new Error("LLM response missing 'summary' field.");
  summary = truncateSummary(summary, maxLen);

  const sections = {
    customerContext: String(obj.customerContext).trim(),
    opportunitySummary: String(obj.opportunitySummary).trim(),
    architecturalAssessment: String(obj.architecturalAssessment).trim(),
    competitiveLandscape: String(obj.competitiveLandscape).trim(),
    recommendedApproach: String(obj.recommendedApproach).trim(),
    openQuestionsRisks: String(obj.openQuestionsRisks).trim(),
    technicalFitAssessment: {
      opinion: String(tfa.opinion).trim(),
      summary: String(tfa.summary).trim(),
      dimensions: tfa.dimensions.map((d) => ({
        name: String(d.name ?? "").trim(),
        assessment: String(d.assessment ?? "").trim(),
        confidence: String(d.confidence ?? "").trim(),
      })),
      keyUnknowns: String(tfa.keyUnknowns ?? "").trim(),
      nextSteps: Array.isArray(tfa.nextSteps) ? tfa.nextSteps.map((s) => String(s).trim()) : [],
    },
  };

  return { sections, summary };
}

/**
 * Generate structured architect comments using the Engineering AI Model Gateway.
 * Builds prompt, calls gateway, parses response. No fallback; throws if key missing or call fails.
 *
 * @param {import('./types.js').OpportunityWithRelated} opportunityWithRelated
 * @param {string} guidelinesText
 * @param {{
 *   engAiModelGwKey?: string,
 *   engAiModelGwUrl?: string,
 *   llmModel?: string,
 *   maxLength?: number,
 *   llmCache?: boolean,
 *   llmCacheDir?: string,
 * }} options
 * @returns {Promise<{ sections: object, full: string, summary: string, usage: LlmUsage }>}
 */

/**
 * Verify that the Engineering AI Model Gateway is reachable and the API key is accepted.
 * Makes a minimal POST /chat/completions request (max_tokens: 1) and discards the response.
 * Throws with a human-readable message on any failure.
 *
 * @param {{ apiKey: string, baseUrl: string, model?: string }} options
 * @returns {Promise<{ baseUrl: string, model: string }>}
 */
export async function verifyGateway(options) {
  const { apiKey, baseUrl, model } = options;
  const modelName = model || "gemini-3-flash-preview";
  if (!apiKey?.trim()) throw new Error("ENG_AI_MODEL_GW_KEY is not set.");
  if (!baseUrl?.trim()) throw new Error("ENG_AI_MODEL_GW_URL is not set.");
  const url = `${baseUrl.replace(/\/$/, "")}/chat/completions`;
  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey.trim()}`,
      },
      body: JSON.stringify({
        model: modelName,
        messages: [{ role: "user", content: "ping" }],
        max_tokens: 1,
      }),
    });
  } catch (err) {
    throw new Error(`Engineering AI Model Gateway unreachable: ${err.message}. Check ENG_AI_MODEL_GW_URL.`);
  }
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(
      `Engineering AI Model Gateway returned ${res.status}. Check ENG_AI_MODEL_GW_URL and ENG_AI_MODEL_GW_KEY.${body ? ` (${body.slice(0, 120)})` : ""}`
    );
  }
  return { baseUrl, model: modelName };
}

export async function generateArchitectCommentsWithLLM(opportunityWithRelated, guidelinesText, options = {}) {
  const opportunityId = opportunityWithRelated?.Id ?? "";
  const lastModifiedDate = opportunityWithRelated?.LastModifiedDate ?? opportunityWithRelated?.LastModified ?? "";
  const modelName = options.llmModel ?? "gemini-3-flash-preview";
  const useCache = options.llmCache !== false;
  const cacheDir = options.llmCacheDir ?? DEFAULT_CACHE_DIR;

  if (useCache && opportunityId) {
    const cached = await getCached(cacheDir, opportunityId, lastModifiedDate, guidelinesText ?? "", modelName);
    if (cached) return { ...cached, full: assembleFull(cached.sections) };
  }

  const { systemPrompt, userPrompt } = buildPromptForOpportunity(opportunityWithRelated, guidelinesText);
  const messages = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt },
  ];

  const result = await callGateway(messages, {
    apiKey: options.engAiModelGwKey ?? "",
    baseUrl: options.engAiModelGwUrl ?? "",
    model: modelName,
  });

  const { sections, summary } = parseLlmCommentResponse(result.content, {
    maxLength: options.maxLength ?? SUMMARY_MAX_LENGTH,
  });
  const full = assembleFull(sections);
  const out = { sections, full, summary, usage: result.usage };

  if (useCache && opportunityId) {
    await setCached(cacheDir, opportunityId, lastModifiedDate, guidelinesText ?? "", modelName, out);
  }
  return out;
}
