# Desktop packaging (Tauri v2)

## Runtime decision: Bun sidecar

The web GUI and markdown pipeline depend on **Bun** (`Bun.serve`, `Bun.spawn`, `Bun.file`, etc.). For the desktop shell we:

1. **Bundle** a copy of `web/`, `src/`, and `scripts/` into `bundle-tauri-app/`, write a **production-only** `package.json` (no `devDependencies`), and run `bun install --production` before `tauri build` (see [scripts/prepare-tauri-bundle.js](../scripts/prepare-tauri-bundle.js)).
2. **Spawn** `bun run src/web-server.js` from the Tauri (Rust) process. In **development**, the working directory is the **repository root** (where `src/web-server.js` exists). In **release**, the working directory is the app **`resource_dir()`** — Tauri places each listed resource (`web/`, `src/`, `scripts/`, `package.json`, `node_modules/`) at the top level of that directory, not under a `bundle-tauri-app/` subfolder.
3. **Require** a system-installed **`bun`** on `PATH` (same as local development). We do not embed the Bun binary in the installer; that could be a future optimization.

**Why not Node in v1?** Porting [src/web-server.js](../src/web-server.js) and [scripts/opportunities-to-markdown.js](../scripts/opportunities-to-markdown.js) off Bun APIs would be a larger change. The sidecar approach keeps one runtime and matches [README.md](../README.md) install steps.

## Tooling prerequisites

- **Rust** – Stable toolchain with `cargo` (for `tauri build`). Install via [rustup](https://rustup.rs/).
- **Bun** – [bun.sh](https://bun.sh).

## External prerequisites (not bundled)

- **Salesforce CLI** (`sf`) on `PATH`, authenticated org (`sf org login web` or equivalent).
- **Environment variables** for LLM and optional guidelines (`ENG_AI_MODEL_GW_KEY`, etc.) — typically from a shell profile, `.env` loaded by Bun, or system env when launching the app.
- The Tauri app inherits the parent process environment when started from a terminal; when launched from Finder/dock, only the macOS/Windows user environment applies (configure `launchctl` / system env if needed).

## Build flow

1. `bun run scripts/prepare-tauri-bundle.js` (or `bun src-tauri/prepare-bundle.mjs` from the repo root) — copies sources, production `bun install`, writes `bundle-tauri-app/` (gitignored).
2. `tauri build` — `beforeBuildCommand` in [src-tauri/tauri.conf.json](../src-tauri/tauri.conf.json) runs [src-tauri/prepare-bundle.mjs](../src-tauri/prepare-bundle.mjs) so the bundle is created with the correct working directory (Tauri runs this from the **repository root**). Then Tauri embeds the listed resource paths and compiles the Rust shell.

## Development

From the repo root:

```bash
bun install
bun run tauri:dev
```

This starts the Bun HTTP server (spawned by Rust) and opens a native window to `http://127.0.0.1:14238` (fixed port; change `WEB_SERVER_PORT` in [src-tauri/src/lib.rs](../src-tauri/src/lib.rs) and the window `url` in [tauri.conf.json](../src-tauri/tauri.conf.json) together if needed). **`build.devUrl` is intentionally unset:** if it were set, `tauri dev` would wait for that URL before starting the Rust process, but nothing listens until `setup()` spawns Bun—a deadlock.

## Production installer

```bash
bun run tauri:build
```

Artifacts appear under `src-tauri/target/release/bundle/`. Code signing and notarization are platform-specific (see [Tauri distribution](https://tauri.app/distribute/)).
