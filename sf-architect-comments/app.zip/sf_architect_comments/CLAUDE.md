# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Purpose

This tool combines structured Salesforce CRM data with unstructured architect commentary to produce two outputs per opportunity:
1. A comprehensive **Architect Point of View** (300–500 words)
2. A condensed **summary** of ≤240 characters suitable for the `Architect_Comments__c` CRM field

## Domain Context

- **Industry:** Technology, Media, and Telecommunications (TMT)
- **Team:** Pre-sales Enterprise and Technical Architects at Salesforce
- **Audience:** Internal — sales leadership and executive sponsors
- **Account tier:** Strategic and Enterprise only
- **Coverage examples:** T-Mobile, DIRECTV, Lumen, Cox Communications

## Output Structure

### Full POV — six sections (bold markdown headers)

1. **Customer Context** — Who the customer is, their strategic moment, and what they're trying to solve.
2. **Opportunity Summary** — What Salesforce is being asked to deliver, deal stage, and key signals (size, timeline, competition).
3. **Architectural Assessment** — Key technical considerations, risks, integration complexity, or platform fit concerns.
4. **Competitive Landscape** — Known competitors, their positioning, and Salesforce's differentiated strengths. Flag as open item when no competitor data is available.
5. **Recommended Approach** — Architect team's recommended path forward, including any pre-sales technical actions needed.
6. **Open Questions / Risks** — Unresolved issues that could affect deal success or delivery confidence.

### 240-character summary constraints

- Capture: customer name, core opportunity, and the single most important architect signal (risk, recommendation, or differentiator)
- Do **not** start with "Salesforce" or the customer name alone
- Plain, direct language — no jargon
- Must be usable as a CRM field value or executive briefing snippet

## Tone & Style

- Write as a trusted advisor, not a vendor
- No generic Salesforce marketing language
- Direct, specific, grounded in the customer's actual context
- Lead with business impact when addressing executive audiences
- When architect comments conflict, synthesize into a balanced view and flag uncertainty

## Refinement Prompts (Reference)

**When there's competitive tension:**
> Rewrite the Competitive Landscape section with a sharper focus on where [COMPETITOR] is weakest relative to Salesforce's [PRODUCT/CLOUD] capabilities in a TMT context.

**When architect comments conflict:**
> The architect comments contain differing perspectives. Synthesize them into a single, balanced assessment, noting where consensus exists and where there is genuine uncertainty.

**When the POV needs exec-level framing:**
> Reframe the Recommended Approach section for a Salesforce VP or SVP audience who will use this to decide whether to engage an executive sponsor. Lead with business impact, not technical detail.

## Runtime

This project uses **Bun** exclusively (not Node.js). All commands use `bun`.

## Commands

```bash
bun install          # Install dependencies
bun test             # Run all tests
bun test --watch     # Run tests in watch mode
bun run src/cli.js -- --only-verify-login   # Confirm Salesforce CLI login
bun run src/cli.js -- --dry-run --stub-guidelines  # Dry run with stub guidelines
```

Run a single test file:
```bash
bun test tests/generator.test.js
```

## Architecture

The tool generates `Architect_Comments__c` for Salesforce Opportunity records. It **never writes to Salesforce directly**; it produces files for manual Data Loader import.

### Data flow

1. **Fetch opportunities** (`src/sf.js`) — runs `sf data query` (unified Salesforce CLI only; no legacy `sfdx`) and normalizes records. Also runs batched related-data queries for line items, contact roles, tasks, cases, and related opportunities on the same account.
2. **Fetch guidelines** (`src/guidelines.js`) — downloads a Google Doc via export URL (requires "anyone with link" sharing), or reads a local file.
3. **Analyze** (`src/analyzer.js`) — pure functions that derive structured data: context, technical scope, engagement, and risk signals from an `OpportunityWithRelated`.
4. **Generate** (`src/generator.js` or `src/llm.js`) — produces two outputs per opportunity:
   - **Full POV** (300–500 words, six sections per output structure above)
   - **Summary** (≤240 chars for `Architect_Comments__c`, truncated at word boundary with `…`)
5. **Write outputs** (`src/csv.js`) — Data Loader–ready CSV (`Id`, `Architect_Comments__c`) and a full-comment JSON array.

### Source modules

| File | Role |
|------|------|
| `src/cli.js` | Entry point; `commander` CLI; orchestrates all stages |
| `src/config.js` | Merges config from env vars and optional JSON config file; CLI flags override both |
| `src/soql.js` | Core SOQL with configurable date range and role filter; hardcoded stage/amount constraints |
| `src/soql-related.js` | Batched SOQL helpers for related objects (chunks Ids) |
| `src/sf.js` | `runSf`/`runSfQuery` wrappers; all normalization functions; file I/O for incremental testing |
| `src/guidelines.js` | Fetches from Google Doc export URL or local file |
| `src/analyzer.js` | Pure analysis functions: `analyzeContext`, `analyzeTechnical`, `analyzeEngagement`, `analyzeRisks` |
| `src/generator.js` | Rule-based generation: `generateArchitectComments` returns `{ full, summary }` |
| `src/llm.js` | LLM-based generation (OpenAI or Anthropic); same `{ full, summary, usage }` return shape; **no fallback** to rule-based when enabled |
| `src/csv.js` | CSV builder and file writers |
| `src/types.js` | JSDoc `@typedef` only; no runtime code |

### SOQL filters

`src/soql.js` exports `buildOpportunitiesSoql(options)` which accepts `closeDateFrom`, `closeDateTo`, and `opportunityOwnerRoleLike` overrides (all passed from config). Defaults: `CloseDate` from first of current month to 12 months out; role filter `AMER - ACC - TMT - STRAT - MEDIATELCO%`. Stage filters, `Amount > 0`, empty `Architect_Comments__c`, and the `%W - KA - DIS` exclusion are hardcoded. The `OPPORTUNITIES_SOQL` constant (= `buildOpportunitiesSoql()` with defaults) is kept for backward compatibility in tests.

### LLM mode

Set `USE_LLM=true` and `ENG_AI_MODEL_GW_KEY` for the Engineering AI Model Gateway. When enabled, there is no fallback to rule-based generation; failure exits with an error.

### Incremental testing flags

`--only-verify-login`, `--only-opportunities`, `--only-guidelines`, `--only-generate` let you test one stage at a time. Use `--opportunities-file` to skip SF queries and `--stub-guidelines` to skip the Google Doc fetch.

### Tests

Tests live in `tests/` and use `bun:test`. They are unit/integration style against fixtures and do **not** call live Salesforce or Google APIs.

## File Conventions

- `CLAUDE.md` — This file; committed to git and shared with the architect team.
- `CLAUDE.local.md` — Personal/private config (sandbox URLs, personal org field names, notes); gitignored. Create locally as needed.
- Do not store actual opportunity data or customer names in any committed file.
