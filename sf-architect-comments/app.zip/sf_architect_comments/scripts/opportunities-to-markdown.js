#!/usr/bin/env bun
/**
 * Build a markdown report from opportunities JSON by invoking src/cli.js per opportunity.
 *
 * Usage:
 * - bun run scripts/opportunities-to-markdown.js [input.json] [output.md]
 * - bun run scripts/opportunities-to-markdown.js --opportunity-id=<id> [input.json] [output.md]
 *
 * In --opportunity-id mode, defaults are:
 * - input: <id>.json
 * - output: output/<id>.md
 */

function formatAmount(n) {
  if (n == null || Number.isNaN(Number(n))) return "—";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);
}

/**
 * Escape a string for use inside a Markdown table cell.
 * Collapses newlines to a space, escapes pipes, and escapes $$ to avoid
 * triggering LaTeX math mode in renderers such as Obsidian.
 */
function escapeCell(s) {
  if (s == null || s === "") return "—";
  return String(s)
    .replace(/\n/g, " ")
    .replace(/\|/g, "\\|")
    .replace(/\$\$/g, "\\$\\$");
}

function parseCliStderr(stderr) {
  let model = "—";
  let inputTokens = "—";
  let outputTokens = "—";
  let cached = false;
  for (const line of stderr.split("\n")) {
    const m = line.match(/^LLM model: (.+)$/);
    if (m) {
      const raw = m[1].trim();
      cached = raw.includes("(cached)");
      model = cached ? raw.replace(/\s*\(cached\)\s*$/, "").trim() : raw;
    }
    const i = line.match(/^Input tokens: (\d+)$/);
    if (i) inputTokens = i[1];
    const o = line.match(/^Output tokens: (\d+)$/);
    if (o) outputTokens = o[1];
  }
  return { model, inputTokens, outputTokens, cached };
}

async function runCliForOpportunity(opportunityId, projectRoot) {
  const start = performance.now();
  const proc = Bun.spawn(
    ["bun", "run", "src/cli.js", "--", "--use-llm", "--opportunity-id", opportunityId, "--stub-guidelines", "--json-output"],
    { stdout: "pipe", stderr: "pipe", cwd: projectRoot, env: process.env }
  );
  const [stdout, stderr] = await Promise.all([proc.stdout.text(), proc.stderr.text()]);
  const exitCode = await proc.exited;
  const durationMs = performance.now() - start;
  const parsedErr = parseCliStderr(stderr);

  let sections = null;
  let summary = "—";
  let parseError = null;
  let gateway = "—";
  if (exitCode === 0) {
    try {
      const json = JSON.parse(stdout);
      sections = json.sections ?? null;
      summary = json.summary ?? "—";
      gateway = json.gateway ?? "—";
    } catch (e) {
      parseError = e instanceof Error ? e.message : String(e);
    }
  }

  return {
    sections,
    summary,
    gateway,
    durationMs,
    ...parsedErr,
    ok: exitCode === 0,
    stderr: exitCode !== 0 ? stderr : undefined,
    parseError: parseError ?? undefined,
    cached: parsedErr.cached,
  };
}

function parseArgs(argv) {
  let opportunityId = null;
  const positional = [];

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--opportunity-id") {
      const next = argv[i + 1];
      if (!next || next.startsWith("--")) {
        throw new Error("Missing value for --opportunity-id");
      }
      opportunityId = next;
      i += 1;
      continue;
    }
    if (arg.startsWith("--opportunity-id=")) {
      const value = arg.slice("--opportunity-id=".length);
      if (!value) throw new Error("Missing value for --opportunity-id");
      opportunityId = value;
      continue;
    }
    positional.push(arg);
  }

  return {
    opportunityId,
    inputPathArg: positional[0],
    outputPathArg: positional[1],
  };
}

async function main() {
  const { opportunityId, inputPathArg, outputPathArg } = parseArgs(process.argv);
  const inputPath = inputPathArg ?? (opportunityId ? `${opportunityId}.json` : "opportunities.json");
  const outputPath = outputPathArg ?? (opportunityId ? `output/${opportunityId}.md` : "output/opportunities.md");
  const projectRoot = process.cwd();

  const data = await Bun.file(inputPath).json();
  const opportunities = Array.isArray(data) ? data : [data];

  const lines = [
    "# Opportunities Report",
    "",
    `Generated from **${opportunities.length}** opportunity(ies) using LLM.`,
    "",
    "---",
    "",
  ];

  /** When the inner CLI fails, we still write a diagnostic .md but must exit non-zero so callers (e.g. web GUI) report failure. */
  let cliFailureCount = 0;

  for (let i = 0; i < opportunities.length; i++) {
    const opp = opportunities[i];
    const id = opp.Id ?? "";
    const accountName = opp["Account.Name"] ?? "—";
    const name = opp.Name ?? "—";
    const amount = formatAmount(opp.Amount);
    const closeDate = opp.CloseDate ?? "—";
    const lastModifiedDate = opp.LastModifiedDate ?? "—";
    const stageName = opp.StageName ?? "—";
    const ownerName = opp["Owner.Name"] ?? "—";

    process.stderr.write(`[${i + 1}/${opportunities.length}] ${id} ... `);
    const result = await runCliForOpportunity(id, projectRoot);
    if (!result.ok) {
      cliFailureCount += 1;
      const errLine = result.stderr?.split("\n").find((l) => l.trim().startsWith("Error:"))?.trim() ?? result.stderr?.split("\n")[0]?.trim();
      process.stderr.write(errLine ? `failed: ${errLine}\n` : "failed\n");
      if (result.stderr) process.stderr.write(result.stderr);
    } else {
      process.stderr.write(result.cached ? "ok (cached)\n" : "ok\n");
    }

    const { sections } = result;
    const summary = result.summary ?? "—";
    const gateway = result.gateway ?? "—";
    const durationMs = result.durationMs ?? 0;
    const durationStr = durationMs >= 1000 ? `${(durationMs / 1000).toFixed(2)}s` : `${Math.round(durationMs)}ms`;
    const model = result.model ?? "—";
    const inputTokens = result.inputTokens ?? "—";
    const outputTokens = result.outputTokens ?? "—";
    const cacheUsed = result.cached === true;
    const errorMessage = !result.ok
      ? (result.stderr?.split("\n").find((l) => l.trim().startsWith("Error:"))?.trim() ?? result.stderr?.split("\n")[0]?.trim() ?? "CLI exited with an error")
      : result.parseError
        ? `Could not parse CLI output: ${result.parseError}`
        : null;

    // Opportunity heading
    lines.push(`## ${i + 1}. ${escapeCell(name)}`);
    lines.push("");

    // Compact metadata table — no long-form content
    lines.push("| Field | Value |");
    lines.push("| ----- | ----- |");
    lines.push(`| **Account** | ${escapeCell(accountName)} |`);
    lines.push(`| **Id** | \`${id}\` |`);
    lines.push(`| **Amount** | ${amount} |`);
    lines.push(`| **Close Date** | ${escapeCell(closeDate)} |`);
    lines.push(`| **Last Modified** | ${escapeCell(lastModifiedDate)} |`);
    lines.push(`| **Stage** | ${escapeCell(stageName)} |`);
    lines.push(`| **Owner** | ${escapeCell(ownerName)} |`);
    lines.push(`| **Gateway** | ${escapeCell(gateway)} |`);
    lines.push(`| **Model** | ${escapeCell(model)} |`);
    lines.push(`| **Tokens** | ${inputTokens} in / ${outputTokens} out |`);
    lines.push(`| **Cache** | ${cacheUsed ? "Yes" : "No"} |`);
    lines.push(`| **Duration** | ${durationStr} |`);
    if (errorMessage) {
      lines.push(`| **Status** | ⚠ ${escapeCell(errorMessage)} |`);
    }
    lines.push("");

    // Architect Point of View — render each section individually
    lines.push("### Architect Point of View");
    lines.push("");

    if (sections) {
      const proseSections = [
        ["Customer Context", sections.customerContext],
        ["Opportunity Summary", sections.opportunitySummary],
        ["Architectural Assessment", sections.architecturalAssessment],
        ["Competitive Landscape", sections.competitiveLandscape],
        ["Recommended Approach", sections.recommendedApproach],
        ["Open Questions / Risks", sections.openQuestionsRisks],
      ];

      for (const [title, content] of proseSections) {
        lines.push(`**${title}** – ${content ?? "—"}`);
        lines.push("");
      }

      const tfa = sections.technicalFitAssessment;
      if (tfa) {
        lines.push("**Technical Fit Assessment**");
        lines.push("");
        lines.push(`Opinion: ${tfa.opinion ?? "—"}`);
        lines.push("");
        lines.push(`Summary: ${tfa.summary ?? "—"}`);
        lines.push("");

        if (Array.isArray(tfa.dimensions) && tfa.dimensions.length > 0) {
          lines.push("Dimension Breakdown:");
          lines.push("");
          lines.push("| Dimension | Assessment | Confidence |");
          lines.push("| --------- | ---------- | ---------- |");
          for (const d of tfa.dimensions) {
            lines.push(`| ${escapeCell(d.name)} | ${escapeCell(d.assessment)} | ${escapeCell(d.confidence)} |`);
          }
          lines.push("");
        }

        if (tfa.keyUnknowns) {
          lines.push("Key Unknowns:");
          lines.push("");
          lines.push(tfa.keyUnknowns);
          lines.push("");
        }

        if (Array.isArray(tfa.nextSteps) && tfa.nextSteps.length > 0) {
          lines.push("Recommended Next Steps:");
          lines.push("");
          for (let j = 0; j < tfa.nextSteps.length; j++) {
            lines.push(`${j + 1}. ${tfa.nextSteps[j]}`);
          }
          lines.push("");
        }
      }
    } else {
      if (errorMessage) {
        lines.push(`*No comment generated. ${escapeCell(errorMessage)}*`);
        lines.push("");
      } else {
        lines.push("—");
        lines.push("");
      }
    }

    // 240-char summary as a blockquote
    lines.push("### Proposed Org62 Comment");
    lines.push("");
    lines.push(`> ${summary}`);
    lines.push("");
    lines.push("---");
    lines.push("");
  }

  await Bun.write(outputPath, lines.join("\n"), { encoding: "utf-8" });
  console.log(`Wrote ${outputPath} (${opportunities.length} opportunities).`);
  if (cliFailureCount > 0) {
    process.stderr.write(
      `${cliFailureCount} opportunity(ies) failed CLI generation; see Status rows in ${outputPath}.\n`
    );
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
