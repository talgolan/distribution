#!/usr/bin/env bun
/**
 * Copies application sources into bundle-tauri-app/ for Tauri resource bundling,
 * writes a production-only package.json (no devDependencies), then runs bun install --production.
 * Run before: tauri build (see src-tauri/tauri.conf.json beforeBuildCommand).
 */
import { cp, copyFile, chmod, mkdir, rm, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = join(__dirname, "..");
const bundleRoot = join(projectRoot, "bundle-tauri-app");
const bunCacheDir = join(projectRoot, ".bun-bundle-cache");

const dirsToCopy = ["web", "src", "scripts"];

/**
 * Download the platform-appropriate bun binary and place it at bundle-tauri-app/bin/bun.
 *
 * The binary is cached at .bun-bundle-cache/bun-<platform>-<arch> so it is only
 * downloaded once. Delete that directory to force a fresh download.
 *
 * @param {string} binDir  - destination directory (bundle-tauri-app/bin)
 * @param {string} cacheDir - persistent cache directory (.bun-bundle-cache)
 */
async function downloadBun(binDir, cacheDir) {
  const { platform, arch } = process;

  if (platform !== "darwin" && platform !== "linux") {
    throw new Error(
      `Bun bundling is not supported on platform "${platform}". ` +
      "Only darwin and linux are supported."
    );
  }

  const bunArch = arch === "arm64" ? "aarch64" : "x64";
  const zipName = `bun-${platform}-${bunArch}.zip`;
  // The zip contains a single directory: bun-<platform>-<arch>/bun
  const innerEntry = `bun-${platform}-${bunArch}/bun`;
  const cacheFile = join(cacheDir, `bun-${platform}-${bunArch}`);
  const destFile = join(binDir, "bun");

  await mkdir(binDir, { recursive: true });

  // Use cached binary when available — avoids re-downloading on every build.
  if (existsSync(cacheFile)) {
    await copyFile(cacheFile, destFile);
    await chmod(destFile, 0o755);
    console.log(`bun: using cached binary (${cacheFile})`);
    return;
  }

  const url = `https://github.com/oven-sh/bun/releases/latest/download/${zipName}`;
  console.log(`bun: downloading ${url} ...`);

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to download bun (HTTP ${res.status}) from ${url}`);
  }

  const tmpDir = join(cacheDir, "_tmp");
  await mkdir(tmpDir, { recursive: true });
  const zipPath = join(tmpDir, zipName);

  await Bun.write(zipPath, res);

  const extract = spawnSync("unzip", ["-o", "-j", zipPath, innerEntry, "-d", tmpDir], {
    stdio: "inherit",
  });
  if (extract.status !== 0) {
    throw new Error(`unzip failed with exit code ${extract.status}`);
  }

  const extractedBun = join(tmpDir, "bun");

  // Persist to cache so subsequent builds skip the download.
  await mkdir(cacheDir, { recursive: true });
  await copyFile(extractedBun, cacheFile);
  await chmod(cacheFile, 0o755);

  await copyFile(extractedBun, destFile);
  await chmod(destFile, 0o755);

  await rm(tmpDir, { recursive: true, force: true });

  console.log(`bun: ready at ${destFile}`);
}

async function main() {
  await rm(bundleRoot, { recursive: true, force: true });
  await mkdir(bundleRoot, { recursive: true });

  for (const name of dirsToCopy) {
    await cp(join(projectRoot, name), join(bundleRoot, name), { recursive: true });
  }

  const pkgPath = join(projectRoot, "package.json");
  const pkg = { ...(await Bun.file(pkgPath).json()) };
  delete pkg.devDependencies;
  await writeFile(join(bundleRoot, "package.json"), `${JSON.stringify(pkg, null, 2)}\n`, "utf-8");

  const r = spawnSync("bun", ["install", "--production"], {
    cwd: bundleRoot,
    stdio: "inherit",
    env: process.env,
  });
  if (r.status !== 0) {
    throw new Error(`bun install --production failed with exit ${r.status}`);
  }

  await downloadBun(join(bundleRoot, "bin"), bunCacheDir);

  console.log(`Prepared Tauri bundle at ${bundleRoot}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
