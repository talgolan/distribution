#!/usr/bin/env bash
set -e

# Make sure bun is on PATH (handles machines where it's installed but not in /usr/bin)
export BUN_INSTALL="${BUN_INSTALL:-$HOME/.bun}"
export PATH="$BUN_INSTALL/bin:$PATH"

PORT=${WEB_PORT:-3000}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Starting Architect Comments at http://localhost:$PORT ..."
cd "$SCRIPT_DIR"

# Start server in background
bun run web &
SERVER_PID=$!

# Wait up to 10 seconds for the server to accept connections
for i in $(seq 1 20); do
  if curl -sf "http://localhost:$PORT" >/dev/null 2>&1; then
    open "http://localhost:$PORT"
    break
  fi
  sleep 0.5
done

# Bring server to foreground so Ctrl-C stops it cleanly
wait $SERVER_PID
