# Architect Comments CLI

A command-line tool that **generates and maintains the `Architect_Comments__c` field** on Opportunity records in your Salesforce org. It reads opportunities via the **unified Salesforce CLI (`sf`) only** (no legacy `sfdx` commands), fetches Architect guidelines from a Google Doc URL (or local file), and outputs **(1) a Data Loader–ready CSV** for updating `Architect_Comments__c` and **(2) a separate full-comment file** (JSON) with comprehensive Slackbot-style architect comments. The app does **not** write to Salesforce directly; updates are performed exclusively using [Salesforce Data Loader](https://developer.salesforce.com/tools/data-loader/).

## Purpose

- **Inputs**: Opportunities (from SOQL, with optional related data: line items, contact roles, tasks, cases, related opportunities), SE_Comments__c, Einstein Opportunity Score (IqScore), StageName, and Architect guidelines (Google Doc or file).
- **Outputs**:
  1. **CSV** – Columns `Id` and `Architect_Comments__c` (≤ 240 characters) for Data Loader **Update** on Opportunity.
  2. **Full-comment file** – JSON array of `{ Id, Name?, FullComment }` with a comprehensive comment (~200–300 words) in six sections: Solution Summary, Technical Scope, Architecture Considerations, Risk Mitigation, Next Steps, Stage Assessment.
- **Dry run**: Use `--dry-run` to print proposed comments and write to separate dry-run CSV and dry-run full-comment JSON.

This application uses **the user's credentials as set for the Salesforce Command Line tool**. There is no separate Salesforce login in the app; you must be authenticated with the **unified Salesforce CLI (`sf`)** and have a default org set (or pass `--target-org`).

---

## Prerequisites

- **Bun** – [bun.sh](https://bun.sh) (runtime for this app).
- **Rust toolchain** (`cargo`, `rustc`) – only if you build the optional **Tauri desktop app** (`bun run tauri:build`). See [docs/PACKAGING.md](docs/PACKAGING.md).
- **Salesforce CLI (unified `sf` only)** – [Salesforce CLI Command Reference (unified)](https://developer.salesforce.com/docs/atlas.en-us.sfdx_cli_reference.meta/sfdx_cli_reference/cli_reference_unified.htm).  
**No legacy `sfdx` commands** are used or supported. Install the current CLI and authenticate, for example:
  - `sf org login web` (then set a default org or use `--target-org` when running this app).
- **Google Doc** – The guidelines document must be shared so the export URL is accessible (e.g. “Anyone with the link can view”). Alternatively, use `--guidelines-file` with a local file.

---

## Installation

```bash
bun install
```

---

## Configuration

Configuration is from **environment variables** and/or a **JSON config file** (e.g. `--config path/to/config.json`). CLI flags override env and config.


| Source      | Variables / keys                                                                                                                                                                                                                                                                      |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Env         | `GUIDELINES_DOC_URL`, `GUIDELINES_FILE`, `OUTPUT_PATH`, `OUTPUT_FULL_PATH`, `SF_TARGET_ORG`, `MAX_COMMENT_LENGTH`, `FETCH_RELATED_DATA`, `CASE_OPPORTUNITY_FIELD`, `OPPORTUNITY_OWNER_ROLE_LIKE`, `OWNER_MANAGER_NAMES`, `USE_LLM`, `ENG_AI_MODEL_GW_KEY`, `ENG_AI_MODEL_GW_URL`, `ENG_AI_MODEL`, `LLM_MODEL`, `LLM_CACHE`, `LLM_CACHE_DIR` |
| Config file | `guidelinesUrl`, `guidelinesFile`, `outputPath`, `outputFullPath`, `targetOrg`, `maxCommentLength`, `fetchRelatedData`, `caseOpportunityField`, `opportunityOwnerRoleLike`, `ownerManagerNames`, `useLlm`, `engAiModelGwKey`, `engAiModelGwUrl`, `llmModel`, `llmCache`, `llmCacheDir`                                                 |
| CLI         | `--guidelines-url`, `--guidelines-file`, `--opportunity-owner-role-like`, `--owner-manager-names`, `--output`, `--output-full`, `--use-llm`, `--target-org`, `--config`                                                                                                                                        |


Copy `.env.example` to `.env` and set values as needed. Do **not** commit `.env` or config files that contain secrets (this app does not use Salesforce credentials in env; auth is via `sf` only).

---

## Usage

**Run (generate CSV for Data Loader):**

```bash
bun run src/cli.js -- --guidelines-url "https://docs.google.com/document/d/YOUR_DOC_ID/edit"
# Or with env: GUIDELINES_DOC_URL=... bun run src/cli.js
```

### Web GUI — Quick Start (share with teammates)

Each person runs the app locally. One command handles all prerequisites and sets up a daily launcher:

```bash
bash <(curl -fsSL https://distribution.usefulto.us/sf-architect-comments/install.sh)
```

This checks for and installs Bun, Homebrew, curl, unzip, and the Salesforce CLI if any are missing, downloads the app to `~/sf-architect-comments`, and adds a `sfac` alias to your shell.

**Daily use** (after setup):

```bash
sfac
```

Starts the server and opens `http://localhost:3000` automatically. Press `Ctrl-C` to stop.

**Updating:**

```bash
bash ~/sf-architect-comments/install.sh
```

Re-run the installer — it detects that the app is already installed and offers to download the latest version.

**First launch:** open ⚙ Settings in the app to enter your Engineering AI Gateway key (`ENG_AI_MODEL_GW_KEY`). You will also need to authenticate the Salesforce CLI against org62 once if you haven't already:

```bash
sf org login web --instance-url https://org62.my.salesforce.com --alias org62
```

---

### Publishing a new release (maintainers only)

The distribution ZIP is built and published automatically by GitHub Actions on every push to `main`. No manual step is required.

The workflow ([`.github/workflows/publish-dist.yml`](.github/workflows/publish-dist.yml)):
1. Zips the source (excluding `.env`, `node_modules/`, `output/`, `bun.lock`, `src-tauri/`)
2. Commits `app.zip` and `install.sh` to `sf-architect-comments/` in the public distribution repo [`talgolan/distribution`](https://github.com/talgolan/distribution)
3. GitHub Pages serves them at `https://distribution.usefulto.us/sf-architect-comments/`

**One-time setup** (already done; documented here for reference):
- Created public repo `talgolan/distribution` with GitHub Pages enabled on a custom domain (`distribution.usefulto.us`, source: `main` branch, root `/`)
- Added a `DIST_REPO_TOKEN` secret (GitHub PAT with `repo` scope on the dist repo) to this private repo's Actions secrets

---

### Web GUI (developer run)

Run a local browser GUI to load opportunities from JSON, select records, and process selected IDs through the existing LLM flow:

```bash
bun run web        # server only — open http://localhost:3000 manually
bun run web:open   # server + auto-open browser
```

### Desktop app (Tauri v2)

You can run the same web UI in a **native window** (Rust shell + WebView) that starts the Bun HTTP server automatically:

```bash
bun install
bun run tauri:dev
```

Production installers: `bun run tauri:build` (runs [src-tauri/prepare-bundle.mjs](src-tauri/prepare-bundle.mjs), then compiles the Tauri app). See [docs/PACKAGING.md](docs/PACKAGING.md) for bundling, code signing, and the Bun sidecar design.

**Install / run expectations (same as the browser GUI):**

- **`sf`** must be on `PATH` and authenticated (`sf org login web`, default org or `SF_TARGET_ORG`).
- **LLM:** set `ENG_AI_MODEL_GW_KEY` (and optional `ENG_AI_MODEL_GW_URL`, model vars). Bun loads a `.env` from the **process working directory** when present (typically the repo root in dev). The packaged app uses the bundled resource folder as `cwd`; put secrets in the macOS user environment, launch from a terminal where you have `export`’d them, or add a `.env` next to the app content if you copy one into the bundle manually.
- **Guidelines:** configure `GUIDELINES_DOC_URL` / `GUIDELINES_FILE` as for the CLI, or rely on the GUI’s defaults.

The desktop app listens on **127.0.0.1:14238** (see `WEB_SERVER_PORT` in [src-tauri/src/lib.rs](src-tauri/src/lib.rs) and the window `url` in [src-tauri/tauri.conf.json](src-tauri/tauri.conf.json); `build.devUrl` is omitted so `tauri dev` does not wait for the server before Rust starts).

- By default, the GUI loads `mcmahan.json` from the project root via `GET /api/opportunities`.
- On load/reload, the GUI also discovers previously processed opportunities from `output/<id>.md` and pre-populates `Processing Results` plus row-level `View Result` buttons.
- Processing uses `POST /api/process` and runs each selected ID synchronously through:
  - `bun run scripts/opportunities-to-markdown.js --opportunity-id <id>`
- The server writes/reads per-opportunity markdown files at `output/<id>.md`.
- The GUI can load each markdown file via `GET /api/markdown/:id` and switch between rendered and raw markdown views.
- The GUI includes `Clear Cache`, which calls `POST /api/cache/clear` and removes entries under `.llm-cache`.
- The opportunities table shows `Manager` (`Owner_Manager_Name__c`), supports sortable visible columns, and defaults to `Close Date` descending.
- Default pagination is 50 rows/page; change it with the rows-per-page control. Sort and pagination settings persist across browser reloads.
- `Processing Results` shows Opportunity Name, Opportunity ID, Account, Owner, Manager, and Amount.
- While processing is active, the GUI opens a live progress modal with current opportunity, rolling logs, and completion progress.
- Cache usage is surfaced per processed opportunity (`cached` vs `not cached`) based on CLI output (`LLM model: ... (cached)`).
- Press `Ctrl-C` in the terminal running `bun run web` to stop the server gracefully.
- To use another port, set `WEB_PORT`, e.g. `WEB_PORT=4000 bun run web`.

**Dry run (print proposed comments and write to `*_dry_run.csv`):**

```bash
bun run src/cli.js -- --dry-run --guidelines-url "https://docs.google.com/document/d/YOUR_DOC_ID/edit"
# Or: bun run dry-run  (if you set GUIDELINES_DOC_URL in .env)
```

**Optional flags:**

- `--guidelines-file <path>` – Use a local file for guidelines (override or fallback if URL fails).
- `--opportunity-owner-role-like <value>` – Override the bulk retrieval `Opportunity_Owner_Role__c LIKE ...` filter for this run. Precedence: CLI flag > config file `opportunityOwnerRoleLike` > env `OPPORTUNITY_OWNER_ROLE_LIKE` > built-in default.
- `--owner-manager-names <names>` – Comma-separated `Owner_Manager_Name__c` values used in the bulk retrieval `IN (...)` filter.
- `--output <path>` – Output CSV path (default: `architect_comments.csv`).
- `--output-full <path>` – Output path for full architect comments JSON (default: `architect_comments_full.json`). One run produces both CSV and full-comment file by default.
- `--opportunity-id <id>` – Test the full workflow for a single opportunity: fetch that opportunity (and related data), generate both the comprehensive comment and the 240-char summary, and print them to **stdout** (no CSV or file output). Requires guidelines (URL, file, or `--stub-guidelines`). Cannot be combined with other `--only-*` flags except `--only-retrieve-opportunity`.
- `--only-retrieve-opportunity` – Fetch a single opportunity by ID and print or write its JSON; requires `--opportunity-id`. Does not fetch guidelines or generate comments. Use `--output path.json` to write to a file; otherwise the opportunity (with related data) is printed to stdout.
- `--use-llm` – Use an LLM via the Engineering AI Model Gateway to generate architect comments from the factual opportunity data. Requires `ENG_AI_MODEL_GW_KEY`. There is **no fallback** to the rule-based generator when `--use-llm` is set; if the key is missing or the call fails, the tool exits with an error.
- `--target-org <alias>` – Passed to `sf` so the SOQL query runs against that org.
- `--config <path>` – Path to JSON config file.

**Related-data and Case config:** Set `fetchRelatedData: false` (or `FETCH_RELATED_DATA=false`) to skip related-data queries (line items, contact roles, tasks, cases, related opportunities). Set `caseOpportunityField` (e.g. `Related_Opportunity__c`) to the Case lookup field that links to Opportunity; if empty, the Case query is skipped. ContentNote is optional and skipped on errors.

**LLM config (when using `--use-llm`):** All LLM access is through the Engineering AI Model Gateway. Set `ENG_AI_MODEL_GW_KEY` to your gateway API key. Optionally set `ENG_AI_MODEL_GW_URL` to override the gateway base URL (default: preprod gateway). Set `ENG_AI_MODEL` or `LLM_MODEL` to the model id (default: `claude-sonnet-4-20250514`). Available models can be listed with: `curl -s -X GET "{baseUrl}/v1/models" -H "Authorization: Bearer $ENG_AI_MODEL_GW_KEY" -H "Content-Type: application/json"`. The tool sends the factual opportunity data and guidelines to the gateway and requests a structured JSON response. No fallback to rule-based generation when LLM is enabled. **Caching:** Responses are cached by opportunity Id, LastModifiedDate hash, guidelines hash, and model in `.llm-cache/` (or `LLM_CACHE_DIR`); set `LLM_CACHE=false` or `LLM_CACHE=0` to disable. When a cached result is used, the CLI prints `(cached)` next to the model name.

---

## Incremental testing

You can test each capability of the tool one at a time. **The first incremental test is confirmation that you are logged in** to the Salesforce CLI.


| Flag                          | Purpose                                                                                                                                        |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `--only-verify-login`         | **First test:** Confirm you are logged in to the Salesforce CLI (`sf`). Runs `sf org display --json`; prints org alias and exits.              |
| `--only-opportunities`        | Test SF only: fetch opportunities via SOQL and write them to a JSON file (default: `opportunities.json`). No guidelines or comment generation. |
| `--only-guidelines`           | Test guidelines fetch only: fetch from URL or file and write to `--output` or stdout. No SF or generator.                                      |
| `--only-generate`             | Test generator + CSV only: requires `--opportunities-file` and guidelines (file, URL, or `--stub-guidelines`). No SF call.                     |
| `--only-retrieve-opportunity` | Fetch a single opportunity by ID and output JSON; requires `--opportunity-id`. No guidelines or comment generation. Use `--output path.json` to write to a file. |
| `--opportunities-file <path>` | Skip SF: load opportunities from a JSON file (same format as `--only-opportunities` output). Use with full pipeline or `--only-generate`.      |
| `--stub-guidelines`           | Skip real guidelines: use a built-in stub string. Use with full pipeline or `--only-generate`.                                                 |


At most one of `--only-verify-login`, `--only-opportunities`, `--only-guidelines`, `--only-generate`, `--only-retrieve-opportunity` may be set.

**Example commands:**

```bash
# First test: confirm you are logged in to the Salesforce CLI
bun run src/cli.js -- --only-verify-login
bun run src/cli.js -- --only-verify-login --target-org my-org

# Test SF only; write opportunities to opportunities.json
bun run src/cli.js -- --only-opportunities --output opportunities.json

# Test SF only with manager override
bun run src/cli.js -- --only-opportunities --owner-manager-names "Rachel McMahan,Michael McTigue" --output opportunities.json

# Test guidelines only; write to guidelines.txt
bun run src/cli.js -- --only-guidelines --guidelines-url "https://docs.google.com/document/d/ID/edit" --output guidelines.txt

# Test generator + CSV only (no SF, no Google Doc)
bun run src/cli.js -- --only-generate --opportunities-file opportunities.json --stub-guidelines --output out.csv

# Full pipeline using saved opportunities (no SF call)
bun run src/cli.js -- --opportunities-file opportunities.json --guidelines-file guidelines.txt --dry-run

# Full pipeline with stub guidelines (no Google Doc)
bun run src/cli.js -- --stub-guidelines --dry-run

# Test full workflow for one opportunity; print full + 240-char summary to stdout
c
bun run src/cli.js -- --opportunity-id 006ed00000TwuE1AAJ --guidelines-file guidelines.txt
```

**Opportunities JSON format** (for `--opportunities-file` and `--only-opportunities` output): a JSON array of objects with the same shape as normalized opportunities: `Id`, `Name`, `Account.Name`, `StageName`, `SE_Comments__c`, `IqScore`, and optionally `CloseDate`, `Type`, `Owner.Name`, `Architect_Comments__c`, `Opportunity_Owner_Role__c`, `Amount`.

---

## SOQL and related data

The app runs a **core opportunity query** via `sf data query` (unified CLI only) using the fiscal-year and manager-focused filters:

- `Opportunity_Owner_Role__c LIKE 'AMER - TMT - ENTR - MT - MTE%'` (override with `OPPORTUNITY_OWNER_ROLE_LIKE`)
- `CloseDate = THIS_FISCAL_YEAR`
- `AmountConverted__c > 0`
- `Owner_Manager_Name__c IN (...)` (dynamic from `OWNER_MANAGER_NAMES` or `--owner-manager-names`)
- `StageName NOT IN ('Dead - Duplicate','Dead - No Opportunity','Dead - No Decision','Dead - Webstore','Dead - Lost','Dead - OEM')`

When related data is enabled, it also runs batched queries for **OpportunityLineItem**, **OpportunityContactRole**, **Task**, **Case** (if `caseOpportunityField` is set, e.g. `Related_Opportunity__c`), and **related opportunities** (same account). Results are grouped by Opportunity Id into an in-memory **OpportunityWithRelated** model used for analysis and both comment types.

**Analysis and synthesis:**

- **Context** – Name, Amount, Stage, Type, products (from line items), account, owner, contact roles, SE_Comments__c, Description, NextStep.
- **Technical** – Product/solution complexity, keywords (e.g. POC, validation, routing, sandbox).
- **Engagement** – Task count, recent activity, cases, related opportunities on account.
- **Risks** – POC/validation language, stage vs probability, technical roles in contact roles.

**Full comment** (written to the JSON file) has six sections: **[Solution Summary]**, **[Technical Scope]**, **[Architecture Considerations]**, **[Risk Mitigation]**, **[Next Steps]**, **[Stage Assessment]**. Target length ~200–300 words; tone professional and actionable.

**240-character summary** (written to the CSV for `Architect_Comments__c`) is derived from the full comment (truncated at word boundary with "…") or built from the same analysis when full is not used.

The summary is **capped at 240 characters** (configurable via `MAX_COMMENT_LENGTH` or `maxCommentLength`).

---

## Outputs: CSV and full-comment file

The tool writes two outputs (paths configurable via `--output` and `--output-full` or config):

1. **CSV** – Headers: `Id`, `Architect_Comments__c` (240-char summary for Data Loader).
2. **Full-comment file** – JSON array of `{ Id, Name?, FullComment }` (comprehensive comment for each opportunity). Default path: `architect_comments_full.json` (dry-run: `architect_comments_full_dry_run.json`).

**Steps in Data Loader:**

1. Open Data Loader and choose **Update**.
2. Select the **Opportunity** object.
3. Map the CSV columns: `Id` → Id, `Architect_Comments__c` → Architect_Comments__c.
4. Run the update.

The app does **not** execute Data Loader; you run it manually after generating the CSV.

---

## Troubleshooting


| Issue                               | What to do                                                                                                                                                                                                                        |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Google Doc returns 403**          | Ensure the doc is shared (e.g. “Anyone with the link”). Use `--guidelines-file` with a local copy as fallback.                                                                                                                    |
| **Missing IqScore in results**      | Confirm Einstein Opportunity Scoring is enabled and the field is available in your org; the field name may differ (configurable in code).                                                                                         |
| `**sf` not found or not logged in** | Install the [unified Salesforce CLI](https://developer.salesforce.com/docs/atlas.en-us.sfdx_cli_reference.meta/sfdx_cli_reference/cli_reference_unified.htm) and run `sf org login web`; set a default org or use `--target-org`. |
| **No legacy sfdx**                  | This app uses **only** the unified `sf` CLI (e.g. `sf data query`, `sf org login web`). Do not use `sfdx` commands.                                                                                                               |


---

## Tests

```bash
bun test
```

Tests are unit and integration-style; they use fixtures and do **not** call live Salesforce or Google APIs by default.

---

## License

UNLICENSED.