**Customer Context** – Paramount Global is a leading entity in the Communications & Media sector, currently leveraging Slack across its organization. They are at a strategic point where they aim to upgrade to Slack Enterprise Plus to enhance collaboration and integrate Slack AI capabilities, aligning with their digital transformation goals. 

**Opportunity Summary** – The opportunity involves upgrading Paramount Global to Slack Enterprise Plus for 30,300 users, valued at $600,000. The deal is in the negotiation stage, with a close date targeted for April 2026. The key challenge is securing necessary customer approvals.

**Architectural Assessment** – The technical complexity is medium, primarily due to the integration of Slack AI. Paramount has successfully completed a Proof of Concept (PoC) for Slack AI, indicating readiness but also highlighting the need for robust integration planning to ensure seamless adoption.

**Competitive Landscape** – There is no specific competitor data available, which remains an open item. However, Salesforce's comprehensive platform capabilities and existing relationship with Paramount provide a competitive edge. 

**Recommended Approach** – We recommend focusing on securing customer approvals swiftly by highlighting the successful PoC outcomes and the strategic benefits of Slack AI integration. Pre-sales should engage with Paramount's procurement to address any legal or compliance concerns promptly. 

**Open Questions / Risks** – The primary risk is the delay in customer approvals, which could impact the timeline. Additionally, the absence of detailed competitor insights could pose a challenge in positioning. Addressing these uncertainties is crucial for deal success.