/**
 * Unit tests for CSV building and escaping.
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { buildCsv, writeCsvReport } from "../src/csv.js";
import { readFile, rm, mkdtemp } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";

describe("buildCsv", () => {
  test("headers are Id and Architect_Comments__c", () => {
    const csv = buildCsv([]);
    expect(csv).toBe("Id,Architect_Comments__c\n");
  });

  test("one row", () => {
    const rows = [{ Id: "006xx", Architect_Comments__c: "Short comment" }];
    const csv = buildCsv(rows);
    expect(csv).toContain("006xx");
    expect(csv).toContain("Short comment");
    expect(csv.split("\n").length).toBe(2);
  });

  test("commas in comment are quoted", () => {
    const rows = [{ Id: "006xx", Architect_Comments__c: "A, B, C" }];
    const csv = buildCsv(rows);
    expect(csv).toContain('"A, B, C"');
  });

  test("quotes in comment are escaped", () => {
    const rows = [{ Id: "006xx", Architect_Comments__c: 'Say "hello"' }];
    const csv = buildCsv(rows);
    expect(csv).toContain('""');
  });

  test("newlines in comment are quoted", () => {
    const rows = [{ Id: "006xx", Architect_Comments__c: "Line1\nLine2" }];
    const csv = buildCsv(rows);
    expect(csv).toContain('"');
  });

  test("multiple rows", () => {
    const rows = [
      { Id: "006a", Architect_Comments__c: "First" },
      { Id: "006b", Architect_Comments__c: "Second" },
    ];
    const csv = buildCsv(rows);
    const lines = csv.split("\n");
    expect(lines.length).toBe(3);
    expect(lines[0]).toBe("Id,Architect_Comments__c");
    expect(lines[1]).toContain("006a");
    expect(lines[2]).toContain("006b");
  });
});

describe("writeCsvReport", () => {
  let tempDir;

  beforeAll(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "csv-report-"));
  });

  afterAll(async () => {
    if (tempDir) await rm(tempDir, { recursive: true, force: true });
  });

  test("writes CSV file with correct content", async () => {
    const outPath = join(tempDir, "out.csv");
    const rows = [{ Id: "006x", Architect_Comments__c: "Test comment" }];
    const csv = buildCsv(rows);
    await writeCsvReport(outPath, csv, rows, [], { verbose: false });
    const content = await readFile(outPath, "utf-8");
    expect(content).toContain("Id,Architect_Comments__c");
    expect(content).toContain("006x");
    expect(content).toContain("Test comment");
  });
});
