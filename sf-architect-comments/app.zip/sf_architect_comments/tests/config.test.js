/**
 * Unit tests for config loading (env and optional config file).
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { writeFile, rm } from "fs/promises";
import { mkdtemp } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { loadConfig } from "../src/config.js";
import { DEFAULT_ORG_ID, DEFAULT_MAX_COMMENT_LENGTH } from "../src/config.js";

describe("loadConfig", () => {
  test("returns env-based config when no config path", async () => {
    const config = await loadConfig();
    expect(config).toBeDefined();
    expect(config.orgId).toBe(DEFAULT_ORG_ID);
    expect(config.maxCommentLength).toBe(DEFAULT_MAX_COMMENT_LENGTH);
    expect(config.outputFullPath).toBe("architect_comments_full.json");
    expect(config.fetchRelatedData).toBe(true);
    expect(config.caseOpportunityField).toBe("");
  });

  test("merges file config when path provided", async () => {
    const dir = await mkdtemp(join(tmpdir(), "architect-config-"));
    const configPath = join(dir, "config.json");
    await writeFile(
      configPath,
      JSON.stringify({
        guidelinesUrl: "https://docs.google.com/document/d/abc123/edit",
        outputPath: "out.csv",
        outputFullPath: "full.json",
        targetOrg: "my-org",
        fetchRelatedData: false,
        caseOpportunityField: "Related_Opportunity__c",
      }),
      "utf-8"
    );
    const config = await loadConfig(configPath);
    expect(config.guidelinesUrl).toBe("https://docs.google.com/document/d/abc123/edit");
    expect(config.outputPath).toBe("out.csv");
    expect(config.outputFullPath).toBe("full.json");
    expect(config.targetOrg).toBe("my-org");
    expect(config.fetchRelatedData).toBe(false);
    expect(config.caseOpportunityField).toBe("Related_Opportunity__c");
    await rm(dir, { recursive: true, force: true });
  });

  test("throws when config file path is invalid JSON", async () => {
    const dir = await mkdtemp(join(tmpdir(), "architect-config-"));
    const configPath = join(dir, "bad.json");
    await writeFile(configPath, "not json", "utf-8");
    await expect(loadConfig(configPath)).rejects.toThrow();
    await rm(dir, { recursive: true, force: true });
  });
});
