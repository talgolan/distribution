/**
 * Unit tests for generateArchitectComment, generateFullArchitectComment, generateSummaryArchitectComment, generateArchitectComments (pure; no I/O).
 */

import { describe, test, expect } from "bun:test";
import {
  generateArchitectComment,
  generateFullArchitectComment,
  generateSummaryArchitectComment,
  generateArchitectComments,
} from "../src/generator.js";

const MAX_LEN = 240;

describe("generateArchitectComment", () => {
  test("output is ≤ maxLength (240)", () => {
    const opp = {
      Id: "006x",
      SE_Comments__c: "A".repeat(500),
      StageName: "04 - Confirming Value With Power",
      IqScore: 75,
    };
    const guidelines = "First line of guidelines.\nSecond line.";
    const out = generateArchitectComment(opp, guidelines, { maxLength: MAX_LEN });
    expect(out.length).toBeLessThanOrEqual(MAX_LEN);
  });

  test("incorporates SE_Comments__c (truncated when long)", () => {
    const opp = {
      Id: "006x",
      SE_Comments__c: "Short SE note",
      StageName: "03 - Validating Benefits & Value",
      IqScore: 50,
    };
    const out = generateArchitectComment(opp, "Guidelines here.", { maxLength: MAX_LEN });
    expect(out).toContain("Short SE note");
  });

  test("incorporates stage", () => {
    const opp = {
      Id: "006x",
      StageName: "05 - Negotiating $$ & Mutual Plan",
      IqScore: 30,
    };
    const out = generateArchitectComment(opp, "", { maxLength: MAX_LEN });
    expect(out).toContain("Stage:");
    expect(out).toContain("05");
  });

  test("incorporates score tier (High/Medium/Low)", () => {
    const high = generateArchitectComment({ Id: "1", IqScore: 80 }, "", { maxLength: MAX_LEN });
    const med = generateArchitectComment({ Id: "2", IqScore: 55 }, "", { maxLength: MAX_LEN });
    const low = generateArchitectComment({ Id: "3", IqScore: 20 }, "", { maxLength: MAX_LEN });
    expect(high).toContain("Score: High");
    expect(med).toContain("Score: Medium");
    expect(low).toContain("Score: Low");
  });

  test("score N/A when IqScore is null or missing", () => {
    const out1 = generateArchitectComment({ Id: "1", IqScore: null }, "", { maxLength: MAX_LEN });
    const out2 = generateArchitectComment({ Id: "2" }, "", { maxLength: MAX_LEN });
    expect(out1).toContain("Score: N/A");
    expect(out2).toContain("Score: N/A");
  });

  test("incorporates first line of guidelines", () => {
    const opp = { Id: "006x", StageName: "04", IqScore: 60 };
    const guidelines = "Key Architect guidance: focus on value.\nMore text.";
    const out = generateArchitectComment(opp, guidelines, { maxLength: MAX_LEN });
    expect(out).toContain("Key Architect");
  });

  test("empty SE_Comments__c and empty guidelines still produce stage and score", () => {
    const opp = { Id: "006x", StageName: "04", IqScore: 70 };
    const out = generateArchitectComment(opp, "", { maxLength: MAX_LEN });
    expect(out.length).toBeLessThanOrEqual(MAX_LEN);
    expect(out).toContain("Stage:");
    expect(out).toContain("Score: High");
  });

  test("respects custom maxLength", () => {
    const opp = { Id: "006x", SE_Comments__c: "Hello", StageName: "04", IqScore: 50 };
    const out = generateArchitectComment(opp, "Guidelines", { maxLength: 20 });
    expect(out.length).toBeLessThanOrEqual(20);
  });

  test("special characters in SE_Comments__c are collapsed to single space", () => {
    const opp = {
      Id: "006x",
      SE_Comments__c: "Line1\n\nLine2   spaces",
      StageName: "04",
      IqScore: 50,
    };
    const out = generateArchitectComment(opp, "", { maxLength: MAX_LEN });
    expect(out).not.toContain("\n\n");
  });
});

function wordCount(s) {
  return (s || "").trim().split(/\s+/).filter(Boolean).length;
}

describe("generateFullArchitectComment", () => {
  test("output contains all six section headers", () => {
    const opp = {
      Id: "006x",
      Name: "Test Opp",
      StageName: "04 - Confirming Value With Power",
      SE_Comments__c: "SE note",
      IqScore: 70,
      lineItems: [],
      contactRoles: [],
      tasks: [],
      cases: [],
      relatedOpportunities: [],
    };
    const out = generateFullArchitectComment(opp, "Guidelines first line.", {});
    expect(out).toContain("**Customer Context**");
    expect(out).toContain("**Opportunity Summary**");
    expect(out).toContain("**Architectural Assessment**");
    expect(out).toContain("**Competitive Landscape**");
    expect(out).toContain("**Recommended Approach**");
    expect(out).toContain("**Open Questions / Risks**");
  });

  test("output length is substantial and bounded (structured sections)", () => {
    const opp = {
      Id: "006x",
      Name: "Test Opp",
      "Account.Name": "Acme",
      StageName: "04",
      SE_Comments__c: "SE note",
      IqScore: 70,
      lineItems: [{ "Product2.Name": "Product A", "Product2.Family": "Family X" }],
      contactRoles: [{ "Contact.Name": "Jane", Role: "Architect" }],
      tasks: [{ Subject: "Call" }],
      cases: [],
      relatedOpportunities: [],
    };
    const out = generateFullArchitectComment(opp, "Guidelines.", {});
    const w = wordCount(out);
    expect(w).toBeGreaterThanOrEqual(50);
    expect(w).toBeLessThanOrEqual(500);
  });
});

describe("generateSummaryArchitectComment", () => {
  test("summary is ≤ 240 characters when distilled from full", () => {
    const full = "A".repeat(400);
    const out = generateSummaryArchitectComment(full, undefined, undefined, { maxLength: 240 });
    expect(out.length).toBeLessThanOrEqual(240);
    expect(out.endsWith("…") || out.length < 240).toBe(true);
  });

  test("summary contains key info when built from opportunity", () => {
    const opp = {
      Id: "006x",
      Name: "Key Opp",
      StageName: "04",
      SE_Comments__c: "Important note",
      IqScore: 75,
      lineItems: [],
      contactRoles: [],
      tasks: [],
      cases: [],
      relatedOpportunities: [],
    };
    const out = generateSummaryArchitectComment(undefined, opp, "Guidelines", { maxLength: 240 });
    expect(out.length).toBeLessThanOrEqual(240);
    expect(out).toContain("Score:");
  });
});

describe("generateArchitectComments", () => {
  test("returns both full and summary; summary ≤ 240 chars", () => {
    const opp = {
      Id: "006x",
      Name: "Test",
      StageName: "04",
      SE_Comments__c: "SE",
      IqScore: 60,
      lineItems: [],
      contactRoles: [],
      tasks: [],
      cases: [],
      relatedOpportunities: [],
    };
    const { full, summary } = generateArchitectComments(opp, "Guidelines", { maxLength: 240 });
    expect(full).toContain("**Customer Context**");
    expect(summary.length).toBeLessThanOrEqual(240);
  });
});
