/**
 * Unit tests for guidelines URL parsing and fetch (fetch mocked via global fetch override in integration).
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { writeFile, rm, mkdtemp } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { extractDocId, fetchGuidelines } from "../src/guidelines.js";

describe("extractDocId", () => {
  test("extracts ID from full Google Doc URL", () => {
    const url = "https://docs.google.com/document/d/1abc123XYZ/edit";
    expect(extractDocId(url)).toBe("1abc123XYZ");
  });

  test("returns plain ID when passed only ID", () => {
    expect(extractDocId("1abc123XYZ")).toBe("1abc123XYZ");
  });

  test("returns null for empty string", () => {
    expect(extractDocId("")).toBe(null);
    expect(extractDocId("   ")).toBe(null);
  });

  test("handles URL with query params", () => {
    const url = "https://docs.google.com/document/d/abc_def-123/view?usp=sharing";
    expect(extractDocId(url)).toBe("abc_def-123");
  });
});

describe("fetchGuidelines from file", () => {
  let tempDir;
  let filePath;

  beforeAll(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "guidelines-"));
    filePath = join(tempDir, "guidelines.txt");
    await writeFile(filePath, "Line one\nLine two", "utf-8");
  });

  afterAll(async () => {
    if (tempDir) await rm(tempDir, { recursive: true, force: true });
  });

  test("returns file content when filePath provided", async () => {
    const text = await fetchGuidelines({ filePath });
    expect(text).toContain("Line one");
    expect(text).toContain("Line two");
  });

  test("throws when filePath does not exist and no url", async () => {
    await expect(fetchGuidelines({ filePath: "/nonexistent/path.txt" })).rejects.toThrow();
  });
});
