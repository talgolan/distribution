/**
 * Unit tests for LLM module: buildPromptForOpportunity, parseLlmCommentResponse, generateArchitectCommentsWithLLM (with mocked fetch).
 */

import { describe, test, expect, mock } from "bun:test";
import {
  buildPromptForOpportunity,
  parseLlmCommentResponse,
  generateArchitectCommentsWithLLM,
  callGateway,
} from "../src/llm.js";

const fixtureOpp = {
  Id: "006FIX",
  Name: "Test Opp",
  "Account.Name": "Acme Corp",
  StageName: "04 - Confirming Value With Power",
  SE_Comments__c: "Customer wants POC in sandbox for routing validation.",
  IqScore: 70,
  Probability: 25,
  lineItems: [{ "Product2.Name": "Product A", "Product2.Family": "Family X" }],
  contactRoles: [{ "Contact.Name": "Jane Doe", Role: "Solution Architect" }],
  tasks: [{ Subject: "Discovery call" }],
  cases: [],
  relatedOpportunities: [],
};

/** Build a valid structured LLM response, with optional field overrides. */
const makeStructuredContent = (overrides = {}) =>
  JSON.stringify({
    customerContext: "Acme Corp is a leading tech company seeking to modernize their CRM platform.",
    opportunitySummary: "Deal for Sales Cloud Enterprise at Stage 04, $2M, closing Q2.",
    architecturalAssessment: "Complex integration with legacy ERP required; data migration scope unclear.",
    competitiveLandscape: "No competitor data available; flagged as open item for discovery.",
    recommendedApproach: "Run integration POC before full proposal to de-risk ERP connectivity.",
    openQuestionsRisks: "Data migration scope and internal technical capacity are unconfirmed.",
    technicalFitAssessment: {
      opinion: "⚠️ CONDITIONAL FIT",
      summary: "Viable with POC. Integration risk is the key gating item before committing to a full proposal.",
      dimensions: [
        { name: "Solution Alignment", assessment: "Strong product fit for stated needs.", confidence: "High" },
        { name: "Integration Complexity", assessment: "ERP integration needs scoping.", confidence: "Medium" },
        { name: "Customization Burden", assessment: "Moderate custom work expected.", confidence: "Medium" },
        { name: "Technical Risk Flags", assessment: "No POC completed yet.", confidence: "Medium" },
        { name: "Customer Technical Readiness", assessment: "Unknown internal capacity.", confidence: "Low" },
      ],
      keyUnknowns: "ERP integration scope and data migration volume.",
      nextSteps: ["Run integration POC.", "Scope data migration."],
    },
    summary: "Conditional fit; integration POC required before full proposal.",
    ...overrides,
  });

describe("buildPromptForOpportunity", () => {
  test("prompt contains key facts from opportunity", () => {
    const { systemPrompt, userPrompt } = buildPromptForOpportunity(fixtureOpp, "Guidelines here.");
    expect(systemPrompt).toContain("JSON");
    expect(systemPrompt).toContain("customerContext");
    expect(systemPrompt).toContain("summary");
    expect(userPrompt).toContain("Test Opp");
    expect(userPrompt).toContain("Acme Corp");
    expect(userPrompt).toContain("04 - Confirming Value With Power");
    expect(userPrompt).toContain("POC");
    expect(userPrompt).toContain("routing validation");
    expect(userPrompt).toContain("Product A");
    expect(userPrompt).toContain("Solution Architect");
    expect(userPrompt).toContain("Guidelines here");
  });

  test("prompt includes guidelines snippet", () => {
    const { userPrompt } = buildPromptForOpportunity(fixtureOpp, "Architect guidelines first line.");
    expect(userPrompt).toContain("Architect guidelines first line");
  });
});

describe("parseLlmCommentResponse", () => {
  test("valid structured JSON returns sections and summary", () => {
    const out = parseLlmCommentResponse(makeStructuredContent(), { maxLength: 240 });
    expect(out.sections.customerContext).toContain("Acme Corp");
    expect(out.sections.technicalFitAssessment.opinion).toBe("⚠️ CONDITIONAL FIT");
    expect(out.sections.technicalFitAssessment.dimensions).toHaveLength(5);
    expect(out.summary).toBe("Conditional fit; integration POC required before full proposal.");
    expect(out.summary.length).toBeLessThanOrEqual(240);
  });

  test("summary over 240 chars is truncated at word boundary", () => {
    const longSummary = "A ".repeat(150);
    const out = parseLlmCommentResponse(makeStructuredContent({ summary: longSummary }), { maxLength: 240 });
    expect(out.summary.length).toBeLessThanOrEqual(240);
    expect(out.summary.endsWith("…")).toBe(true);
  });

  test("strips markdown code block wrapper", () => {
    const content = "```json\n" + makeStructuredContent() + "\n```";
    const out = parseLlmCommentResponse(content);
    expect(out.sections.customerContext).toContain("Acme Corp");
    expect(out.summary).toBe("Conditional fit; integration POC required before full proposal.");
  });

  test("throws on invalid JSON", () => {
    expect(() => parseLlmCommentResponse("not json")).toThrow("not valid JSON");
  });

  test("throws when customerContext is missing", () => {
    const parsed = JSON.parse(makeStructuredContent());
    delete parsed.customerContext;
    expect(() => parseLlmCommentResponse(JSON.stringify(parsed))).toThrow("missing 'customerContext'");
  });

  test("throws when summary is missing", () => {
    const parsed = JSON.parse(makeStructuredContent());
    delete parsed.summary;
    expect(() => parseLlmCommentResponse(JSON.stringify(parsed))).toThrow("missing 'summary'");
  });

  test("throws when technicalFitAssessment.opinion is missing", () => {
    const parsed = JSON.parse(makeStructuredContent());
    delete parsed.technicalFitAssessment.opinion;
    expect(() => parseLlmCommentResponse(JSON.stringify(parsed))).toThrow("technicalFitAssessment.opinion");
  });
});

describe("callGateway", () => {
  test("throws when API key is empty", async () => {
    await expect(
      callGateway([{ role: "user", content: "Hi" }], { apiKey: "", baseUrl: "https://gateway.example.com", model: "gpt-4o" })
    ).rejects.toThrow("ENG_AI_MODEL_GW_KEY is required");
  });
});

describe("generateArchitectCommentsWithLLM", () => {
  test("returns structured sections when fetch is mocked (gateway)", async () => {
    const fakeContent = makeStructuredContent();
    const originalFetch = globalThis.fetch;
    globalThis.fetch = mock((url) => {
      if (url.includes("/chat/completions")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              model: "claude-sonnet-4-20250514",
              choices: [{ message: { content: fakeContent } }],
              usage: { prompt_tokens: 100, completion_tokens: 50 },
            }),
        });
      }
      return originalFetch(url);
    });

    try {
      const result = await generateArchitectCommentsWithLLM(fixtureOpp, "Guidelines", {
        engAiModelGwKey: "fake-key",
        engAiModelGwUrl: "https://eng-ai-model-gateway.example.com",
        llmModel: "claude-sonnet-4-20250514",
        maxLength: 240,
        llmCache: false,
      });
      expect(result.sections.customerContext).toContain("Acme Corp");
      expect(result.sections.technicalFitAssessment.opinion).toBe("⚠️ CONDITIONAL FIT");
      expect(result.full).toContain("**Customer Context**");
      expect(result.summary).toBe("Conditional fit; integration POC required before full proposal.");
      expect(result.usage).toEqual({ model: "claude-sonnet-4-20250514", inputTokens: 100, outputTokens: 50 });
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  test("throws when gateway key is missing", async () => {
    await expect(
      generateArchitectCommentsWithLLM(fixtureOpp, "Guidelines", {
        engAiModelGwKey: "",
        engAiModelGwUrl: "https://gateway.example.com",
        llmModel: "gpt-4o",
        llmCache: false,
      })
    ).rejects.toThrow("ENG_AI_MODEL_GW_KEY is required");
  });
});
