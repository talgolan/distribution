/**
 * Unit tests for Salesforce CLI module.
 * runSf and fetchOpportunities are used in integration flow; full CLI test requires sf to be installed.
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { runSf, loadOpportunitiesFromFile, writeOpportunitiesToFile, fetchOpportunitiesWithRelated } from "../src/sf.js";
import { OPPORTUNITIES_SOQL } from "../src/soql.js";
import { mkdtemp, writeFile, rm } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";

describe("runSf", () => {
  test("runSf exists and is a function", () => {
    expect(typeof runSf).toBe("function");
  });
});

describe("loadOpportunitiesFromFile", () => {
  let tempDir;

  beforeAll(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "sf-test-"));
  });

  afterAll(async () => {
    if (tempDir) await rm(tempDir, { recursive: true, force: true });
  });

  test("loads valid JSON array of opportunities", async () => {
    const path = join(tempDir, "opps.json");
    const data = [
      { Id: "006x", Name: "Test", StageName: "04", SE_Comments__c: "Note", IqScore: 70 },
    ];
    await writeFile(path, JSON.stringify(data), "utf-8");
    const loaded = await loadOpportunitiesFromFile(path);
    expect(Array.isArray(loaded)).toBe(true);
    expect(loaded.length).toBe(1);
    expect(loaded[0].Id).toBe("006x");
    expect(loaded[0].StageName).toBe("04");
    expect(loaded[0].IqScore).toBe(70);
  });

  test("throws when file does not exist", async () => {
    await expect(loadOpportunitiesFromFile(join(tempDir, "nonexistent.json"))).rejects.toThrow("not found");
  });

  test("throws when file is invalid JSON", async () => {
    const path = join(tempDir, "bad.json");
    await writeFile(path, "not json", "utf-8");
    await expect(loadOpportunitiesFromFile(path)).rejects.toThrow("Invalid JSON");
  });

  test("throws when file is not a JSON array", async () => {
    const path = join(tempDir, "obj.json");
    await writeFile(path, '{"a":1}', "utf-8");
    await expect(loadOpportunitiesFromFile(path)).rejects.toThrow("JSON array");
  });
});

describe("writeOpportunitiesToFile", () => {
  let tempDir;

  beforeAll(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "sf-write-"));
  });

  afterAll(async () => {
    if (tempDir) await rm(tempDir, { recursive: true, force: true });
  });

  test("writes JSON that loadOpportunitiesFromFile can read", async () => {
    const path = join(tempDir, "out.json");
    const opportunities = [
      { Id: "006a", Name: "A", "Account.Name": "Acme", StageName: "04", IqScore: 65 },
    ];
    await writeOpportunitiesToFile(opportunities, path);
    const loaded = await loadOpportunitiesFromFile(path);
    expect(loaded.length).toBe(1);
    expect(loaded[0].Id).toBe("006a");
    expect(loaded[0]["Account.Name"]).toBe("Acme");
  });
});

describe("fetchOpportunitiesWithRelated", () => {
  test("groups related data by OpportunityId when runSfQuery is mocked", async () => {
    const coreRecords = [
      { Id: "006CORE", Name: "Core Opp", AccountId: "001A", Account: { Name: "Acme" }, StageName: "04", IqScore: 70 },
    ];
    const lineItemRecords = [
      { Id: "oli1", OpportunityId: "006CORE", Product2: { Name: "Product A", Family: "F1" }, Quantity: 1, UnitPrice: 100, TotalPrice: 100 },
    ];
    const contactRecords = [
      { Id: "ocr1", OpportunityId: "006CORE", Role: "Decision Maker", Contact: { Name: "Jane", Title: "VP" }, IsPrimary: true },
    ];
    let callCount = 0;
    const runSfQueryMock = async (soql) => {
      callCount++;
      if (soql === OPPORTUNITIES_SOQL) return coreRecords;
      if (soql.includes("OpportunityLineItem")) return lineItemRecords;
      if (soql.includes("OpportunityContactRole")) return contactRecords;
      if (soql.includes("Task")) return [];
      if (soql.includes("Case")) return [];
      if (soql.includes("AccountId IN")) return [];
      return [];
    };
    const result = await fetchOpportunitiesWithRelated({
      fetchRelatedData: true,
      caseOpportunityField: "",
      runSfQuery: runSfQueryMock,
    });
    expect(result.length).toBe(1);
    expect(result[0].Id).toBe("006CORE");
    expect(result[0].lineItems).toBeDefined();
    expect(result[0].lineItems.length).toBe(1);
    expect(result[0].lineItems[0]["Product2.Name"]).toBe("Product A");
    expect(result[0].contactRoles.length).toBe(1);
    expect(result[0].contactRoles[0]["Contact.Name"]).toBe("Jane");
    expect(result[0].tasks).toEqual([]);
    expect(result[0].cases).toEqual([]);
    expect(result[0].relatedOpportunities).toEqual([]);
  });
});
