/**
 * Integration-style test: full pipeline with fixture opportunities and guidelines file.
 * No live Salesforce or Google calls; uses guidelines file and in-memory opportunities.
 * Also tests --only-generate path: loadOpportunitiesFromFile + stub guidelines + generator + CSV.
 */

import { describe, test, expect, beforeAll, afterAll } from "bun:test";
import { mkdtemp, writeFile, rm } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { fetchGuidelines } from "../src/guidelines.js";
import { generateArchitectComment, generateArchitectComments } from "../src/generator.js";
import { buildCsv, writeFullCommentsJson } from "../src/csv.js";
import { loadOpportunitiesFromFile, writeOpportunitiesToFile } from "../src/sf.js";
import { STUB_GUIDELINES } from "../src/guidelines.js";

const fixtureOpportunities = [
  {
    Id: "006FIX001",
    Name: "Integration Test Opp",
    "Account.Name": "Acme Corp",
    StageName: "04 - Confirming Value With Power",
    SE_Comments__c: "SE feedback here",
    IqScore: 65,
  },
  {
    Id: "006FIX002",
    Name: "Second Opp",
    "Account.Name": "Beta Inc",
    StageName: "05 - Negotiating $$ & Mutual Plan",
    SE_Comments__c: "",
    IqScore: 80,
  },
];

const fixtureGuidelines = "Architect guidelines first line.\nSecond line of guidelines.";

describe("integration: full pipeline with fixtures", () => {
  let tempDir;
  let guidelinesPath;

  beforeAll(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "architect-comments-"));
    guidelinesPath = join(tempDir, "guidelines.txt");
    await writeFile(guidelinesPath, fixtureGuidelines, "utf-8");
  });

  afterAll(async () => {
    if (tempDir) await rm(tempDir, { recursive: true, force: true });
  });

  test("pipeline: opportunities + guidelines file -> CSV with correct row count and one full comment", async () => {
    const guidelinesText = await fetchGuidelines({ filePath: guidelinesPath });
    expect(guidelinesText).toContain("Architect guidelines");

    const opportunities = fixtureOpportunities;
    const rows = opportunities.map((opp) => {
      const comment = generateArchitectComment(opp, guidelinesText, { maxLength: 240 });
      return { Id: opp.Id, Architect_Comments__c: comment };
    });

    expect(rows.length).toBe(2);
    expect(rows[0].Architect_Comments__c.length).toBeLessThanOrEqual(240);
    expect(rows[0].Architect_Comments__c).toContain("SE feedback");
    expect(rows[0].Architect_Comments__c).toContain("Score:");

    const csv = buildCsv(rows);
    expect(csv).toContain("006FIX001");
    expect(csv).toContain("006FIX002");
    const lines = csv.split("\n");
    expect(lines.length).toBe(3);
  });

  test("--only-generate path: opportunities file + stub guidelines -> CSV", async () => {
    const opportunitiesPath = join(tempDir, "opportunities.json");
    await writeOpportunitiesToFile(fixtureOpportunities, opportunitiesPath);
    const opportunities = await loadOpportunitiesFromFile(opportunitiesPath);
    const guidelinesText = STUB_GUIDELINES;
    const rows = opportunities.map((opp) => {
      const comment = generateArchitectComment(opp, guidelinesText, { maxLength: 240 });
      return { Id: opp.Id, Architect_Comments__c: comment };
    });
    expect(rows.length).toBe(2);
    expect(rows[0].Architect_Comments__c.length).toBeLessThanOrEqual(240);
    expect(rows[0].Architect_Comments__c).toContain("Score:");
    expect(rows[0].Architect_Comments__c).toContain("Stub guidelines");
    const csv = buildCsv(rows);
    expect(csv).toContain("006FIX001");
    expect(csv).toContain("006FIX002");
  });

  test("OpportunityWithRelated + generateArchitectComments produces both full and summary", async () => {
    const withRelated = fixtureOpportunities.map((opp) => ({
      ...opp,
      lineItems: [],
      contactRoles: [],
      tasks: [],
      cases: [],
      relatedOpportunities: [],
    }));
    const guidelinesText = await fetchGuidelines({ filePath: guidelinesPath });
    const rows = [];
    const fullEntries = [];
    for (const opp of withRelated) {
      const { full, summary } = generateArchitectComments(opp, guidelinesText, { maxLength: 240 });
      rows.push({ Id: opp.Id, Architect_Comments__c: summary });
      fullEntries.push({ Id: opp.Id, Name: opp.Name, FullComment: full });
    }
    expect(rows.length).toBe(2);
    expect(fullEntries.length).toBe(2);
    expect(rows[0].Architect_Comments__c.length).toBeLessThanOrEqual(240);
    expect(fullEntries[0].FullComment).toContain("**Customer Context**");
    expect(fullEntries[0].FullComment).toContain("**Open Questions / Risks**");
    const csv = buildCsv(rows);
    expect(csv).toContain("006FIX001");
    const fullPath = join(tempDir, "full_comments.json");
    await writeFullCommentsJson(fullPath, fullEntries, { verbose: false });
    const { readFile } = await import("fs/promises");
    const raw = await readFile(fullPath, "utf-8");
    const parsed = JSON.parse(raw);
    expect(parsed.length).toBe(2);
    expect(parsed[0].Id).toBe("006FIX001");
    expect(parsed[0].FullComment).toContain("**Customer Context**");
  });
});

describe("CLI: --use-llm validation", () => {
  test("when useLlm is true with no gateway key, validation fails", () => {
    const config = { useLlm: true, engAiModelGwKey: "" };
    const hasKey = (config.engAiModelGwKey ?? "").trim().length > 0;
    expect(hasKey).toBe(false);
  });

  test("when useLlm is true with gateway key set, validation passes", () => {
    const config = { useLlm: true, engAiModelGwKey: "fake-key" };
    const hasKey = (config.engAiModelGwKey ?? "").trim().length > 0;
    expect(hasKey).toBe(true);
  });
});
