# CURSOR.md

## Project Philosophy
- Prefer boring technology over clever solutions
- Every abstraction must justify its existence in a comment
- Before developing anything, find the three best reasons the architecture being proposing is wrong.
- Before developing anything, consider what a senior engineer, three years in the future, would say about this decision.