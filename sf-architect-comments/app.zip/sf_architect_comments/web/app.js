const oppsBody = document.querySelector("#oppsBody");
const dataFileInput = document.querySelector("#dataFileInput");
const browseButton = document.querySelector("#browseButton");
const reloadButton = document.querySelector("#reloadButton");
const settingsButton = document.querySelector("#settingsButton");
const mainContent = document.querySelector("#mainContent");
const settingsPage = document.querySelector("#settingsPage");
const settingsBackButton = document.querySelector("#settingsBackButton");
const settingsSaveButton = document.querySelector("#settingsSaveButton");
const settingsResetButton = document.querySelector("#settingsResetButton");
const settingGwKey = document.querySelector("#settingGwKey");
const settingGwUrl = document.querySelector("#settingGwUrl");
const settingModel = document.querySelector("#settingModel");
const settingGwKeyToggle = document.querySelector("#settingGwKeyToggle");
const settingGwKeyBadge = document.querySelector("#settingGwKeyBadge");
const settingGwUrlBadge = document.querySelector("#settingGwUrlBadge");
const settingModelBadge = document.querySelector("#settingModelBadge");
const settingCaCerts = document.querySelector("#settingCaCerts");
const settingCaCertsBadge = document.querySelector("#settingCaCertsBadge");
const settingCaCertsSystemNote = document.querySelector("#settingCaCertsSystemNote");
const settingTargetOrg = document.querySelector("#settingTargetOrg");
const settingTargetOrgBadge = document.querySelector("#settingTargetOrgBadge");
const settingTargetOrgSystemNote = document.querySelector("#settingTargetOrgSystemNote");
const settingGwKeySystemNote = document.querySelector("#settingGwKeySystemNote");
const settingGwUrlSystemNote = document.querySelector("#settingGwUrlSystemNote");
const settingModelSystemNote = document.querySelector("#settingModelSystemNote");
const tabBatchButton = document.querySelector("#tabBatchButton");
const tabSingleButton = document.querySelector("#tabSingleButton");
const tabBatch = document.querySelector("#tabBatch");
const tabSingle = document.querySelector("#tabSingle");
const singleOppIdInput = document.querySelector("#singleOppIdInput");
const singleGenerateButton = document.querySelector("#singleGenerateButton");
const singleStatus = document.querySelector("#singleStatus");
const selectAllButton = document.querySelector("#selectAllButton");
const clearSelectionButton = document.querySelector("#clearSelectionButton");
const processButton = document.querySelector("#processButton");
const clearCacheButton = document.querySelector("#clearCacheButton");
const selectionCount = document.querySelector("#selectionCount");
const statusText = document.querySelector("#statusText");
const processedList = document.querySelector("#processedList");
const oppsHead = document.querySelector("#oppsHead");
const renderedModeButton = document.querySelector("#renderedModeButton");
const rawModeButton = document.querySelector("#rawModeButton");
const viewerMeta = document.querySelector("#viewerMeta");
const markdownRendered = document.querySelector("#markdownRendered");
const markdownRaw = document.querySelector("#markdownRaw");
const pageSizeInput = document.querySelector("#pageSizeInput");
const prevPageButton = document.querySelector("#prevPageButton");
const nextPageButton = document.querySelector("#nextPageButton");
const pageIndicator = document.querySelector("#pageIndicator");
const processingModal = document.querySelector("#processingModal");
const modalCloseButton = document.querySelector("#modalCloseButton");
const modalSummary = document.querySelector("#modalSummary");
const modalProgressBar = document.querySelector("#modalProgressBar");
const modalCurrent = document.querySelector("#modalCurrent");
const modalLog = document.querySelector("#modalLog");

/** @type {Array<Record<string, unknown>>} */
let opportunities = [];
const selectedIds = new Set();
/** @type {Array<Record<string, unknown>>} */
let processResults = [];
let viewerMode = "rendered";
let activeMarkdownId = "";
let activeEventSource = null;
let currentPage = 1;
let pageSize = 50;
let sortKey = "closeDate";
let sortDirection = "desc";
const tableStateStorageKey = "opportunityTableState";
const allowedSortKeys = new Set(["id", "name", "account", "stage", "amount", "closeDate", "owner", "manager", "result"]);

const loadTableState = () => {
  try {
    const raw = localStorage.getItem(tableStateStorageKey);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (allowedSortKeys.has(String(parsed?.sortKey || ""))) {
      sortKey = String(parsed.sortKey);
    }
    if (parsed?.sortDirection === "asc" || parsed?.sortDirection === "desc") {
      sortDirection = parsed.sortDirection;
    }
    const parsedPageSize = Number(parsed?.pageSize);
    if (Number.isFinite(parsedPageSize) && parsedPageSize > 0) {
      pageSize = Math.floor(parsedPageSize);
    }
    const parsedCurrentPage = Number(parsed?.currentPage);
    if (Number.isFinite(parsedCurrentPage) && parsedCurrentPage > 0) {
      currentPage = Math.floor(parsedCurrentPage);
    }
  } catch {
    // Ignore malformed localStorage data and use defaults.
  }
};

const saveTableState = () => {
  try {
    const payload = {
      sortKey,
      sortDirection,
      pageSize,
      currentPage,
    };
    localStorage.setItem(tableStateStorageKey, JSON.stringify(payload));
  } catch {
    // Ignore storage failures (e.g. private mode restrictions).
  }
};

const mergeResultsById = (existing, incoming) => {
  const byId = new Map((existing || []).map((item) => [String(item?.id || ""), item]));
  for (const item of incoming || []) {
    const id = String(item?.id || "");
    if (!id) continue;
    byId.set(id, item);
  }
  return [...byId.values()];
};

const pruneResultsToCurrentSource = (results, sourceOpportunities) => {
  const allowedIds = new Set((sourceOpportunities || []).map((opp) => String(opp?.Id || "")));
  return (results || []).filter((item) => allowedIds.has(String(item?.id || "")));
};

const formatAmount = (value) => {
  const number = Number(value || 0);
  if (!Number.isFinite(number)) return "0";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(number);
};

const setStatus = (message, { error = false } = {}) => {
  statusText.textContent = message;
  statusText.classList.toggle("status--error", error);
};

const checkConnectivity = async () => {
  setStatus("Checking connectivity...");
  try {
    const res = await fetch("/api/preflight");
    const data = await res.json();
    const errors = [];
    if (!data.sf?.ok) {
      errors.push(`Salesforce: ${data.sf?.error ?? "not authenticated"}`);
    }
    if (!data.gateway?.ok) {
      errors.push(`Gateway: ${data.gateway?.error ?? "unreachable"}`);
    }
    if (errors.length > 0) {
      setStatus(errors.join(" · "), { error: true });
    } else {
      const org = data.sf?.username ?? data.sf?.org ?? "connected";
      setStatus(`Ready — Salesforce: ${org} · Gateway: OK`);
    }
  } catch (err) {
    setStatus(`Connectivity check failed: ${err.message}`, { error: true });
  }
};

// --- Settings page ---

const SETTINGS_STORAGE_KEY = "userSettings";

const loadStoredSettings = () => {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const persistStoredSettings = (settings) => {
  try { localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings)); } catch { /* ignore */ }
};

const clearStoredSettings = () => {
  try { localStorage.removeItem(SETTINGS_STORAGE_KEY); } catch { /* ignore */ }
};

/** Sends whatever is stored in localStorage to the server so process.env stays in sync. */
const syncSettingsToServer = async () => {
  const stored = loadStoredSettings();
  if (!stored) return;
  const body = {};
  if (stored.engAiModelGwKey) body.engAiModelGwKey = stored.engAiModelGwKey;
  if (stored.engAiModelGwUrl) body.engAiModelGwUrl = stored.engAiModelGwUrl;
  if (stored.engAiModel) body.engAiModel = stored.engAiModel;
  if (!Object.keys(body).length) return;
  try {
    await fetch("/api/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch { /* connectivity check will surface any issues */ }
};

/** Cached system values from the most recent /api/settings call. */
let systemSettings = null;

/**
 * Show/hide override badges and system-value notes for each field.
 * @param {{ engAiModelGwKeySet: boolean, engAiModelGwUrl: string, engAiModel: string }} system
 * @param {{ engAiModelGwKey?: string, engAiModelGwUrl?: string, engAiModel?: string }|null} stored
 */
const updateOverrideBadges = (system, stored) => {
  const keyOverridden = !!(stored?.engAiModelGwKey);
  settingGwKeyBadge.classList.toggle("hidden", !keyOverridden);
  settingGwKeySystemNote.classList.toggle("hidden", !keyOverridden);
  if (keyOverridden) {
    settingGwKeySystemNote.textContent = system?.engAiModelGwKeySet
      ? "System: set via ENG_AI_MODEL_GW_KEY"
      : "System: not set";
  }

  const urlOverridden = !!(stored?.engAiModelGwUrl && stored.engAiModelGwUrl !== system?.engAiModelGwUrl);
  settingGwUrlBadge.classList.toggle("hidden", !urlOverridden);
  settingGwUrlSystemNote.classList.toggle("hidden", !urlOverridden);
  if (urlOverridden) {
    settingGwUrlSystemNote.textContent = `System: ${system?.engAiModelGwUrl ?? "(not set)"}`;
  }

  const modelOverridden = !!(stored?.engAiModel && stored.engAiModel !== system?.engAiModel);
  settingModelBadge.classList.toggle("hidden", !modelOverridden);
  settingModelSystemNote.classList.toggle("hidden", !modelOverridden);
  if (modelOverridden) {
    settingModelSystemNote.textContent = `System: ${system?.engAiModel ?? "(not set)"}`;
  }

  const caCertsOverridden = !!(stored?.nodeExtraCaCerts && stored.nodeExtraCaCerts !== system?.nodeExtraCaCerts);
  settingCaCertsBadge.classList.toggle("hidden", !caCertsOverridden);
  settingCaCertsSystemNote.classList.toggle("hidden", !caCertsOverridden);
  if (caCertsOverridden) {
    settingCaCertsSystemNote.textContent = `System: ${system?.nodeExtraCaCerts || "(not set)"}`;
  }

  const targetOrgOverridden = !!(stored?.sfTargetOrg && stored.sfTargetOrg !== system?.sfTargetOrg);
  settingTargetOrgBadge.classList.toggle("hidden", !targetOrgOverridden);
  settingTargetOrgSystemNote.classList.toggle("hidden", !targetOrgOverridden);
  if (targetOrgOverridden) {
    settingTargetOrgSystemNote.textContent = `System: ${system?.sfTargetOrg || "(not set)"}`;
  }
};

const openSettingsPage = async () => {
  mainContent.classList.add("hidden");
  settingsPage.classList.remove("hidden");
  try {
    const res = await fetch("/api/settings");
    const data = await res.json();
    systemSettings = data.system;
    const stored = loadStoredSettings() || {};

    // Reset the toggle so the field always opens masked.
    settingGwKey.type = "password";
    settingGwKeyToggle.textContent = "Show";

    if (stored.engAiModelGwKey) {
      // Populate with the actual stored value so the user can see/edit it.
      settingGwKey.value = stored.engAiModelGwKey;
      settingGwKey.placeholder = "";
    } else if (data.system?.engAiModelGwKeySet) {
      // Key is in the system environment — we don't have the value to show.
      settingGwKey.value = "";
      settingGwKey.placeholder = "\u2022\u2022\u2022\u2022 (system env \u2014 leave blank to use)";
    } else {
      settingGwKey.value = "";
      settingGwKey.placeholder = "Enter API key\u2026";
    }

    settingGwUrl.value = stored.engAiModelGwUrl ?? data.active?.engAiModelGwUrl ?? "";
    settingModel.value = stored.engAiModel ?? data.active?.engAiModel ?? "";
    settingCaCerts.value = stored.nodeExtraCaCerts ?? data.active?.nodeExtraCaCerts ?? "";
    settingTargetOrg.value = stored.sfTargetOrg ?? data.active?.sfTargetOrg ?? "";

    updateOverrideBadges(data.system, stored);
  } catch (err) {
    setStatus(`Could not load settings: ${err.message}`, { error: true });
  }
};

const closeSettingsPage = () => {
  settingsPage.classList.add("hidden");
  mainContent.classList.remove("hidden");
};

const saveSettingsPage = async () => {
  const stored = loadStoredSettings() || {};

  const key = settingGwKey.value.trim();
  if (key) stored.engAiModelGwKey = key;

  const url = settingGwUrl.value.trim();
  if (url) {
    stored.engAiModelGwUrl = url;
  } else {
    delete stored.engAiModelGwUrl;
  }

  const model = settingModel.value.trim();
  if (model) {
    stored.engAiModel = model;
  } else {
    delete stored.engAiModel;
  }

  const caCerts = settingCaCerts.value.trim();
  if (caCerts) {
    stored.nodeExtraCaCerts = caCerts;
  } else {
    delete stored.nodeExtraCaCerts;
  }

  const targetOrg = settingTargetOrg.value.trim();
  if (targetOrg) {
    stored.sfTargetOrg = targetOrg;
  } else {
    delete stored.sfTargetOrg;
  }

  persistStoredSettings(stored);

  const body = {};
  if (stored.engAiModelGwKey) body.engAiModelGwKey = stored.engAiModelGwKey;
  body.engAiModelGwUrl = stored.engAiModelGwUrl ?? "";
  body.engAiModel = stored.engAiModel ?? "";
  body.nodeExtraCaCerts = stored.nodeExtraCaCerts ?? "";
  body.sfTargetOrg = stored.sfTargetOrg ?? "";

  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? `HTTP ${res.status}`);
    }
    updateOverrideBadges(systemSettings, stored);
    closeSettingsPage();
    await checkConnectivity();
  } catch (err) {
    setStatus(`Failed to save settings: ${err.message}`, { error: true });
  }
};

const resetToSystemDefaults = async () => {
  clearStoredSettings();
  try {
    const res = await fetch("/api/settings/reset", { method: "POST" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? `HTTP ${res.status}`);
    }
    await openSettingsPage();
    await checkConnectivity();
  } catch (err) {
    setStatus(`Failed to reset settings: ${err.message}`, { error: true });
  }
};

// --- Tab switching ---

const switchTab = (tab) => {
  const isBatch = tab === "batch";
  tabBatchButton.classList.toggle("active", isBatch);
  tabSingleButton.classList.toggle("active", !isBatch);
  tabBatch.classList.toggle("hidden", !isBatch);
  tabSingle.classList.toggle("hidden", isBatch);
};

// --- Generate by ID ---

const setSingleStatus = (message, { error = false } = {}) => {
  singleStatus.textContent = message;
  singleStatus.classList.toggle("status--error", error);
};

const generateById = async () => {
  const opportunityId = singleOppIdInput.value.trim();
  if (!opportunityId) {
    setSingleStatus("Enter a Salesforce Opportunity ID.", { error: true });
    return;
  }

  singleGenerateButton.disabled = true;
  setSingleStatus(`Fetching ${opportunityId} from Salesforce…`);

  try {
    const response = await fetch("/api/process-by-sfid", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ opportunityId }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);

    const jobId = payload.jobId;
    if (!jobId) throw new Error("Missing jobId from response.");

    setSingleStatus("Fetched from Salesforce. Generating architect comments…");
    openModal();
    appendModalLog(`Generating for ${opportunityId}…`);

    activeEventSource?.close();
    activeEventSource = new EventSource(`/api/process/${encodeURIComponent(jobId)}/stream`);

    activeEventSource.addEventListener("job-start", (event) => {
      const data = JSON.parse(event.data);
      setModalProgress(data.completed ?? 0, data.total ?? 1);
    });

    activeEventSource.addEventListener("opportunity-start", (event) => {
      const data = JSON.parse(event.data);
      modalCurrent.textContent = `Current: ${data.id}`;
      setModalProgress(data.completed ?? 0, data.total ?? 1);
    });

    activeEventSource.addEventListener("opportunity-log", (event) => {
      const data = JSON.parse(event.data);
      appendModalLog(`[${data.id}] ${data.stream}: ${data.line}`);
    });

    activeEventSource.addEventListener("opportunity-complete", (event) => {
      const data = JSON.parse(event.data);
      setModalProgress(data.completed ?? 0, data.total ?? 1);
      appendModalLog(`${data.id}: ${data.ok ? "ok" : "failed"} in ${data.durationMs}ms`);
    });

    activeEventSource.addEventListener("job-complete", async (event) => {
      const data = JSON.parse(event.data);
      const success = (data.successCount ?? 0) > 0;
      setSingleStatus(
        success
          ? `Done — generated for ${opportunityId}.`
          : `Generation failed for ${opportunityId}. Check the log above.`,
        { error: !success },
      );
      appendModalLog(`Job complete. Success: ${data.successCount}, Failed: ${data.failureCount}.`);
      modalCurrent.textContent = "Current: complete";
      setModalProgress(data.requested ?? 1, data.requested ?? 1);
      modalCloseButton.disabled = false;
      activeEventSource?.close();
      activeEventSource = null;
      if (success) await loadMarkdownForId(opportunityId);
    });

    activeEventSource.addEventListener("stream-end", () => {
      activeEventSource?.close();
      activeEventSource = null;
    });

    activeEventSource.onerror = () => {
      appendModalLog("Live stream disconnected.");
      modalCloseButton.disabled = false;
      activeEventSource?.close();
      activeEventSource = null;
    };
  } catch (error) {
    setSingleStatus(`Failed: ${error.message}`, { error: true });
    appendModalLog(`Error: ${error.message}`);
    modalCloseButton.disabled = false;
  } finally {
    singleGenerateButton.disabled = false;
  }
};

// --- File picker ---

const LAST_DATA_FILE_KEY = "lastDataFilePath";

const loadLastDataFile = () => {
  try { return localStorage.getItem(LAST_DATA_FILE_KEY) ?? ""; } catch { return ""; }
};

const persistDataFile = (path) => {
  try { localStorage.setItem(LAST_DATA_FILE_KEY, path); } catch { /* ignore */ }
};

const browseFile = async () => {
  try {
    const res = await fetch("/api/browse", { method: "POST" });
    if (res.status === 204) return; // user cancelled
    const data = await res.json();
    if (data.path) {
      dataFileInput.value = data.path;
      persistDataFile(data.path);
      await loadOpportunities();
    }
  } catch (err) {
    setStatus(`Browse failed: ${err.message}`, { error: true });
  }
};

const appendModalLog = (line) => {
  const row = document.createElement("div");
  row.textContent = line;
  modalLog.appendChild(row);
  modalLog.scrollTop = modalLog.scrollHeight;
};

const setModalProgress = (completed, total) => {
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
  modalProgressBar.style.width = `${pct}%`;
  modalSummary.textContent = `${completed}/${total} completed (${pct}%)`;
};

const openModal = () => {
  processingModal.classList.remove("hidden");
  processingModal.setAttribute("aria-hidden", "false");
  modalCloseButton.disabled = true;
  modalLog.innerHTML = "";
  modalCurrent.textContent = "Current: —";
  setModalProgress(0, 0);
};

const closeModal = () => {
  processingModal.classList.add("hidden");
  processingModal.setAttribute("aria-hidden", "true");
};

const updateSelectionCount = () => {
  selectionCount.textContent = `${selectedIds.size} selected`;
};

const successfulResultIds = () =>
  new Set(processResults.filter((item) => item?.ok).map((item) => String(item.id || "")));

const normalizeSortValue = (value) => {
  if (value == null) return "";
  return String(value).toLowerCase();
};

const sortOpportunities = (items) => {
  const successIds = successfulResultIds();
  const sorted = [...items];
  sorted.sort((a, b) => {
    const getSortValue = (opp) => {
      switch (sortKey) {
        case "id": return String(opp.Id || "");
        case "name": return String(opp.Name || "");
        case "account": return String(opp["Account.Name"] || "");
        case "stage": return String(opp.StageName || "");
        case "amount": return Number(opp.Amount || 0);
        case "closeDate": return String(opp.CloseDate || "");
        case "owner": return String(opp["Owner.Name"] || "");
        case "manager": return String(opp["Owner_Manager_Name__c"] || "");
        case "result": return successIds.has(String(opp.Id || "")) ? 1 : 0;
        default: return String(opp.Id || "");
      }
    };
    const aVal = getSortValue(a);
    const bVal = getSortValue(b);
    let cmp = 0;
    if (typeof aVal === "number" && typeof bVal === "number") cmp = aVal - bVal;
    else cmp = normalizeSortValue(aVal).localeCompare(normalizeSortValue(bVal));
    return sortDirection === "asc" ? cmp : -cmp;
  });
  return sorted;
};

const updateSortHeaderUi = () => {
  const headers = document.querySelectorAll(".sort-header[data-sort-key]");
  for (const header of headers) {
    if (!(header instanceof HTMLButtonElement)) continue;
    const isActive = header.dataset.sortKey === sortKey;
    header.classList.toggle("active", isActive);
    header.dataset.sortDirection = isActive ? sortDirection : "";
  }
};

const updatePaginationUi = (totalItems) => {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (currentPage > totalPages) currentPage = totalPages;
  pageIndicator.textContent = `Page ${currentPage} / ${totalPages}`;
  prevPageButton.disabled = currentPage <= 1;
  nextPageButton.disabled = currentPage >= totalPages;
  pageSizeInput.value = String(pageSize);
  saveTableState();
};

const escapeHtml = (value) =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");

const renderInlineMarkdown = (text) =>
  escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>");

const renderMarkdown = (markdown) => {
  const lines = String(markdown || "").replace(/\r\n/g, "\n").split("\n");
  const htmlParts = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      i += 1;
      continue;
    }

    if (/^#{1,6}\s/.test(trimmed)) {
      const level = trimmed.match(/^#+/)[0].length;
      const content = trimmed.replace(/^#{1,6}\s+/, "");
      htmlParts.push(`<h${level}>${renderInlineMarkdown(content)}</h${level}>`);
      i += 1;
      continue;
    }

    if (trimmed === "---") {
      htmlParts.push("<hr>");
      i += 1;
      continue;
    }

    if (trimmed.startsWith("> ")) {
      htmlParts.push(`<blockquote>${renderInlineMarkdown(trimmed.slice(2))}</blockquote>`);
      i += 1;
      continue;
    }

    if (/^\d+\.\s+/.test(trimmed) || /^-\s+/.test(trimmed)) {
      const isOrdered = /^\d+\.\s+/.test(trimmed);
      const listTag = isOrdered ? "ol" : "ul";
      const listItems = [];
      while (i < lines.length) {
        const itemLine = lines[i].trim();
        if (isOrdered && /^\d+\.\s+/.test(itemLine)) {
          listItems.push(itemLine.replace(/^\d+\.\s+/, ""));
          i += 1;
          continue;
        }
        if (!isOrdered && /^-\s+/.test(itemLine)) {
          listItems.push(itemLine.replace(/^-\s+/, ""));
          i += 1;
          continue;
        }
        break;
      }
      htmlParts.push(
        `<${listTag}>${listItems.map((item) => `<li>${renderInlineMarkdown(item)}</li>`).join("")}</${listTag}>`,
      );
      continue;
    }

    if (trimmed.startsWith("|")) {
      const tableLines = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        tableLines.push(lines[i].trim());
        i += 1;
      }
      const rows = tableLines
        .map((tableLine) => tableLine.split("|").slice(1, -1).map((cell) => cell.trim()))
        .filter((cells) => cells.some(Boolean));
      if (rows.length >= 2) {
        const header = rows[0];
        const bodyRows = rows.slice(2);
        const thead = `<thead><tr>${header.map((cell) => `<th>${renderInlineMarkdown(cell)}</th>`).join("")}</tr></thead>`;
        const tbody = `<tbody>${bodyRows.map((row) => `<tr>${row.map((cell) => `<td>${renderInlineMarkdown(cell)}</td>`).join("")}</tr>`).join("")}</tbody>`;
        htmlParts.push(`<table>${thead}${tbody}</table>`);
      }
      continue;
    }

    htmlParts.push(`<p>${renderInlineMarkdown(trimmed)}</p>`);
    i += 1;
  }

  return htmlParts.join("\n");
};

const setViewerMode = (mode) => {
  viewerMode = mode;
  renderedModeButton.classList.toggle("active", mode === "rendered");
  rawModeButton.classList.toggle("active", mode === "raw");
  markdownRendered.classList.toggle("hidden", mode !== "rendered");
  markdownRaw.classList.toggle("hidden", mode !== "raw");
};

const renderProcessedList = () => {
  processedList.innerHTML = "";
  if (!processResults.length) {
    processedList.textContent = "No processing run yet.";
    return;
  }

  const opportunitiesById = new Map(
    opportunities.map((opp) => [String(opp?.Id || ""), opp]),
  );

  for (const item of processResults) {
    const meta = opportunitiesById.get(String(item.id || "")) || {};
    const oppName = String(meta.Name || "—");
    const oppId = String(item.id || meta.Id || "—");
    const accountName = String(meta["Account.Name"] || "—");
    const ownerName = String(meta["Owner.Name"] || "—");
    const managerName = String(meta["Owner_Manager_Name__c"] || "—");
    const amount = meta.Amount == null ? "—" : formatAmount(meta.Amount);
    const row = document.createElement("div");
    row.className = "processed-item";
    const state = item.ok ? "success" : "error";
    row.innerHTML = `
      <div class="processed-main">
        <div class="processed-meta-grid">
          <span class="processed-meta-label">Opportunity Name</span>
          <span>${oppName}</span>
          <span class="processed-meta-label">Opportunity ID</span>
          <span><code>${oppId}</code></span>
          <span class="processed-meta-label">Account</span>
          <span>${accountName}</span>
          <span class="processed-meta-label">Owner</span>
          <span>${ownerName}</span>
          <span class="processed-meta-label">Manager</span>
          <span>${managerName}</span>
          <span class="processed-meta-label">Amount</span>
          <span>${amount}</span>
        </div>
        <div class="processed-status-row">
          <span class="badge ${state}">${item.ok ? "ok" : "failed"}</span>
          <span class="muted">${item.durationMs} ms</span>
          <span class="badge ${item.cacheUsed ? "success" : "error"}">${item.cacheUsed ? "cached" : "not cached"}</span>
        </div>
      </div>
      <div class="processed-actions">
        <button type="button" data-view-id="${item.id}" ${item.ok ? "" : "disabled"}>View Markdown</button>
      </div>
    `;
    processedList.appendChild(row);
  }
};

const loadMarkdownForId = async (id) => {
  activeMarkdownId = id;
  viewerMeta.textContent = `Loading markdown for ${id}...`;
  try {
    const response = await fetch(`/api/markdown/${encodeURIComponent(id)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Failed to load markdown.");
    viewerMeta.textContent = `${payload.path}`;
    markdownRaw.textContent = payload.markdown;
    markdownRendered.innerHTML = renderMarkdown(payload.markdown);
    setViewerMode(viewerMode);
  } catch (error) {
    viewerMeta.textContent = `Failed to load markdown for ${id}: ${error.message}`;
    markdownRaw.textContent = "";
    markdownRendered.innerHTML = "";
  }
};

const renderTable = () => {
  oppsBody.innerHTML = "";
  const successIds = successfulResultIds();
  const sorted = sortOpportunities(opportunities);
  updatePaginationUi(sorted.length);
  const startIdx = (currentPage - 1) * pageSize;
  const paged = sorted.slice(startIdx, startIdx + pageSize);
  for (const opp of paged) {
    const id = String(opp.Id || "");
    const resultCell = successIds.has(id)
      ? `<button type="button" class="row-result-button" data-row-view-id="${id}">View Result</button>`
      : '<span class="muted">—</span>';
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><input type="checkbox" data-id="${id}" ${selectedIds.has(id) ? "checked" : ""}></td>
      <td>${id}</td>
      <td>${String(opp.Name || "")}</td>
      <td>${String(opp["Account.Name"] || "")}</td>
      <td>${String(opp.StageName || "")}</td>
      <td>${formatAmount(opp.Amount)}</td>
      <td>${String(opp.CloseDate || "")}</td>
      <td>${String(opp["Owner.Name"] || "")}</td>
      <td>${String(opp["Owner_Manager_Name__c"] || "")}</td>
      <td>${resultCell}</td>
    `;
    oppsBody.appendChild(tr);
  }
  updateSortHeaderUi();
  updateSelectionCount();
};

const loadPreexistingProcessedResults = async () => {
  const dataFile = dataFileInput.value.trim();
  const response = await fetch(`/api/processed?file=${encodeURIComponent(dataFile)}`);
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Failed to load previously processed opportunities.");

  const incoming = Array.isArray(payload.results) ? payload.results : [];
  processResults = mergeResultsById(processResults, incoming.filter((item) => !processResults.some((r) => String(r?.id || "") === String(item?.id || ""))));
  processResults = pruneResultsToCurrentSource(processResults, opportunities);
};

const loadOpportunities = async () => {
  const dataFile = dataFileInput.value.trim();
  if (!dataFile) {
    setStatus("No data file selected. Click Browse to choose a JSON file.");
    opportunities = [];
    processResults = [];
    renderTable();
    return;
  }
  setStatus(`Loading ${dataFile}...`);
  reloadButton.disabled = true;
  try {
    const response = await fetch(`/api/opportunities?file=${encodeURIComponent(dataFile)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Failed to load opportunities.");
    opportunities = payload.opportunities || [];
    processResults = pruneResultsToCurrentSource(processResults, opportunities);
    selectedIds.clear();
    await loadPreexistingProcessedResults();
    renderProcessedList();
    renderTable();
    setStatus(`Loaded ${payload.count} opportunities from ${payload.source}.`);
  } catch (error) {
    setStatus(`Load failed: ${error.message}`);
    opportunities = [];
    selectedIds.clear();
    processResults = [];
    renderProcessedList();
    renderTable();
  } finally {
    reloadButton.disabled = false;
  }
};

const processSelected = async () => {
  if (selectedIds.size === 0) {
    setStatus("Select at least one opportunity.");
    return;
  }

  const ids = [...selectedIds];
  processButton.disabled = true;
  setStatus(`Starting processing for ${ids.length} opportunities...`);

  try {
    openModal();
    appendModalLog(`Starting job for ${ids.length} opportunities.`);
    const response = await fetch("/api/process", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ids, dataFile: dataFileInput.value.trim() }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Processing failed.");
    const jobId = payload.jobId;
    if (!jobId) throw new Error("Missing jobId from process start response.");

    activeEventSource?.close();
    activeEventSource = new EventSource(`/api/process/${encodeURIComponent(jobId)}/stream`);

    activeEventSource.addEventListener("job-start", (event) => {
      const data = JSON.parse(event.data);
      setModalProgress(data.completed ?? 0, data.total ?? ids.length);
      appendModalLog(`Job started (${data.total} total).`);
      setStatus("Processing started...");
    });

    activeEventSource.addEventListener("opportunity-start", (event) => {
      const data = JSON.parse(event.data);
      modalCurrent.textContent = `Current: ${data.id} (${data.index}/${data.total})`;
      setModalProgress(data.completed ?? 0, data.total ?? ids.length);
      appendModalLog(`Processing ${data.id} (${data.index}/${data.total})...`);
    });

    activeEventSource.addEventListener("opportunity-log", (event) => {
      const data = JSON.parse(event.data);
      appendModalLog(`[${data.id}] ${data.stream}: ${data.line}`);
    });

    activeEventSource.addEventListener("opportunity-complete", (event) => {
      const data = JSON.parse(event.data);
      processResults = [...processResults.filter((r) => r.id !== data.id), data];
      processResults = pruneResultsToCurrentSource(processResults, opportunities);
      setModalProgress(data.completed ?? 0, data.total ?? ids.length);
      appendModalLog(
        `${data.id}: ${data.ok ? "ok" : "failed"} in ${data.durationMs}ms; cache: ${data.cacheUsed ? "yes" : "no"}`,
      );
      renderProcessedList();
      renderTable();
    });

    activeEventSource.addEventListener("job-complete", async (event) => {
      const data = JSON.parse(event.data);
      processResults = mergeResultsById(processResults, data.results || []);
      processResults = pruneResultsToCurrentSource(processResults, opportunities);
      renderProcessedList();
      renderTable();
      setStatus(`Done. ${data.successCount} succeeded, ${data.failureCount} failed.`);
      appendModalLog(`Job complete. Success: ${data.successCount}, Failed: ${data.failureCount}.`);
      modalCurrent.textContent = "Current: complete";
      setModalProgress(data.requested ?? processResults.length, data.requested ?? processResults.length);
      modalCloseButton.disabled = false;
      activeEventSource?.close();
      activeEventSource = null;
      const firstSuccess = processResults.find((item) => item.ok);
      if (firstSuccess) await loadMarkdownForId(firstSuccess.id);
    });

    activeEventSource.addEventListener("stream-end", () => {
      activeEventSource?.close();
      activeEventSource = null;
    });

    activeEventSource.onerror = () => {
      appendModalLog("Live stream disconnected. You can close the modal.");
      modalCloseButton.disabled = false;
      activeEventSource?.close();
      activeEventSource = null;
    };
  } catch (error) {
    setStatus(`Processing failed: ${error.message}`);
    appendModalLog(`Error: ${error.message}`);
    modalCloseButton.disabled = false;
  } finally {
    processButton.disabled = false;
  }
};

const clearCache = async () => {
  clearCacheButton.disabled = true;
  try {
    const dataFile = dataFileInput.value.trim();
    const response = await fetch("/api/cache/clear", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ dataFile }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Failed to clear cache.");
    const clearedIds = new Set(Array.isArray(payload.sourceIds) ? payload.sourceIds.map((id) => String(id)) : []);
    processResults = processResults.filter((item) => !clearedIds.has(String(item?.id || "")));
    if (activeMarkdownId && clearedIds.has(String(activeMarkdownId))) {
      activeMarkdownId = "";
      viewerMeta.textContent = "No markdown selected.";
      markdownRaw.textContent = "";
      markdownRendered.innerHTML = "";
    }
    renderProcessedList();
    renderTable();
    setStatus(
      `Cleared source cache for ${payload.idsConsidered ?? 0} IDs: ${payload.llmDeletedCount ?? 0} llm, ${payload.markdownDeletedCount ?? 0} markdown.`,
    );
  } catch (error) {
    setStatus(`Clear cache failed: ${error.message}`);
  } finally {
    clearCacheButton.disabled = false;
  }
};

oppsBody.addEventListener("change", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLInputElement)) return;
  if (target.type !== "checkbox") return;
  const id = target.dataset.id;
  if (!id) return;
  if (target.checked) selectedIds.add(id);
  else selectedIds.delete(id);
  updateSelectionCount();
});
oppsBody.addEventListener("click", async (event) => {
  const target = event.target;
  if (!(target instanceof Element)) return;
  const button = target.closest("button[data-row-view-id]");
  if (!(button instanceof HTMLButtonElement)) return;
  const id = button.dataset.rowViewId;
  if (!id) return;
  setViewerMode("rendered");
  await loadMarkdownForId(id);
  markdownRendered.scrollIntoView({ behavior: "smooth", block: "start" });
});

tabBatchButton.addEventListener("click", () => switchTab("batch"));
tabSingleButton.addEventListener("click", () => switchTab("single"));
singleGenerateButton.addEventListener("click", generateById);
singleOppIdInput.addEventListener("keydown", (e) => { if (e.key === "Enter") generateById(); });

settingsButton.addEventListener("click", openSettingsPage);
settingsBackButton.addEventListener("click", closeSettingsPage);
settingsSaveButton.addEventListener("click", saveSettingsPage);
settingsResetButton.addEventListener("click", resetToSystemDefaults);
settingGwKeyToggle.addEventListener("click", () => {
  const isHidden = settingGwKey.type === "password";
  settingGwKey.type = isHidden ? "text" : "password";
  settingGwKeyToggle.textContent = isHidden ? "Hide" : "Show";
});

browseButton.addEventListener("click", browseFile);

reloadButton.addEventListener("click", loadOpportunities);
clearCacheButton.addEventListener("click", clearCache);
selectAllButton.addEventListener("click", () => {
  for (const opp of opportunities) selectedIds.add(String(opp.Id || ""));
  renderTable();
});
clearSelectionButton.addEventListener("click", () => {
  selectedIds.clear();
  renderTable();
});
processButton.addEventListener("click", processSelected);
oppsHead.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof Element)) return;
  const button = target.closest(".sort-header[data-sort-key]");
  if (!(button instanceof HTMLButtonElement)) return;
  const key = button.dataset.sortKey;
  if (!key) return;
  if (sortKey === key) sortDirection = sortDirection === "asc" ? "desc" : "asc";
  else {
    sortKey = key;
    sortDirection = "asc";
  }
  currentPage = 1;
  saveTableState();
  renderTable();
});
pageSizeInput.addEventListener("change", () => {
  const parsed = Number(pageSizeInput.value);
  pageSize = Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 50;
  currentPage = 1;
  saveTableState();
  renderTable();
});
prevPageButton.addEventListener("click", () => {
  if (currentPage <= 1) return;
  currentPage -= 1;
  saveTableState();
  renderTable();
});
nextPageButton.addEventListener("click", () => {
  const totalPages = Math.max(1, Math.ceil(opportunities.length / pageSize));
  if (currentPage >= totalPages) return;
  currentPage += 1;
  saveTableState();
  renderTable();
});
processedList.addEventListener("click", async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLButtonElement)) return;
  const id = target.dataset.viewId;
  if (!id) return;
  await loadMarkdownForId(id);
});
renderedModeButton.addEventListener("click", () => setViewerMode("rendered"));
rawModeButton.addEventListener("click", () => setViewerMode("raw"));
modalCloseButton.addEventListener("click", closeModal);

loadTableState();
const lastFile = loadLastDataFile();
if (lastFile) dataFileInput.value = lastFile;
await syncSettingsToServer();
await loadOpportunities();
await checkConnectivity();

fetch('/api/version')
  .then(r => r.json())
  .then(({ version }) => {
    const el = document.getElementById('appVersion');
    if (el) el.textContent = `Version ${version}`;
  })
  .catch(() => {});
setViewerMode("rendered");
viewerMeta.textContent = activeMarkdownId ? activeMarkdownId : "No markdown selected.";
